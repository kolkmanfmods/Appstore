#!/bin/sh
# shellcheck disable=SC2004 disable=SC2048 disable=SC2070 disable=SC2086 disable=SC3041 disable=SC3054
#########################################################################################################################################################################
#	Installation script for Video Player																																#
#########################################################################################################################################################################
#																																										#
#					AAA								   TTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEE			   AAA				 MMMMMMMM				MMMMMMMM	#
#				   A:::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			  A:::A				 M:::::::M			   M:::::::M	#
#				  A:::::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			 A:::::A			 M::::::::M			  M::::::::M	#
#				 A:::::::A							   T:::::TT:::::::TT:::::TEE::::::EEEEEEEEE::::E			A:::::::A			 M:::::::::M		 M:::::::::M	#
#				A:::::::::A							   TTTTTT  T:::::T  TTTTTT  E:::::E		  EEEEEE		   A:::::::::A			 M::::::::::M		M::::::::::M	#
#			   A:::::A:::::A								   T:::::T			E:::::E			 			  A:::::A:::::A			 M:::::::::::M	   M:::::::::::M	#
#			  A:::::A A:::::A								   T:::::T			E::::::EEEEEEEEEE			 A:::::A A:::::A		 M:::::::M::::M   M::::M:::::::M	#
#			 A:::::A   A:::::A		   ---------------		   T:::::T			E:::::::::::::::E			A:::::A   A:::::A		 M::::::M M::::M M::::M M::::::M	#
#			A:::::A		A:::::A		   -:::::::::::::-		   T:::::T			E:::::::::::::::E		   A:::::A	   A:::::A		 M::::::M  M::::M::::M  M::::::M	#
#		   A:::::AAAAAAAAA:::::A	   ---------------		   T:::::T			E::::::EEEEEEEEEE		  A:::::AAAAAAAAA:::::A		 M::::::M   M:::::::M   M::::::M	#
#		  A:::::::::::::::::::::A							   T:::::T			E:::::E			 		 A:::::::::::::::::::::A	 M::::::M	 M:::::M	M::::::M	#
#		 A:::::AAAAAAAAAAAAA:::::A							   T:::::T			E:::::E		  EEEEEE	A:::::AAAAAAAAAAAAA:::::A	 M::::::M	  MMMMM		M::::::M	#
#		A:::::A				A:::::A							 TT:::::::TT	  EE::::::EEEEEEEE:::::E   A:::::A			   A:::::A   M::::::M				M::::::M	#
#	   A:::::A				 A:::::A						 T:::::::::T	  E::::::::::::::::::::E  A:::::A				A:::::A  M::::::M				M::::::M	#
#	  A:::::A				  A:::::A						 T:::::::::T	  E::::::::::::::::::::E A:::::A				 A:::::A M::::::M				M::::::M	#
#	 AAAAAAA				   AAAAAAA						 TTTTTTTTTTT	  EEEEEEEEEEEEEEEEEEEEEEAAAAAAA					 AAAAAAAMMMMMMMM				MMMMMMMM	#
#																																										#
#########################################################################################################################################################################
#																																										#
#							 ###############																															#
#							#				#																															#
#						  #					 #					M			 M						 D			 														#
#				 #########	   FFFFFFFFFFF	  #########			MM			MM						 D			 														#
#						#	   FF			   #				M M		   M M   OOOOOOOO	DDDDDDD D   SSSSSSSS		   NN		N  EEEEEEEEEE  TTTTTTTTTT			#
#			############	   FF FFFF			############	M  M	  M  M  O		 O  D		 D  S				   N NN		N  EE			   TT				#
#						#	   FF			   #				M   M	 M   M  O		 O  D		 D   SSSSSSSS		   N   NN   N  EEEEEEEEEE	   TT				#
#				 #########	   FF			  #########			M	  M M	 M  O		 O  D		 D			 S   ###   N	 NN N  EE			   TT				#
#						  #	   FF			 #					M	   M	 M   OOOOOOOO	DDDDDDDD	 SSSSSSSS	 ###   N	   NN  EEEEEEEEEE	   TT				#
#						   #				#																															#
#							################																															#
#																																										#
#########################################################################################################################################################################

# Mod Name		: Video Player ( VIDEO_SUPPORT ).
# Author		: AJC and Au{R}oN | www.fmods.net.
# Creation date	: 2017-12-26.
# Version		: 3.2.
# Update date	: 2026-08-18.
# Update notes	: Adjusted to support FMods Tools 3.3 and added an uninstall script and hashes for all altered, to be patched files.

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Environment variables. MODNAME.																																		#
#########################################################################################################################################################################

# Feel free to delete unnecessary Env. vars
SCRIPT_DIR="${0%/*}"
USB_ROOT_DIR="${SCRIPT_DIR%/*}"
FILES_DIR="${SCRIPT_DIR}/files"
BIN_DIR="${FILES_DIR}/bin"
ICON_DIR="${FILES_DIR}/icon"
PATCH_DIR="${FILES_DIR}/patch"
SHELL_DIR="${FILES_DIR}/shell"
OTHER_DIR="${FILES_DIR}/other"
BACKUP_DIR="${OTHER_DIR}/backup"
NEW_DIR="${OTHER_DIR}/new"
LOG_FILE="${USB_ROOT_DIR}/installation_$(date +"%Y%m%d_%H%M%S").log"
FMODS_MODS_DIR="/fs/images/fmods_mods_data"
MODS_JSON_PATH="${FMODS_MODS_DIR}/mods.json"

# Put your mod name in this variable.
# Do not use space character, use only uppercase letters and do NOT use any special character other than _
# Examples: ANALOGUE_CLOCK, BLACK_THEME, VIDEO_PLAYER, ENHANCED_CALM_SCREEN
# MODNAME="YOUR_MOD_NAME"
MODNAME="VIDEO_SUPPORT"

# Mod Name and Version
FANCYNAME="Video Player"
VERSION="3.2"

# Developer Name
AUTHOR="AJC and AuRoN89"

# Minimum SYNC 3 compatible version. Uncomment (remove the # at the beginning of the line below) it only if required.
SYNC3_MIN_BUILD="3.4.21194"

# FMods Tools entries
MODTOOLS="FMODS_TOOLS"
MIN_MODTOOLS_VERSION="3.0"

# Variables
DISPLAY="/fs/tmpfs/status"
POPUP="/tmp/popup.txt"

# Backup value: should (default) files be copied (BACKUP=1) from SYNC3 to the USB stick or not (BACKUP=0).
BACKUP=0

# USBPATCH value: should files be patched (USBPATCH=1) in the new folder on the USB stick or not (USBPATCH=0). Useful for manual copying files.
USBPATCH=1

# MANUAL value: should the new files be copied directly without patch (MANUAL=1) or not (MANUAL=0).
# Can be useful if you do not want to create a new master.patch but just want to replace a few files.
MANUAL=0

# Restore value: should the patch in the mod be applied without restore (RESTORE=0) or do stock files have to be restored to SYNC 3 first (RESTORE=1).
RESTORE=1

# PATCH value: should the patch in the mod be applied (PATCH=1) or not (PATCH=0). PATCH=0 and RESTORE=1 is useful if you want to go back to stock.
PATCH=1

# UNPATCH value: should the reverse patch in the mod be applied (UNPATCH=1) or not (UNPATCH=0).
UNPATCH=0

# UPDATE MODE
UPDATE=0

# Dependencies
MDEPENDENCY="ModsManager"
DEPENDENCY=""

# Use these lines below to specify your .patch files.
MOD_PATCH="master.patch"
MOD_DEPENDENCY_PATCH=""
# NEW_PATCH="masterGPS.patch"
USB_PATCH="masterUSB.patch"
USB_DEPENDENCY_PATCH=""

HASH_TEXT_FILE="original_hashes.txt"
HASH_JSON_FILE="original_hashes.json"

# Add your to be patched files as mentioned in the master*.patch files in the list, so a backup and patched version
# is saved on the USB stick (based on the hash value).
set -A ALTERED_FILES \
	"/fs/mp/etc/mm/mm-sync.conf" \
	"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/qmldir" \
	"/fs/mp/fordhmi/imports/Hmi/Ford/MenuBar.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/CoverAlbumButton.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/GeneralUSBScreen.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/SongInformationView.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/USBMusicScreen.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/usb/SongInformationPage.qml" \
	"/fs/mp/fordhmi/imports/Hmi/Ford/+10inchL/MenuBar.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/CoverAlbumButton.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/GeneralUSBScreen.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/SongInformationView.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/USBMusicScreen.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/usb/+10inchL/SongInformationPage.qml" \
	"/fs/mp/fordhmi/imports/Hmi/Ford/+10inchP/MenuBar.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/+10inchP/GeneralUSBScreen.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/+10inchP/SongInformationView.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/usb/+10inchP/SongInformationPage.qml" \
	"/fs/mp/fordhmi/imports/Hmi/Ford/+lincoln-MY20/MenuBar.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/GeneralUSBScreen.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/SongInformationView.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/USBMusicScreen.qml" \
	"/fs/mp/fordhmi/qml/hmimedia/usb/+lincoln-MY20/SongInformationPage.qml"
# In case of mutiple files: only the last line should not have a \ at the end, example:
# "/fs/mp/fordhmi/qml/hminavigation/NavigationFaultPopup.qml" \
# "/fs/mp/fordhmi/qml/hmitrafficcenter/popups/Disclaimer.qml" \
# "/fs/mp/fordhmi/qml/hmimedia/components/GeneralUSBScreen.qml" \
# "/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/GeneralUSBScreen.qml" \
# "/fs/mp/fordhmi/qml/hmimedia/components/+10inchP/GeneralUSBScreen.qml" \
# "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/GeneralUSBScreen.qml"

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Functions that you have to call in order to display an image on the screen (as soon as user removes the USB pendrive, the APIM is rebooted).						#
#########################################################################################################################################################################

PATH="/fs/rwdata/dev:${PATH}"

output() {
	echo "${1}" >																				"${DISPLAY}"
	echo "${1}" >> 																				"${LOG_FILE}"
	sleep "${2}"
}

progress() {
	echo "PROGRESS ${1}" >																		"${DISPLAY}"
}

displayMessage() {
	echo "${1}" >>																				"${POPUP}"
	utserviceutility popup																		"${POPUP}"
	exit 0
}

installationTerminated() {
	while [ -e "/fs/usb0" ]; do
		sleep 1
	done
	output "REBOOT" 3
	exit 0
}

# To create a hash for a file SongInformationPage.qml (replace this name with your file in the commented lines below) on a Windows11 system inside folder c:\temp use:
# $hash = (([System.Security.Cryptography.SHA1]::Create()).ComputeHash([System.Text.Encoding]::UTF8.GetBytes(([System.IO.File]::ReadAllText("C:\temp\mm-sync.conf") -replace "`r",""))) | ForEach-Object { $_.ToString("x2") }) -join ""
# "$hash  mm-sync.conf"
# $hash = (([System.Security.Cryptography.SHA1]::Create()).ComputeHash([System.Text.Encoding]::UTF8.GetBytes(([System.IO.File]::ReadAllText("C:\temp\qmldir") -replace "`r",""))) | ForEach-Object { $_.ToString("x2") }) -join ""
# "$hash  qmldir"
# $hash = (([System.Security.Cryptography.SHA1]::Create()).ComputeHash([System.Text.Encoding]::UTF8.GetBytes(([System.IO.File]::ReadAllText("C:\temp\MenuBar.qml") -replace "`r",""))) | ForEach-Object { $_.ToString("x2") }) -join ""
# "$hash  MenuBar.qml"
# $hash = (([System.Security.Cryptography.SHA1]::Create()).ComputeHash([System.Text.Encoding]::UTF8.GetBytes(([System.IO.File]::ReadAllText("C:\temp\CoverAlbumButton.qml") -replace "`r",""))) | ForEach-Object { $_.ToString("x2") }) -join ""
# "$hash  CoverAlbumButton.qml"
# $hash = (([System.Security.Cryptography.SHA1]::Create()).ComputeHash([System.Text.Encoding]::UTF8.GetBytes(([System.IO.File]::ReadAllText("C:\temp\GeneralUSBScreen.qml") -replace "`r",""))) | ForEach-Object { $_.ToString("x2") }) -join ""
# "$hash  GeneralUSBScreen.qml"
# $hash = (([System.Security.Cryptography.SHA1]::Create()).ComputeHash([System.Text.Encoding]::UTF8.GetBytes(([System.IO.File]::ReadAllText("C:\temp\SongInformationView.qml") -replace "`r",""))) | ForEach-Object { $_.ToString("x2") }) -join ""
# "$hash  SongInformationView.qml"
# $hash = (([System.Security.Cryptography.SHA1]::Create()).ComputeHash([System.Text.Encoding]::UTF8.GetBytes(([System.IO.File]::ReadAllText("C:\temp\USBMusicScreen.qml") -replace "`r",""))) | ForEach-Object { $_.ToString("x2") }) -join ""
# "$hash  USBMusicScreen.qml"
# $hash = (([System.Security.Cryptography.SHA1]::Create()).ComputeHash([System.Text.Encoding]::UTF8.GetBytes(([System.IO.File]::ReadAllText("C:\temp\SongInformationPage.qml") -replace "`r",""))) | ForEach-Object { $_.ToString("x2") }) -join ""
# "$hash  SongInformationPage.qml"
# and copy the hash to original_hashes.txt. Make sure the .txt file is saved with LF line endings.
sha1Hash() {
	# Strips CR before hashing, so CRLF vs LF alone never causes a false mismatch
	hash=$(tr -d '\r' < "$1" | openssl dgst -sha1 2>/dev/null)
	printf '%s' "${hash#*= }"
}

getStoredHash() {
	tr -d '\r' < "${1}" | awk -v want="${2}" '$1 !~ /^#/ && $2 == want { print $1; exit }'
}

deriveHashKey() {
	FP="${1}"
	case "${FP}" in
		/fs/mp/fordhmi/qml/themes/ford-MY20/*) MF="0" ;;
		/fs/mp/fordhmi/qml/themes/ford-10P-MY20/*) MF="+10inchP" ;;
		/fs/mp/fordhmi/qml/themes/lincoln-10L-MY20/*) MF="+10inchL" ;;
		/fs/mp/fordhmi/qml/themes/lincoln-MY20/*) MF="+lincoln-MY20" ;;
		/fs/mp/fordhmi/qml/themes/root-theme/*) MF="root-theme" ;;
		/fs/mp/fordhmi/qml/themes/*) MF="0" ;;
		*)
			FPARENT="${FP%/*}"
			FLASTSEG="${FPARENT##*/}"
			case "${FLASTSEG}" in
				+*) MF="${FLASTSEG}" ;;
				*) MF="0" ;;
			esac
			;;
	esac
	if [ ! "${MF}" = "0" ]; then
		echo "${MF}_${FP##*/}"
	else
		echo "${FP##*/}"
	fi
}

buildHashJsonFromText() {
	JSONFILE="$1"
	HASHFILE="${OTHER_DIR}/original_hashes.txt"
	if [ ! -f "$HASHFILE" ]; then
		echo "{\"officialName\":\"$MODNAME\",\"sourceFile\":\"original_hashes.txt (MISSING)\",\"patchedFiles\":[]}" > "$JSONFILE"
		return
	fi
	HASHFILE_CLEAN="/fs/tmpfs/original_hashes_noCR_${MODNAME}.txt"
	tr -d '\r' < "$HASHFILE" > "$HASHFILE_CLEAN"
	ENTRIES=""
	first_entry=1
	for fp in ${ALTERED_FILES[*]}; do
		HASHKEY=$(deriveHashKey "$fp")
		STOCK=""
		PATCHED=""
		DEPPATCHED=""
		OWNDEPPATCHED=""
		while IFS= read -r line; do
			case "$line" in
				\#*) continue ;;
				*) 
					set -- $line
					hash="$1"
					key="$2"
					case "$key" in
						"Stock_$HASHKEY") STOCK="$hash" ;;
						"Patched_$HASHKEY") PATCHED="$hash" ;;
						"DependencyPatched_$HASHKEY") DEPPATCHED="$hash" ;;
						"PatchedWithDependency_$HASHKEY") OWNDEPPATCHED="$hash" ;;
					esac
					;;
			esac
		done < "$HASHFILE_CLEAN"
		VARIANTS=""
		if [ -n "$PATCHED" ]; then
			VARIANTS="${VARIANTS}{\"dependencies\":[],\"label\":\"default\",\"hash\":\"$PATCHED\"}"
		fi
		if [ -n "$DEPPATCHED" ]; then
			if [ -n "$VARIANTS" ]; then
				VARIANTS="${VARIANTS},"
			fi
			if [ -n "$DEPENDENCY" ]; then
				VARIANTS="${VARIANTS}{\"dependencies\":[\"$DEPENDENCY\"],\"label\":\"already patched by $DEPENDENCY\",\"hash\":\"$DEPPATCHED\"}"
			else
				VARIANTS="${VARIANTS}{\"dependencies\":[],\"label\":\"dependency-patched\",\"hash\":\"$DEPPATCHED\"}"
			fi
		fi
		if [ -n "$OWNDEPPATCHED" ]; then
			if [ -n "$VARIANTS" ]; then
				VARIANTS="${VARIANTS},"
			fi
			if [ -n "$DEPENDENCY" ]; then
				VARIANTS="${VARIANTS}{\"dependencies\":[\"$DEPENDENCY\"],\"label\":\"own patch after $DEPENDENCY\",\"hash\":\"$OWNDEPPATCHED\"}"
			else
				VARIANTS="${VARIANTS}{\"dependencies\":[],\"label\":\"own patch after dependency\",\"hash\":\"$OWNDEPPATCHED\"}"
			fi
		fi
		VARIANTS="[${VARIANTS}]"
		if [ $first_entry -eq 0 ]; then
			ENTRIES="${ENTRIES},"
		fi
		ENTRIES="${ENTRIES}{\"path\":\"${fp}\",\"stockHash\":\"${STOCK}\",\"variants\":${VARIANTS}}"
		first_entry=0
	done
	echo "{\"officialName\":\"$MODNAME\",\"sourceFile\":\"original_hashes.txt\",\"patchedFiles\":[${ENTRIES}]}" > "$JSONFILE"
	rm -f "$HASHFILE_CLEAN"
}

getJsonHashState() {
	FPATH="${1}"
	LIVEHASH="${2}"
	JSONFILE="${3}"
	if [ ! -f "${JSONFILE}" ] || ! jq empty "${JSONFILE}" >/dev/null 2>&1; then
		return
	fi
	jq -r --arg p "${FPATH}" --arg h "${LIVEHASH}" '
		(.patchedFiles[]? | select(.path == $p)) as $f
		| if $f == null then empty
		  elif $f.stockHash == $h then "stock"
		  else ( ($f.variants // []) | map(select(.hash == $h)) | if length > 0 then .[0].label else "unknown" end )
		  end
	' "${JSONFILE}" 2>/dev/null
}

getJsonRecordedInfo() {
	FPATH="${1}"
	JSONFILE="${2}"
	if [ ! -f "${JSONFILE}" ] || ! jq empty "${JSONFILE}" >/dev/null 2>&1; then
		echo "(no original_hashes.json)"
		return
	fi
	jq -r --arg p "${FPATH}" '
		(.patchedFiles[]? | select(.path == $p)) as $f
		| if $f == null then "(path not tracked in original_hashes.json)"
		  else ([{label: "stock", hash: $f.stockHash}] + ($f.variants // []))
			   | map("\(.label)=\(.hash)")
			   | if length > 1 then .[0] + ",\n" + (.[1:] | join(", ")) else (.[0] // "") end
		  end
	' "${JSONFILE}" 2>/dev/null
}

detectAppliedPatch() {
	FOUND_WITH=0
	FOUND_WITHOUT=0
	for fp in ${ALTERED_FILES[*]}; do
		if [ -f "${fp}" ]; then
			LIVE_HASH=$(sha1Hash "${fp}")
			STATE=$(getJsonHashState "${fp}" "${LIVE_HASH}" "${OTHER_DIR}/${HASH_JSON_FILE}")
			case "${STATE}" in
				"own patch after "*) FOUND_WITH=1 ;;
				"default") FOUND_WITHOUT=1 ;;
			esac
		fi
	done
	if [ "${FOUND_WITH}" -eq 1 ] && [ "${FOUND_WITHOUT}" -eq 0 ]; then
		echo "with_dependency"
	elif [ "${FOUND_WITHOUT}" -eq 1 ] && [ "${FOUND_WITH}" -eq 0 ]; then
		echo "without_dependency"
	else
		echo "unknown"
	fi
}

buildHashJsonFromText "${OTHER_DIR}/${HASH_JSON_FILE}"

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Check if FMods Tools are installed																																	#
#########################################################################################################################################################################

if ! grep -q "${MODTOOLS}" 																		"/fs/rwdata/dev/mods_tools.txt"; then
	displayMessage "FMods Tools not found. Installation aborted."
else
	LINE=$(grep "${MODTOOLS}" "/fs/rwdata/dev/mods_tools.txt")
	MODS_TOOLS_VERSION=$(echo "$LINE" | awk -F'_' '{print $NF}')
	if ! awk 'BEGIN {exit !('"${MODS_TOOLS_VERSION}"' >= '"${MIN_MODTOOLS_VERSION}"') }'; then
		displayMessage "FMods Tools ${MIN_MODTOOLS_VERSION} or higher not found. Installation aborted."
	fi
fi

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Launch Installer Utility																																			#
#########################################################################################################################################################################

cp -r "${OTHER_DIR}/images/"*																	"/tmp/"
chmod a+x "/fs/rwdata/dev/"*
sleep 1

instutility &
sleep 2

output "DEV ${FANCYNAME} v${VERSION} - Developed by ${AUTHOR}" 1

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Remount FS as RW																																					#
#########################################################################################################################################################################

remount_rw.sh
sleep 1

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	In case of RESTORE and not MANUAL, remove the name of the Mod from the file /fs/mp/etc/installed_mods.txt.															#
#########################################################################################################################################################################

if [ "${MANUAL:-0}" -eq 0 ] && [ "${RESTORE:-0}" -eq 1 ]; then
	progress 10
	if grep -q "${MODNAME}" 																	"/fs/mp/etc/installed_mods.txt"; then
		sed -i -e "/${MODNAME}/d" 																"/fs/mp/etc/installed_mods.txt"
		INSTALLED_BEFORE=1
	fi
	output "Mod name(s) removed from installed_mods.txt." 1
fi

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK. 																																			#
#	Check if this Mod is already installed.																																#
#########################################################################################################################################################################

# DO NOT EDIT. Remove the # below if your mod has a name. If not, DO NOT EDIT.
if [ "${MANUAL:-0}" -eq 0 ]; then
	if grep -q "${MODNAME}" 																	"/fs/mp/etc/installed_mods.txt"; then
		progress 50
		output "${MODNAME} is already installed in your SYNC 3." 1
		progress 100
		output "Please remove the USB stick to reboot." 1
		remount_ro.sh
		sync
		sync
		sync
		installationTerminated
	fi
fi

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Backup old file(s) to USB stick if they do not exist yet in the USB stick folder.																					#
#########################################################################################################################################################################

if [ "${BACKUP:-0}" -eq 1 ]; then
	for VERIFYPATH in ${ALTERED_FILES[*]}; do
		VERIFYNAME="${VERIFYPATH##*/}"
		case "${VERIFYPATH}" in
			/fs/mp/fordhmi/qml/themes/ford-MY20/*) MODFOLDER="0" ;;
			/fs/mp/fordhmi/qml/themes/ford-10P-MY20/*) MODFOLDER="+10inchP" ;;
			/fs/mp/fordhmi/qml/themes/lincoln-10L-MY20/*) MODFOLDER="+10inchL" ;;
			/fs/mp/fordhmi/qml/themes/lincoln-MY20/*) MODFOLDER="+lincoln-MY20" ;;
			/fs/mp/fordhmi/qml/themes/root-theme/*) MODFOLDER="root-theme" ;;
			/fs/mp/fordhmi/qml/themes/*) MODFOLDER="0" ;;
			*)
				VERIFYPARENT="${VERIFYPATH%/*}"
				VERIFYLASTSEG="${VERIFYPARENT##*/}"
				case "${VERIFYLASTSEG}" in
					+*) MODFOLDER="${VERIFYLASTSEG}" ;;
					*) MODFOLDER="0" ;;
				esac
				;;
		esac
		if [ ! "${MODFOLDER}" = "0" ]; then
			HASHKEY="${MODFOLDER}_${VERIFYNAME}"
			BACKUP_TARGET_DIR="${BACKUP_DIR}/${MODFOLDER}"
			DISPLAYNAME="${MODFOLDER}/${VERIFYNAME}"
		else
			HASHKEY="${VERIFYNAME}"
			BACKUP_TARGET_DIR="${BACKUP_DIR}"
			DISPLAYNAME="${VERIFYNAME}"
		fi
		mkdir -p "${BACKUP_TARGET_DIR}"
		STOCK_HASH=$(getStoredHash "${OTHER_DIR}/${HASH_TEXT_FILE}" "Stock_${HASHKEY}")
		PATCHED_HASH=$(getStoredHash "${OTHER_DIR}/${HASH_TEXT_FILE}" "Patched_${HASHKEY}")
		DEPENDENCY_HASH=$(getStoredHash "${OTHER_DIR}/${HASH_TEXT_FILE}" "DependencyPatched_${HASHKEY}")
		if [ ! -f "${BACKUP_TARGET_DIR}/${VERIFYNAME}" ] && [ ! -f "${VERIFYPATH}.orig" ]; then
			if [ -f "${VERIFYPATH}" ] && { [ -n "${STOCK_HASH}" ] || [ -n "${PATCHED_HASH}" ] || [ -n "${DEPENDENCY_HASH}" ]; }; then
				LIVE_HASH=$(sha1Hash "${VERIFYPATH}")
				if [ -n "${STOCK_HASH}" ] && [ "${LIVE_HASH}" = "${STOCK_HASH}" ]; then
					: # genuinely stock, safe to back up below
				elif [ -n "${PATCHED_HASH}" ] && [ "${LIVE_HASH}" = "${PATCHED_HASH}" ]; then
					output "${DISPLAYNAME} already matches the known patched version." 1
				elif [ -n "${DEPENDENCY_HASH}" ] && [ "${LIVE_HASH}" = "${DEPENDENCY_HASH}" ]; then
					output "${DISPLAYNAME} matches the expected ${DEPENDENCY}-patched version" 1
					output "safe to proceed - the dependency-aware patch will apply from here." 1
				else
					cp "${VERIFYPATH}" 															"${USB_ROOT_DIR}/${VERIFYNAME}_unknown"
					echo "${LIVE_HASH}" >> 														"${USB_ROOT_DIR}/${VERIFYNAME}_unknown_hash.txt"
					output "${DISPLAYNAME} doesn't match any known stock, patched, or" 1
					output "dependency-patched version. It may be modified by something else." 1
					output "Installation aborted for safety." 1
					progress 100
					output "Please remove the USB stick to reboot." 1
					remount_ro.sh
					sync
					sync
					sync
					installationTerminated
				fi
			fi
			if [ -f "${VERIFYPATH}" ]; then
				output "Backup ${DISPLAYNAME} from SYNC 3 to USB!" 1
				cp "${VERIFYPATH}"																"${BACKUP_TARGET_DIR}/"
				output "Backup of ${DISPLAYNAME} from SYNC 3 to USB was successful!" 1
				sleep 3
			fi
		elif [ -f "${BACKUP_TARGET_DIR}/${VERIFYNAME}" ]; then
			output "${DISPLAYNAME} is already backed up on the USB stick, skipping." 1
		fi
		if [ -f "${VERIFYPATH}.orig" ] && { [ -n "${STOCK_HASH}" ] || [ -n "${DEPENDENCY_HASH}" ]; }; then
			ORIG_HASH=$(sha1Hash "${VERIFYPATH}.orig")
			if [ "${ORIG_HASH}" != "${STOCK_HASH}" ] && [ "${ORIG_HASH}" != "${DEPENDENCY_HASH}" ]; then
				if [ -f "${BACKUP_TARGET_DIR}/${VERIFYNAME}" ]; then
					output "Existing .orig for ${DISPLAYNAME} doesn't match the expected" 1
					output "stock or ${DEPENDENCY}-patched hash - likely because another mod" 1
					output "already patched this file. A verified backup already exists, continuing." 1
				else
					cp "${VERIFYPATH}.orig" 													"${USB_ROOT_DIR}/${VERIFYNAME}.orig"
					echo "${ORIG_HASH}" >> 														"${USB_ROOT_DIR}/${VERIFYNAME}_orig_hash.txt"
					output "Existing .orig for ${DISPLAYNAME} doesn't match the expected" 1
					output "stock or ${DEPENDENCY}-patched hash - it may be corrupted" 1
					output "or from something else entirely." 1
					output "Cannot verify the existing backup for ${DISPLAYNAME}. Aborted." 1
					output "Installation aborted for safety." 1
					progress 100
					output "Please remove the USB stick to reboot." 1
					remount_ro.sh
					sync
					sync
					sync
					installationTerminated
				fi
			elif [ ! -f "${BACKUP_TARGET_DIR}/${VERIFYNAME}" ]; then
				output "Copying verified .orig for ${DISPLAYNAME} to backup!" 1
				cp "${VERIFYPATH}.orig"															"${BACKUP_TARGET_DIR}/${VERIFYNAME}"
				output "Backup of ${DISPLAYNAME} from .orig was successful!" 1
			fi
		fi
	done
	# START BLOCK BACKUP CUSTOM MOD FILES.
	# Below an example of a copy command to backup files
	# cp "/fs/mp/fordhmi/qml/hminavigation/homewidget/HomeClock.qml"							"${BACKUP_DIR}/"
	# END BLOCK BACKUP CUSTOM MOD FILES.
	if [ "${USBPATCH:-0}" -eq 1 ] && [ "${INSTALLED_BEFORE:-0}" -eq 0 ]; then
		NEED_USB_PATCH=0
		for fp in ${ALTERED_FILES[*]}; do
			filename="${fp##*/}"
			case "${fp}" in
				/fs/mp/fordhmi/qml/themes/ford-MY20/*) modfolder="0" ;;
				/fs/mp/fordhmi/qml/themes/ford-10P-MY20/*) modfolder="+10inchP" ;;
				/fs/mp/fordhmi/qml/themes/lincoln-10L-MY20/*) modfolder="+10inchL" ;;
				/fs/mp/fordhmi/qml/themes/lincoln-MY20/*) modfolder="+lincoln-MY20" ;;
				/fs/mp/fordhmi/qml/themes/root-theme/*) modfolder="root-theme" ;;
				/fs/mp/fordhmi/qml/themes/*) modfolder="0" ;;
				*)
					parentdir="${fp%/*}"
					lastseg="${parentdir##*/}"
					case "${lastseg}" in
						+*) modfolder="${lastseg}" ;;
						*) modfolder="0" ;;
					esac
					;;
			esac
			if [ ! "${modfolder}" = "0" ]; then
				USBSRC_DIR="${BACKUP_DIR}/${modfolder}"
				USBDST_DIR="${NEW_DIR}/${modfolder}"
			else
				USBSRC_DIR="${BACKUP_DIR}"
				USBDST_DIR="${NEW_DIR}"
			fi
			mkdir -p "${USBDST_DIR}"
			if [ -f "${USBDST_DIR}/${filename}.orig" ]; then
				rm -f "${USBDST_DIR}/${filename}" "${USBDST_DIR}/${filename}.orig"
			fi
			if [ -f "${USBSRC_DIR}/${filename}" ] && [ ! -f "${USBDST_DIR}/${filename}" ]; then
				cp "${USBSRC_DIR}/${filename}"													"${USBDST_DIR}/${filename}"
				NEED_USB_PATCH=1
			fi
		done
		APPLIED_VARIANT=$(detectAppliedPatch)
		if [ "${APPLIED_VARIANT}" = "with_dependency" ]; then
			USB_PATCH_TO_CHECK="${USB_DEPENDENCY_PATCH}"
		elif [ "${APPLIED_VARIANT}" = "without_dependency" ]; then
			USB_PATCH_TO_CHECK="${USB_PATCH}"
		elif [ -n "${DEPENDENCY}" ] && grep -q "${DEPENDENCY}" 									"/fs/mp/etc/installed_mods.txt"; then
			USB_PATCH_TO_CHECK="${USB_DEPENDENCY_PATCH}"
		else
			USB_PATCH_TO_CHECK="${USB_PATCH}"
		fi
		if [ "${NEED_USB_PATCH}" -eq 1 ] && [ -f "${PATCH_DIR}/${USB_PATCH_TO_CHECK}" ]; then
			sleep 1
			if [ "${USB_PATCH_TO_CHECK}" = "${USB_DEPENDENCY_PATCH}" ]; then
				if ! patch -l --dry-run -p0 < 													"${PATCH_DIR}/${USB_DEPENDENCY_PATCH}" > "${USB_ROOT_DIR}/patchUSB.log"; then
					output "${USB_DEPENDENCY_PATCH} for mod ${MODNAME} cannot be applied on USB!" 1
					output "Possible reasons are that your Sync version is not supported" 1
					output "(this mod supports SYNC 3 Build ${SYNC3_MIN_BUILD} or higher!) or there is a mod conflict." 1
					output "Try updating your Sync to the latest version." 1
					progress 100
					output "Please remove the USB stick to reboot." 1
					remount_ro.sh
					sync
					sync
					sync
					installationTerminated
				else
					output "${USB_DEPENDENCY_PATCH} for mod ${MODNAME} was tested successfully on USB. Now patching..." 1
					patch -l -b -p0 < 															"${PATCH_DIR}/${USB_DEPENDENCY_PATCH}"
					output "Install of ${USB_DEPENDENCY_PATCH} for ${MODNAME} on USB was successful." 1
				fi
			else
				if ! patch -l --dry-run -p0 < 													"${PATCH_DIR}/${USB_PATCH}" > "${USB_ROOT_DIR}/patchUSB.log"; then
					output "${USB_PATCH} for mod ${MODNAME} cannot be applied ON USB!" 1
					output "Possible reasons are that your Sync version is not supported" 1
					output "(this mod supports SYNC 3 Build ${SYNC3_MIN_BUILD} or higher!) or there is a mod conflict." 1
					output "Try updating your Sync to the latest version." 1
					progress 100
					output "Please remove the USB stick to reboot." 1
					remount_ro.sh
					sync
					sync
					sync
					installationTerminated
				else
					output "${USB_PATCH} for mod ${MODNAME} was tested successfully on USB. Now patching..." 1
					patch -l -b -p0 < 															"${PATCH_DIR}/${USB_PATCH}"
					output "Install of ${USB_PATCH} for ${MODNAME} was on USB successful." 1
				fi
			fi
		else
			output "USB patch skipped: all files are already in NEW_DIR." 1
		fi
		for fp in ${ALTERED_FILES[*]}; do
			filename="${fp##*/}"
			case "${fp}" in
				/fs/mp/fordhmi/qml/themes/ford-MY20/*) modfolder="0" ;;
				/fs/mp/fordhmi/qml/themes/ford-10P-MY20/*) modfolder="+10inchP" ;;
				/fs/mp/fordhmi/qml/themes/lincoln-10L-MY20/*) modfolder="+10inchL" ;;
				/fs/mp/fordhmi/qml/themes/lincoln-MY20/*) modfolder="+lincoln-MY20" ;;
				/fs/mp/fordhmi/qml/themes/root-theme/*) modfolder="root-theme" ;;
				/fs/mp/fordhmi/qml/themes/*) modfolder="0" ;;
				*)
					parentdir="${fp%/*}"
					lastseg="${parentdir##*/}"
					case "${lastseg}" in
						+*) modfolder="${lastseg}" ;;
						*) modfolder="0" ;;
					esac
					;;
			esac
			if [ ! "${modfolder}" = "0" ]; then
				rm -f "${NEW_DIR}/${modfolder}/${filename}.orig"
			else
				rm -f "${NEW_DIR}/${filename}.orig"
			fi
		done
	else
		if [ "${USBPATCH:-0}" -eq 1 ] && [ "${INSTALLED_BEFORE}" -eq 1 ]; then
			output "This mod was installed before: a backup is not reliable!" 1
			output "Restore first: set BACKUP and PATCH to 0 in autoinstall.sh" 1
			output "After Restore: set BACKUP and PATCH to 1 again to reinstall." 1
			progres 100
			output "Please remove the USB stick to reboot." 1
			remount_ro.sh
			sync
			sync
			sync
			installationTerminated
		fi
	fi
	for fp in ${ALTERED_FILES[*]}; do
		filename="${fp##*/}"
		case "${fp}" in
			/fs/mp/fordhmi/qml/themes/ford-MY20/*) modfolder="0" ;;
			/fs/mp/fordhmi/qml/themes/ford-10P-MY20/*) modfolder="+10inchP" ;;
			/fs/mp/fordhmi/qml/themes/lincoln-10L-MY20/*) modfolder="+10inchL" ;;
			/fs/mp/fordhmi/qml/themes/lincoln-MY20/*) modfolder="+lincoln-MY20" ;;
			/fs/mp/fordhmi/qml/themes/root-theme/*) modfolder="root-theme" ;;
			/fs/mp/fordhmi/qml/themes/*) modfolder="0" ;;
			*)
				parentdir="${fp%/*}"
				lastseg="${parentdir##*/}"
				case "${lastseg}" in
					+*) modfolder="${lastseg}" ;;
					*) modfolder="0" ;;
				esac
				;;
		esac
		if [ ! "${modfolder}" = "0" ]; then
			rm -f "${NEW_DIR}/${modfolder}/${filename}.orig"
		else
			rm -f "${NEW_DIR}/${filename}.orig"
		fi
	done
fi

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Restore old file(s) from USB stick to SYNC 3, so they can be patched again.																							#
#########################################################################################################################################################################

if [ "${RESTORE:-0}" -eq 1 ]; then
	progress 10
	output "Restoring original file(s) from USB to SYNC 3, so they can be patched again!" 1
	for fp in ${ALTERED_FILES[*]}; do
		filename="${fp##*/}"
		case "${fp}" in
			/fs/mp/fordhmi/qml/themes/ford-MY20/*) modfolder="0" ;;
			/fs/mp/fordhmi/qml/themes/ford-10P-MY20/*) modfolder="+10inchP" ;;
			/fs/mp/fordhmi/qml/themes/lincoln-10L-MY20/*) modfolder="+10inchL" ;;
			/fs/mp/fordhmi/qml/themes/lincoln-MY20/*) modfolder="+lincoln-MY20" ;;
			/fs/mp/fordhmi/qml/themes/root-theme/*) modfolder="root-theme" ;;
			/fs/mp/fordhmi/qml/themes/*) modfolder="0" ;;
			*)
				parentdir="${fp%/*}"
				lastseg="${parentdir##*/}"
				case "${lastseg}" in
					+*) modfolder="${lastseg}" ;;
					*) modfolder="0" ;;
				esac
				;;
		esac
		if [ ! "${modfolder}" = "0" ]; then
			RESTORE_SRC_DIR="${BACKUP_DIR}/${modfolder}"
		else
			RESTORE_SRC_DIR="${BACKUP_DIR}"
		fi
		if [ -f "${RESTORE_SRC_DIR}/${filename}" ]; then
			rm -f "${fp}.orig"
			cp "${RESTORE_SRC_DIR}/${filename}"													"${fp}"
		fi
	done
	# START BLOCK RESTORE CUSTOM MOD FILES.
	# Below an example of a copy command to backup files
	# rm -f "/fs/mp/fordhmi/qml/hminavigation/homewidget/HomeClock.qml"
	# END BLOCK RESTORE CUSTOM MOD FILES.
	progress 20
	output "Restoring original file(s) from USB to SYNC 3 was successful!" 1
fi

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Copying new file(s). If you want manual copying instead of a patch change line 94 (set PATCH=0 instead of PATCH=1) and 88 (set MANUAL=1 instead of MANUAL=0).		#
#########################################################################################################################################################################

if [ "${MANUAL:-0}" -eq 1 ]; then
	progress 30
	output "Manually copying new file(s) from USB to SYNC 3!" 1
	for fp in ${ALTERED_FILES[*]}; do
		filename="${fp##*/}"
		case "${fp}" in
			/fs/mp/fordhmi/qml/themes/ford-MY20/*) modfolder="0" ;;
			/fs/mp/fordhmi/qml/themes/ford-10P-MY20/*) modfolder="+10inchP" ;;
			/fs/mp/fordhmi/qml/themes/lincoln-10L-MY20/*) modfolder="+10inchL" ;;
			/fs/mp/fordhmi/qml/themes/lincoln-MY20/*) modfolder="+lincoln-MY20" ;;
			/fs/mp/fordhmi/qml/themes/root-theme/*) modfolder="root-theme" ;;
			/fs/mp/fordhmi/qml/themes/*) modfolder="0" ;;
			*)
				parentdir="${fp%/*}"
				lastseg="${parentdir##*/}"
				case "${lastseg}" in
					+*) modfolder="${lastseg}" ;;
					*) modfolder="0" ;;
				esac
				;;
		esac
		if [ ! "${modfolder}" = "0" ]; then
			MANUAL_SRC_DIR="${NEW_DIR}/${modfolder}"
		else
			MANUAL_SRC_DIR="${NEW_DIR}"
		fi
		if [ -f "${MANUAL_SRC_DIR}/${filename}" ]; then
			rm -f "${fp}.orig"
			cp "${MANUAL_SRC_DIR}/${filename}"													"${fp}"
		fi
	done
	# START BLOCK ADDING MOD FILES MANUALLY.
	# Core Files
	cp "${BIN_DIR}/VPVideoInject"																"/fs/mp/apps/fmods/"
	cp "${BIN_DIR}/VPVideoDetach"																"/fs/mp/apps/fmods/"
	chmod +x "/fs/mp/scripts/fmods/"*
	rm -f "/fs/mp/scripts/fmods/video_support.sh"
	cp "${SHELL_DIR}/video_support.sh"															"/fs/mp/scripts/fmods/"
	chmod +x "/fs/mp/apps/fmods/VPVideoInject"
	chmod +x "/fs/mp/apps/fmods/VPVideoDetach"
	chmod +x "/fs/mp/scripts/fmods/video_support.sh"
	# ford-MY20
	cp "${OTHER_DIR}/VideoPlayerPipe.qml"														"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/"
	cp "${OTHER_DIR}/ford-MY20/VideoPlaybackScreenInfoContent.qml"								"/fs/mp/fordhmi/qml/hmimedia/components/"
	cp "${OTHER_DIR}/ford-MY20/VideoTrackControlButtons.qml"									"/fs/mp/fordhmi/qml/hmimedia/components/"
	cp "${OTHER_DIR}/ford-MY20/bg_videocontrols_night.png"										"/fs/mp/fordhmi/qml/themes/ford-MY20/images/night/media/bg_videocontrols.png"
	cp "${OTHER_DIR}/ford-MY20/bg_videocontrols_day.png"										"/fs/mp/fordhmi/qml/themes/ford-MY20/images/day/media/bg_videocontrols.png"
	cp "${OTHER_DIR}/ford-MY20/PlaceholderCoverArt-Video.png"									"/fs/mp/fordhmi/qml/themes/ford-MY20/images/night/media/"
	cp "${OTHER_DIR}/ford-MY20/PlaceholderCoverArt-Video.png"									"/fs/mp/fordhmi/qml/themes/ford-MY20/images/day/media/"
	# +10inchL
	cp "${OTHER_DIR}/VideoPlayerPipe.qml"														"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+10inchL/"
	cp "${OTHER_DIR}/+10inchL/VideoPlaybackScreenInfoContent.qml"								"/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/VideoPlaybackScreenInfoContent.qml"
	cp "${OTHER_DIR}/+10inchL/VideoTrackControlButtons.qml"										"/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/VideoTrackControlButtons.qml"
	# +10inchP
	cp "${OTHER_DIR}/VideoPlayerPipe.qml"														"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+10inchP/"
	cp "${OTHER_DIR}/+10inchP/VideoPlaybackScreenInfoContent.qml"								"/fs/mp/fordhmi/qml/hmimedia/components/+10inchP/VideoPlaybackScreenInfoContent.qml"
	cp "${OTHER_DIR}/+10inchP/VideoTrackControlButtons.qml"										"/fs/mp/fordhmi/qml/hmimedia/components/+10inchP/VideoTrackControlButtons.qml"
	# +lincoln-MY20
	cp "${OTHER_DIR}/VideoPlayerPipe.qml"														"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+lincoln-MY20/"
	cp "${OTHER_DIR}/+lincoln-MY20/LincolnVideoPlaybackScreenInfoContent.qml"					"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/VideoPlaybackScreenInfoContent.qml"
	cp "${OTHER_DIR}/+lincoln-MY20/LincolnVideoTrackControlButtons.qml"							"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/VideoTrackControlButtons.qml"
	cp "${OTHER_DIR}/+lincoln-MY20/videomedia_player_bgr_main_night.png"						"/fs/mp/fordhmi/qml/themes/lincoln-MY20/images/night/media/videomedia_player_bgr_main.png"
	cp "${OTHER_DIR}/+lincoln-MY20/ideomedia_player_bgr_main_day.png"							"/fs/mp/fordhmi/qml/themes/lincoln-MY20/images/day/media/videomedia_player_bgr_main.png"
	# Below an example of a copy command to add new files
	# cp "${OTHER_DIR}/HomeClock.qml"															"/fs/mp/fordhmi/qml/hminavigation/homewidget/"
	# END BLOCK ADDING MOD FILES MANUALLY.
	output "Manually copying new file(s) from USB to SYNC 3 was successful!" 1
fi

#########################################################################################################################################################################
#	START BLOCK: Pre-dry-run hash check (added).																														#
#	Not a replacement for the dry-run below - patch --dry-run stays the actual, authoritative gate, since a hash match only proves the starting point is right, 		#
#	not that the rest of the diff is valid. This only turns a confident, specific finding into an earlier, clearer message; on anything we're not confident about it	# 
#	stays silent and leaves the existing generic dry-run failure message as the only thing the user sees, exactly as before.											#
#########################################################################################################################################################################

if [ "${PATCH:-0}" -eq 1 ] && [ "${UPDATE:-0}" -eq 0 ]; then
	set -A PRECHECK_HASHES
	PRECHECK_INDEX=0
	for fp in ${ALTERED_FILES[*]}; do
		if [ -f "${fp}" ]; then
			PRECHECK_HASH=$(sha1Hash "${fp}")
		else
			PRECHECK_HASH=""
		fi
		PRECHECK_HASHES[${PRECHECK_INDEX}]="${PRECHECK_HASH}"
		PRECHECK_INDEX=$((PRECHECK_INDEX + 1))
		if [ -n "${PRECHECK_HASH}" ]; then
			PRECHECK_STATE=$(getJsonHashState "${fp}" "${PRECHECK_HASH}" "${OTHER_DIR}/${HASH_JSON_FILE}")
			PRECHECK_RECORDED=$(getJsonRecordedInfo "${fp}" "${OTHER_DIR}/${HASH_JSON_FILE}")
			if [ "${PRECHECK_STATE}" = "stock" ]; then
				output "${fp##*/} checked: matches the expected stock hash." 1
				output "  live: ${PRECHECK_HASH} | recorded: ${PRECHECK_RECORDED}" 1
			elif [ -n "${PRECHECK_STATE}" ] && [ "${PRECHECK_STATE}" != "unknown" ]; then
				output "${fp##*/} already matches a known patched state (${PRECHECK_STATE})." 1
				output "  live: ${PRECHECK_HASH} | recorded: ${PRECHECK_RECORDED}" 1
				output "Some files were probably patched before." 1
			else
				output "${fp##*/} checked: no matching recorded hash found - continuing with the standard patch test." 1
				output "  live: ${PRECHECK_HASH} | recorded: ${PRECHECK_RECORDED}" 1
			fi
		fi
	done
	PRECHECK_UPDATE_JSON=$(
		idx=0
		for fp in ${ALTERED_FILES[*]}; do
			printf '%s\t%s\n' "${fp}" "${PRECHECK_HASHES[${idx}]}"
			idx=$((idx + 1))
		done | jq -R -s '
			split("\n") | map(select(. != "")) | map(split("\t"))
			| map({path: .[0], hash_before: (.[1] // "")})
		'
	)
	if [ -f "${MODS_JSON_PATH}" ] && [ -n "${PRECHECK_UPDATE_JSON}" ] && [ "${PRECHECK_UPDATE_JSON}" != "[]" ]; then
		jq --arg modName "${MODNAME}" --argjson updates "${PRECHECK_UPDATE_JSON}" '
			(.mods[] | select(.modName == $modName) | .modPatchedFiles) |=
				(map(. as $pf | (($updates[] | select(.path == $pf.path)) // null) as $u
					| if $u then ($pf + {hash_before: $u.hash_before}) else $pf end))
		' "${MODS_JSON_PATH}" > "/tmp/tmp.json"
		if [ -s "/tmp/tmp.json" ] && jq empty "/tmp/tmp.json" >/dev/null 2>&1; then
			mv "/tmp/tmp.json" 																	"${MODS_JSON_PATH}"
		else
			output "ERROR: JSON validation failed! Aborting." 1
			progress 100
			remount_ro.sh
			sync
			sync
			sync
			installationTerminated
		fi
	fi
fi

#	END BLOCK: Pre-dry-run hash check (added).

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK. 																																			#
#	Check if patch can be applied safely.																																#
#########################################################################################################################################################################

if [ "${PATCH:-0}" -eq 1 ] && [ "${UPDATE:-0}" -eq 0 ]; then
	if grep -q "${DEPENDENCY}" 																	"/fs/mp/etc/installed_mods.txt"; then
		if [ -f "${PATCH_DIR}/${MOD_DEPENDENCY_PATCH}" ]; then
			output "${DEPENDENCY} found: alternative patch will be tested." 1
			# Remove the # below if you are using a master.patch file. If not, DO NOT EDIT.
			if ! patch -l --dry-run -p0 < 														"${PATCH_DIR}/${MOD_DEPENDENCY_PATCH}" > "${USB_ROOT_DIR}/patch.log"; then
				progress 30
				output "This mod is not compatible with your SYNC 3 version!" 1
				output "It only supports SYNC 3 Build ${SYNC3_MIN_BUILD} or higher!" 1
				progress 100
				output "Please remove the USB stick to reboot." 1
				remount_ro.sh
				sync
				sync
				sync
				installationTerminated
			else
				if [ "${UNPATCH:-0}" -eq 0 ]; then
					progress 40
					output "${MOD_DEPENDENCY_PATCH} on SYNC3 for mod ${MODNAME} was tested successfully. Now installing..." 1
				fi
			fi
		else
			progress 40
			output "No patch file found - skipping standard patch step." 1
		fi
	else
		if [ -f "${PATCH_DIR}/${MOD_PATCH}" ]; then
			output "${DEPENDENCY} not found: default patch will be tested." 1
			# Remove the # below if you are using a master.patch file. If not, DO NOT EDIT.
			if ! patch -l --dry-run -p0 < 														"${PATCH_DIR}/${MOD_PATCH}" > "${USB_ROOT_DIR}/patch.log"; then
				progress 30
				output "This mod is not compatible with your SYNC 3 version!" 1
				output "It only supports SYNC 3 Build ${SYNC3_MIN_BUILD} or higher!" 1
				progress 100
				output "Please remove the USB stick to reboot." 1
				remount_ro.sh
				sync
				sync
				sync
				installationTerminated
			else
				if [ "${UNPATCH:-0}" -eq 0 ]; then
					progress 40
					output "${MOD_PATCH} for mod ${MODNAME} was tested successfully. Now installing..." 1
				fi
			fi
		else
			progress 40
			output "No patch file found - skipping standard patch step." 1
		fi
	fi
fi

#########################################################################################################################################################################
#	START BLOCK: Pre-dry-run hash check (added).																														#
#	Same reasoning as the install-side check above: informational only, never blocks, and the reverse dry-run below remains the real gate.								#
#########################################################################################################################################################################

if [ "${UNPATCH:-0}" -eq 1 ] && [ "${UPDATE:-0}" -eq 0 ]; then
	for fp in ${ALTERED_FILES[*]}; do
		if [ -f "${fp}" ]; then
			PRECHECK_HASH=$(sha1Hash "${fp}")
			PRECHECK_STATE=$(getJsonHashState "${fp}" "${PRECHECK_HASH}" "${OTHER_DIR}/${HASH_JSON_FILE}")
			PRECHECK_RECORDED=$(getJsonRecordedInfo "${fp}" "${OTHER_DIR}/${HASH_JSON_FILE}")
			if [ "${PRECHECK_STATE}" = "stock" ]; then
				output "${fp##*/} already matches the stock hash." 1
				output "  live: ${PRECHECK_HASH} | recorded: ${PRECHECK_RECORDED}" 1
				output "This file may already be reverted - there may be nothing to unpatch here." 1
			elif [ -n "${PRECHECK_STATE}" ] && [ "${PRECHECK_STATE}" != "unknown" ]; then
				output "${fp##*/} checked: matches the expected patched hash (${PRECHECK_STATE})." 1
				output "  live: ${PRECHECK_HASH} | recorded: ${PRECHECK_RECORDED}" 1
			else
				output "${fp##*/} checked: no matching recorded hash found - continuing with the standard unpatch test." 1
				output "  live: ${PRECHECK_HASH} | recorded: ${PRECHECK_RECORDED}" 1
			fi
		fi
	done
fi

#	END BLOCK: Pre-dry-run hash check (added).

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Check if Unpatch can be applied safely.																																#
#########################################################################################################################################################################

if [ "${UNPATCH:-0}" -eq 1 ] && [ "${UPDATE:-0}" -eq 0 ]; then
	APPLIED_VARIANT=$(detectAppliedPatch)
	if [ "${APPLIED_VARIANT}" = "with_dependency" ]; then
		USE_DEPENDENCY_PATCH=1
	elif [ "${APPLIED_VARIANT}" = "without_dependency" ]; then
		USE_DEPENDENCY_PATCH=0
	elif [ -n "${DEPENDENCY}" ] && grep -q "${DEPENDENCY}" 										"/fs/mp/etc/installed_mods.txt"; then
		USE_DEPENDENCY_PATCH=1
	else
		USE_DEPENDENCY_PATCH=0
	fi
	if [ "${USE_DEPENDENCY_PATCH}" -eq 1 ] && [ "${RESTORE:-0}" -eq 0 ]; then
		if [ -f "${PATCH_DIR}/${MOD_DEPENDENCY_PATCH}" ]; then
			output "${DEPENDENCY} found: alternative patch will be tested." 1
			# Remove the # below if you are using a master.patch file. If not, DO NOT EDIT.
			if ! patch -l --dry-run -R -p0 < 													"${PATCH_DIR}/${MOD_DEPENDENCY_PATCH}" > "${USB_ROOT_DIR}/unpatch.log"; then
				progress 30
				output "This mod is not compatible with your SYNC 3 version!" 1
				output "It only supports SYNC 3 Build ${SYNC3_MIN_BUILD} or higher!" 1
				progress 100
				output "Please remove the USB stick to reboot." 1
				remount_ro.sh
				sync
				sync
				sync
				installationTerminated
			else
				if [ "${PATCH:-0}" -eq 0 ]; then
					progress 40
					output "Unpatch of ${MOD_DEPENDENCY_PATCH} on SYNC3 for mod ${MODNAME} was tested successfully. Now unpatching..." 1
				fi
			fi
		else
			progress 40
			output "No patch file found - skipping standard unpatch step." 1
		fi
	else
		if [ -f "${PATCH_DIR}/${MOD_PATCH}" ]; then
			output "${DEPENDENCY} not found: default patch will be tested." 1
			# Remove the # below if you are using a master.patch file. If not, DO NOT EDIT.
			if ! patch -l --dry-run -R -p0 < 													"${PATCH_DIR}/${MOD_PATCH}" > "${USB_ROOT_DIR}/unpatch.log"; then
				progress 30
				output "This mod is not compatible with your SYNC 3 version!" 1
				output "It only supports SYNC 3 Build ${SYNC3_MIN_BUILD} or higher!" 1
				progress 100
				output "Please remove the USB stick to reboot." 1
				remount_ro.sh
				sync
				sync
				sync
				installationTerminated
			else
				if [ "${PATCH:-0}" -eq 0 ]; then
					progress 40
					output "Unpatch of ${MOD_PATCH} for mod ${MODNAME} was tested successfully. Now unpatching..." 1
				fi
			fi
		else
			progress 40
			output "No patch file found - skipping standard unpatch step." 1
		fi
	fi
fi

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Apply Patch.																																						#
#########################################################################################################################################################################

if [ "${PATCH:-0}" -eq 1 ] && [ "${UPDATE:-0}" -eq 0 ]; then
	if grep -q "${MDEPENDENCY}" 																"/fs/mp/fordhmi/qml/hmicustomapps/apps.json"; then
		INSTALLATION_DIR="${FMODS_MODS_DIR}/${MODNAME}"
		INSTALL_FILE="install.sh"
		UNINSTALL_FILE="uninstall.sh"
		if [ -f "${MODS_JSON_PATH}" ]; then
			for subdir in backup icon new new/day new/night patch install uninstall; do			mkdir -p "${INSTALLATION_DIR}/${subdir}"; done
			for subdir in new/ford-MY20 new/+10inchL new/+10inchP new/+lincoln-MY20; do			mkdir -p "${INSTALLATION_DIR}/${subdir}"; done
			progress 50
			output "Loop Backup Start..." 1
			for fp in ${ALTERED_FILES[*]}; do
				filename="${fp##*/}"
				case "${fp}" in
					/fs/mp/fordhmi/qml/themes/ford-MY20/*) modfolder="0" ;;
					/fs/mp/fordhmi/qml/themes/ford-10P-MY20/*) modfolder="+10inchP" ;;
					/fs/mp/fordhmi/qml/themes/lincoln-10L-MY20/*) modfolder="+10inchL" ;;
					/fs/mp/fordhmi/qml/themes/lincoln-MY20/*) modfolder="+lincoln-MY20" ;;
					/fs/mp/fordhmi/qml/themes/root-theme/*) modfolder="root-theme" ;;
					/fs/mp/fordhmi/qml/themes/*) modfolder="0" ;;
					*)
						parentdir="${fp%/*}"
						lastseg="${parentdir##*/}"
						case "${lastseg}" in
							+*) modfolder="${lastseg}" ;;
							*) modfolder="0" ;;
						esac
						;;
				esac
				if [ ! -f "${fp}.orig" ]; then
					if [ ! "${modfolder}" = "0" ]; then
						output "No orig, folder found..." 1
						if [ -f "${fp}" ]; then
							mkdir -p "${INSTALLATION_DIR}/backup/${modfolder}"
							cp "${fp}"															"${INSTALLATION_DIR}/backup/${modfolder}/${filename}"
						fi
					else
						output "No orig, no folder found..." 1
						if [ -f "${fp}" ]; then
							cp "${fp}"															"${INSTALLATION_DIR}/backup/${filename}"
						fi
					fi
				else
					if [ ! "${modfolder}" = "0" ]; then
						output "orig found, folder found..." 1
						if [ -f "${BACKUP_DIR}/${modfolder}/${filename}" ]; then
							mkdir -p "${INSTALLATION_DIR}/backup/${modfolder}"
							cp "${BACKUP_DIR}/${modfolder}/${filename}"							"${INSTALLATION_DIR}/backup/${modfolder}/${filename}"
						fi
					else
						output "orig found, no folder found..." 1
						if [ -f "${BACKUP_DIR}/${filename}" ]; then
							cp "${BACKUP_DIR}/${filename}"										"${INSTALLATION_DIR}/backup/${filename}"
						fi
					fi
				fi
			done
			progress 55
			output "Loop Backup End ..." 1
			cp "${ICON_DIR}/Icon_active.png"													"${INSTALLATION_DIR}/icon/"
			cp "${ICON_DIR}/Icon_activepressed.png"												"${INSTALLATION_DIR}/icon/"
			cp "${ICON_DIR}/Modinfo.txt"														"${INSTALLATION_DIR}/icon/"
			cp "${SHELL_DIR}/${INSTALL_FILE}"													"${INSTALLATION_DIR}/install/"
			cp "${SHELL_DIR}/${UNINSTALL_FILE}"													"${INSTALLATION_DIR}/uninstall/"
			if [ -f "${OTHER_DIR}/original_hashes.txt" ]; then
				cp "${OTHER_DIR}/original_hashes"*.txt											"${INSTALLATION_DIR}/new/"
			fi
			if [ -f "${OTHER_DIR}/original_hashes.json" ]; then
				cp "${OTHER_DIR}/original_hashes.json"											"${INSTALLATION_DIR}/new/"
			fi
			if [ -f "${PATCH_DIR}/${MOD_PATCH}" ]; then
				cp "${PATCH_DIR}/${MOD_PATCH}"													"${INSTALLATION_DIR}/patch/"
			fi
			# START BLOCK ADDING MOD FILES TO INSTALLATION_DIR.
			if [ -f "${PATCH_DIR}/${MOD_DEPENDENCY_PATCH}" ]; then
				cp "${PATCH_DIR}/${MOD_DEPENDENCY_PATCH}"										"${INSTALLATION_DIR}/patch/"
			fi
			# Global
			cp "${BIN_DIR}/VPVideoInject"														"${INSTALLATION_DIR}/new/"
			cp "${BIN_DIR}/VPVideoDetach"														"${INSTALLATION_DIR}/new/"
			cp "${SHELL_DIR}/video_support.sh"													"${INSTALLATION_DIR}/new/"
			cp "${OTHER_DIR}/VideoPlayerPipe.qml"												"${INSTALLATION_DIR}/new/"
			# ford-MY20
			cp "${OTHER_DIR}/ford-MY20/VideoPlaybackScreenInfoContent.qml"						"${INSTALLATION_DIR}/new/ford-MY20/"
			cp "${OTHER_DIR}/ford-MY20/VideoTrackControlButtons.qml"							"${INSTALLATION_DIR}/new/ford-MY20/"
			cp "${OTHER_DIR}/ford-MY20/bg_videocontrols_night.png"								"${INSTALLATION_DIR}/new/ford-MY20/"
			cp "${OTHER_DIR}/ford-MY20/bg_videocontrols_day.png"								"${INSTALLATION_DIR}/new/ford-MY20/"
			cp "${OTHER_DIR}/ford-MY20/PlaceholderCoverArt-Video.png"							"${INSTALLATION_DIR}/new/ford-MY20/"
			# +10inchL
			cp "${OTHER_DIR}/VideoPlayerPipe.qml"												"${INSTALLATION_DIR}/new/+10inchL/"
			cp "${OTHER_DIR}/+10inchL/VideoPlaybackScreenInfoContent.qml"						"${INSTALLATION_DIR}/new/+10inchL/"
			cp "${OTHER_DIR}/+10inchL/VideoTrackControlButtons.qml"				 				"${INSTALLATION_DIR}/new/+10inchL/"
			# +10inchP
			cp "${OTHER_DIR}/VideoPlayerPipe.qml"												"${INSTALLATION_DIR}/new/+10inchP/"
			cp "${OTHER_DIR}/+10inchP/VideoPlaybackScreenInfoContent.qml"						"${INSTALLATION_DIR}/new/+10inchP/"
			cp "${OTHER_DIR}/+10inchP/VideoTrackControlButtons.qml"								"${INSTALLATION_DIR}/new/+10inchP/"
			# +lincoln-MY20
			cp "${OTHER_DIR}/+lincoln-MY20/LincolnVideoPlaybackScreenInfoContent.qml"			"${INSTALLATION_DIR}/new/+lincoln-MY20/"
			cp "${OTHER_DIR}/+lincoln-MY20/LincolnVideoTrackControlButtons.qml"					"${INSTALLATION_DIR}/new/+lincoln-MY20/"
			cp "${OTHER_DIR}/+lincoln-MY20/videomedia_player_bgr_main_night.png"				"${INSTALLATION_DIR}/new/+lincoln-MY20/"
			cp "${OTHER_DIR}/+lincoln-MY20/videomedia_player_bgr_main_day.png"					"${INSTALLATION_DIR}/new/+lincoln-MY20/"
			# Below an example of a copy command to add new files
			# cp "${OTHER_DIR}/HomeClock.qml"													"${INSTALLATION_DIR}/new/"
			# END BLOCK ADDING MOD FILES TO INSTALLATION_DIR.
			progress 60
			output "Copy uninstall.sh and (master.patch) files..." 1
			MOD_PATCHED_FILES_JSON=$(
				idx=0
				for fp in ${ALTERED_FILES[*]}; do
					printf '%s\t%s\n' "${fp}" "${PRECHECK_HASHES[${idx}]}"
					idx=$((idx + 1))
				done | jq -R -s '
					split("\n") | map(select(. != "")) | map(split("\t"))
					| map({path: .[0], hash_before: (.[1] // ""), hash_after: ""})
				'
			)
			if [ -z "${MOD_PATCHED_FILES_JSON}" ]; then
				MOD_PATCHED_FILES_JSON='[]'
			fi
			if ! grep -q "${MODNAME}" 															"${MODS_JSON_PATH}"; then
				output "${MODNAME} not detected. Adding JSON entry ..." 1
				if [ -f "${INSTALLATION_DIR}/icon/Modinfo.txt" ]; then
					MOD_INFO="/icon/Modinfo.txt"
				else
					MOD_INFO=""
				fi
				jq --arg modName "${MODNAME}" \
					--arg modIcon "Icon" \
					--arg modInfo "${MOD_INFO}" \
					--arg modAuthor "${AUTHOR}" \
					--arg modVersion "${VERSION}" \
					--arg modUninstallFile "installed" \
					--arg timestamp "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" \
					--argjson modPatchedFiles "${MOD_PATCHED_FILES_JSON}" \
					'.mods += [{"modName": $modName, "modIcon": $modIcon, "modInfo": $modInfo, "modAuthor": $modAuthor, "modVersion": $modVersion, "modUninstallFile": $modUninstallFile, "timestamp": $timestamp, "modPatchedFiles": $modPatchedFiles}]' \
					"${MODS_JSON_PATH}" > "/tmp/tmp.json"
				if [ -s "/tmp/tmp.json" ] && jq empty "/tmp/tmp.json" >/dev/null 2>&1; then
					mv "/tmp/tmp.json" 															"${MODS_JSON_PATH}"
				else
					output "ERROR: JSON validation failed! Aborting." 1
					progress 100
					remount_ro.sh
					sync
					sync
					sync
					installationTerminated
				fi
			else
				output "${MODNAME} detected. Changing JSON entry ..." 1
				jq --arg modName "${MODNAME}" --arg timestamp "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" '
					(.mods[] | select(.modName == $modName)) |= (.modUninstallFile = "installed" | .timestamp = $timestamp)
				' "${MODS_JSON_PATH}" > "/tmp/tmp.json"
				if [ -s "/tmp/tmp.json" ] && jq empty "/tmp/tmp.json" >/dev/null 2>&1; then
					mv "/tmp/tmp.json" 															"${MODS_JSON_PATH}"
				else
					output "ERROR: JSON validation failed! Aborting." 1
					progress 100
					remount_ro.sh
					sync
					sync
					sync
					installationTerminated
				fi
			fi
		fi
	fi
	if grep -q "${DEPENDENCY}" 																	"/fs/mp/etc/installed_mods.txt"; then
		if [ -f "${PATCH_DIR}/${MOD_DEPENDENCY_PATCH}" ]; then
			output "${DEPENDENCY} found: alternative patch will be applied." 1
			patch -l -b -p0 < 																	"${PATCH_DIR}/${MOD_DEPENDENCY_PATCH}"
			progress 65
			output "Install of ${MOD_DEPENDENCY_PATCH} for ${MODNAME} was successful." 1
		else
			progress 65
			output "No patch file found - skipping standard patch step." 1
		fi
	else
		if [ -f "${PATCH_DIR}/${MOD_PATCH}" ]; then
			output "${DEPENDENCY} not found: default patch will be applied." 1
			patch -l -b -p0 < 																	"${PATCH_DIR}/${MOD_PATCH}"
			progress 65
			output "Install of ${MOD_PATCH} for ${MODNAME} was successful." 1
		else
			progress 65
			output "No patch file found - skipping standard patch step." 1
		fi
	fi
	# START BLOCK: Post-patch hash check (added) - backfills hash_after into mods.json
	# for this mod's modPatchedFiles entries, mirroring the pre-patch hash_before capture
	# above. Runs unconditionally (not just when a patch file was applied) so ALTERED_FILES
	# entries touched by MANUAL copy steps still get a real hash_after recorded.
	set -A POSTCHECK_HASHES
	POSTCHECK_INDEX=0
	for fp in ${ALTERED_FILES[*]}; do
		if [ -f "${fp}" ]; then
			POSTCHECK_HASHES[${POSTCHECK_INDEX}]=$(sha1Hash "${fp}")
		else
			POSTCHECK_HASHES[${POSTCHECK_INDEX}]=""
		fi
		POSTCHECK_INDEX=$((POSTCHECK_INDEX + 1))
	done
	POSTCHECK_UPDATE_JSON=$(
		idx=0
		for fp in ${ALTERED_FILES[*]}; do
			printf '%s\t%s\n' "${fp}" "${POSTCHECK_HASHES[${idx}]}"
			idx=$((idx + 1))
		done | jq -R -s '
			split("\n") | map(select(. != "")) | map(split("\t"))
			| map({path: .[0], hash_after: (.[1] // "")})
		'
	)
	if [ -f "${MODS_JSON_PATH}" ] && [ -n "${POSTCHECK_UPDATE_JSON}" ] && [ "${POSTCHECK_UPDATE_JSON}" != "[]" ]; then
		jq --arg modName "${MODNAME}" --argjson updates "${POSTCHECK_UPDATE_JSON}" '
			(.mods[] | select(.modName == $modName) | .modPatchedFiles) |=
				(map(. as $pf | (($updates[] | select(.path == $pf.path)) // null) as $u
					| if $u then ($pf + {hash_after: $u.hash_after}) else $pf end))
		' "${MODS_JSON_PATH}" > "/tmp/tmp.json"
		if [ -s "/tmp/tmp.json" ] && jq empty "/tmp/tmp.json" >/dev/null 2>&1; then
			mv "/tmp/tmp.json" 																	"${MODS_JSON_PATH}"
		else
			output "ERROR: JSON validation failed! Aborting." 1
			progress 100
			remount_ro.sh
			sync
			sync
			sync
			installationTerminated
		fi
	fi
	POSTCHECK_INDEX=0
	for fp in ${ALTERED_FILES[*]}; do
		POSTCHECK_HASH="${POSTCHECK_HASHES[${POSTCHECK_INDEX}]}"
		if [ -n "${POSTCHECK_HASH}" ]; then
			POSTCHECK_STATE=$(getJsonHashState "${fp}" "${POSTCHECK_HASH}" "${OTHER_DIR}/${HASH_JSON_FILE}")
			POSTCHECK_RECORDED=$(getJsonRecordedInfo "${fp}" "${OTHER_DIR}/${HASH_JSON_FILE}")
			if [ -n "${POSTCHECK_STATE}" ] && [ "${POSTCHECK_STATE}" != "unknown" ] && [ "${POSTCHECK_STATE}" != "stock" ]; then
				output "${fp##*/} after patch: confirmed matches (${POSTCHECK_STATE})." 1
				output "  live: ${POSTCHECK_HASH} | recorded: ${POSTCHECK_RECORDED}" 1
			else
				output "${fp##*/} after patch: hash is ${POSTCHECK_STATE:-unknown} - please verify." 1
				output "  live: ${POSTCHECK_HASH} | recorded: ${POSTCHECK_RECORDED}" 1
			fi
		fi
		POSTCHECK_INDEX=$((POSTCHECK_INDEX + 1))
	done
	# END BLOCK: Post-patch hash check (added).
	for NEWPATH in ${ALTERED_FILES[*]}; do
		NEWNAME="${NEWPATH##*/}"
		case "${NEWPATH}" in
			/fs/mp/fordhmi/qml/themes/ford-MY20/*) NEWMODFOLDER="0" ;;
			/fs/mp/fordhmi/qml/themes/ford-10P-MY20/*) NEWMODFOLDER="+10inchP" ;;
			/fs/mp/fordhmi/qml/themes/lincoln-10L-MY20/*) NEWMODFOLDER="+10inchL" ;;
			/fs/mp/fordhmi/qml/themes/lincoln-MY20/*) NEWMODFOLDER="+lincoln-MY20" ;;
			/fs/mp/fordhmi/qml/themes/root-theme/*) NEWMODFOLDER="root-theme" ;;
			/fs/mp/fordhmi/qml/themes/*) NEWMODFOLDER="0" ;;
			*)
				NEWPARENT="${NEWPATH%/*}"
				NEWLASTSEG="${NEWPARENT##*/}"
				case "${NEWLASTSEG}" in
					+*) NEWMODFOLDER="${NEWLASTSEG}" ;;
					*) NEWMODFOLDER="0" ;;
				esac
				;;
		esac
		if [ ! "${NEWMODFOLDER}" = "0" ]; then
			NEW_TARGET_DIR="${NEW_DIR}/${NEWMODFOLDER}"
		else
			NEW_TARGET_DIR="${NEW_DIR}"
		fi
		mkdir -p "${NEW_TARGET_DIR}"
		if [ ! -f "${NEW_TARGET_DIR}/${NEWNAME}" ] && [ -f "${NEWPATH}" ] && [ -f "${NEWPATH}.orig" ]; then
			cp "${NEWPATH}"																		"${NEW_TARGET_DIR}/${NEWNAME}"
		fi
	done
	# START BLOCK COPYING MOD FILES TO SYNC3 AFTER PATCHING.
	# Core Files
	cp "${BIN_DIR}/VPVideoInject"																"/fs/mp/apps/fmods/"
	cp "${BIN_DIR}/VPVideoDetach"																"/fs/mp/apps/fmods/"
	chmod +x "/fs/mp/scripts/fmods/"*
	rm -f "/fs/mp/scripts/fmods/video_support.sh"
	cp "${SHELL_DIR}/video_support.sh"															"/fs/mp/scripts/fmods/"
	chmod +x "/fs/mp/apps/fmods/VPVideoInject"
	chmod +x "/fs/mp/apps/fmods/VPVideoDetach"
	chmod +x "/fs/mp/scripts/fmods/video_support.sh"
	# ford-MY20
	cp "${OTHER_DIR}/VideoPlayerPipe.qml"														"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/"
	cp "${OTHER_DIR}/ford-MY20/VideoPlaybackScreenInfoContent.qml"								"/fs/mp/fordhmi/qml/hmimedia/components/"
	cp "${OTHER_DIR}/ford-MY20/VideoTrackControlButtons.qml"									"/fs/mp/fordhmi/qml/hmimedia/components/"
	cp "${OTHER_DIR}/ford-MY20/bg_videocontrols_night.png"										"/fs/mp/fordhmi/qml/themes/ford-MY20/images/night/media/bg_videocontrols.png"
	cp "${OTHER_DIR}/ford-MY20/bg_videocontrols_day.png"										"/fs/mp/fordhmi/qml/themes/ford-MY20/images/day/media/bg_videocontrols.png"
	cp "${OTHER_DIR}/ford-MY20/PlaceholderCoverArt-Video.png"									"/fs/mp/fordhmi/qml/themes/ford-MY20/images/night/media/"
	cp "${OTHER_DIR}/ford-MY20/PlaceholderCoverArt-Video.png"									"/fs/mp/fordhmi/qml/themes/ford-MY20/images/day/media/"
	# +10inchL
	cp "${OTHER_DIR}/VideoPlayerPipe.qml"														"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+10inchL/"
	cp "${OTHER_DIR}/+10inchL/VideoPlaybackScreenInfoContent.qml"								"/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/VideoPlaybackScreenInfoContent.qml"
	cp "${OTHER_DIR}/+10inchL/VideoTrackControlButtons.qml"						 				"/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/VideoTrackControlButtons.qml"
	# +10inchP
	cp "${OTHER_DIR}/VideoPlayerPipe.qml"														"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+10inchP/"
	cp "${OTHER_DIR}/+10inchP/VideoPlaybackScreenInfoContent.qml"								"/fs/mp/fordhmi/qml/hmimedia/components/+10inchP/VideoPlaybackScreenInfoContent.qml"
	cp "${OTHER_DIR}/+10inchP/VideoTrackControlButtons.qml"										"/fs/mp/fordhmi/qml/hmimedia/components/+10inchP/VideoTrackControlButtons.qml"
	# +lincoln-MY20
	cp "${OTHER_DIR}/VideoPlayerPipe.qml"														"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+lincoln-MY20/"
	cp "${OTHER_DIR}/+lincoln-MY20/LincolnVideoPlaybackScreenInfoContent.qml"					"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/VideoPlaybackScreenInfoContent.qml"
	cp "${OTHER_DIR}/+lincoln-MY20/LincolnVideoTrackControlButtons.qml"							"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/VideoTrackControlButtons.qml"
	cp "${OTHER_DIR}/+lincoln-MY20/videomedia_player_bgr_main_night.png"						"/fs/mp/fordhmi/qml/themes/lincoln-MY20/images/night/media/videomedia_player_bgr_main.png"
	cp "${OTHER_DIR}/+lincoln-MY20/ideomedia_player_bgr_main_day.png"							"/fs/mp/fordhmi/qml/themes/lincoln-MY20/images/day/media/videomedia_player_bgr_main.png"	
	# Below an example of a copy command to add new files
	# cp "${OTHER_DIR}/HomeClock.qml"															"/fs/mp/fordhmi/qml/hminavigation/homewidget/"
	# END BLOCK COPYING MOD FILES TO SYNC3 AFTER PATCHING.
	if grep -q "${MDEPENDENCY}" 																"/fs/mp/fordhmi/qml/hmicustomapps/apps.json"; then
		if [ -f "${MODS_JSON_PATH}" ]; then
			progress 70
			output "Loop New Start..." 1
			for fp in ${ALTERED_FILES[*]}; do
				filename="${fp##*/}"
				case "${fp}" in
					/fs/mp/fordhmi/qml/themes/ford-MY20/*) modfolder="0" ;;
					/fs/mp/fordhmi/qml/themes/ford-10P-MY20/*) modfolder="+10inchP" ;;
					/fs/mp/fordhmi/qml/themes/lincoln-10L-MY20/*) modfolder="+10inchL" ;;
					/fs/mp/fordhmi/qml/themes/lincoln-MY20/*) modfolder="+lincoln-MY20" ;;
					/fs/mp/fordhmi/qml/themes/root-theme/*) modfolder="root-theme" ;;
					/fs/mp/fordhmi/qml/themes/*) modfolder="0" ;;
					*)
						parentdir="${fp%/*}"
						lastseg="${parentdir##*/}"
						case "${lastseg}" in
							+*) modfolder="${lastseg}" ;;
							*) modfolder="0" ;;
						esac
						;;
				esac
				if [ ! -f "${fp}.orig" ]; then
					if [ ! "${modfolder}" = "0" ]; then
						output "${fp}: No orig, folder found..." 0.1
						if [ -f "${NEW_DIR}/${modfolder}/${filename}" ]; then
							mkdir -p "${INSTALLATION_DIR}/new/${modfolder}"
							cp "${fp}: ${NEW_DIR}/${modfolder}/${filename}"						"${INSTALLATION_DIR}/new/${modfolder}/${filename}"
						fi
					else
						output "${fp}: No orig, no folder found..." 0.1
						if [ -f "${NEW_DIR}/${filename}" ]; then
							cp "${NEW_DIR}/${filename}"											"${INSTALLATION_DIR}/new/${filename}"
						fi
					fi
				else
					if [ ! "${modfolder}" = "0" ]; then
						output "${fp}: orig found, folder found..." 0.1
						if [ -f "${fp}" ]; then
							mkdir -p "${INSTALLATION_DIR}/new/${modfolder}"
							cp "${fp}"															"${INSTALLATION_DIR}/new/${modfolder}/${filename}"
						fi
					else
						output "${fp}: orig found, no folder found..." 0.1
						if [ -f "${fp}" ]; then
							cp "${fp}"															"${INSTALLATION_DIR}/new/${filename}"
						fi
					fi
				fi
			done
			progress 80
			output "Loop New End ..." 1
		fi
	fi
else
	if [ "${UNPATCH:-0}" -eq 0 ]; then
		progress 80
		output "Manual install or restore..." 1
	fi
fi

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Apply Unpatch.																																						#
#########################################################################################################################################################################

if [ "${UNPATCH:-0}" -eq 1 ] && [ "${UPDATE:-0}" -eq 0 ]; then
	APPLIED_VARIANT=$(detectAppliedPatch)
	if [ "${APPLIED_VARIANT}" = "with_dependency" ]; then
		USE_DEPENDENCY_PATCH=1
	elif [ "${APPLIED_VARIANT}" = "without_dependency" ]; then
		USE_DEPENDENCY_PATCH=0
	elif [ -n "${DEPENDENCY}" ] && grep -q "${DEPENDENCY}" 										"/fs/mp/etc/installed_mods.txt"; then
		USE_DEPENDENCY_PATCH=1
	else
		USE_DEPENDENCY_PATCH=0
	fi
	if [ "${USE_DEPENDENCY_PATCH}" -eq 1 ] && [ "${RESTORE:-0}" -eq 0 ]; then
		if [ -f "${PATCH_DIR}/${MOD_DEPENDENCY_PATCH}" ]; then
			output "${DEPENDENCY} found: alternative patch will be applied." 1
			patch -l -b -R -p0 < 																"${PATCH_DIR}/${MOD_DEPENDENCY_PATCH}"
		else
			output "No patch file found - skipping standard unpatch step." 1
		fi
	else
		if [ -f "${PATCH_DIR}/${MOD_PATCH}" ]; then
			output "${DEPENDENCY} not found: default patch will be applied." 1
			patch -l -b -R -p0 < 																"${PATCH_DIR}/${MOD_PATCH}"
		else
			output "No patch file found - skipping standard unpatch step." 1
		fi
	fi
	for UNPATCHPATH in ${ALTERED_FILES[*]}; do
		UNPATCHNAME="${UNPATCHPATH##*/}"
		if [ ! -f "${BACKUP_DIR}/${UNPATCHNAME}" ]; then
			cp "${UNPATCHPATH}"																	"${BACKUP_DIR}/"
		fi
	done
	# START BLOCK REMOVING OTHER FILES AFTER UNPATCH.
	chmod a+x "/fs/mp/apps/fmods/"*
	rm -f "/fs/mp/apps/fmods/VPVideoInject"
	rm -f "/fs/mp/apps/fmods/VPVideoDetach"
	rm -f "/fs/mp/fordhmi/qml/hmimedia/components/VideoPlaybackScreenInfoContent.qml"
	rm -f "/fs/mp/fordhmi/qml/hmimedia/components/VideoTrackControlButtons.qml"
	rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/VideoPlayerPipe.qml"
	rm -f "/fs/mp/fordhmi/qml/themes/ford-MY20/images/night/media/bg_videocontrols.png"
	rm -f "/fs/mp/fordhmi/qml/themes/ford-MY20/images/night/media/PlaceholderCoverArt-Video.png"
	rm -f "/fs/mp/fordhmi/qml/themes/ford-MY20/images/day/media/bg_videocontrols.png"
	rm -f "/fs/mp/fordhmi/qml/themes/ford-MY20/images/day/media/PlaceholderCoverArt-Video.png"
	rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+10inchL/VideoPlayerPipe.qml"
	rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/VideoPlaybackScreenInfoContent.qml"
	rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/VideoTrackControlButtons.qml"
	rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+10inchP/VideoPlayerPipe.qml"
	rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+10inchP/VideoPlaybackScreenInfoContent.qml"
	rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+10inchP/VideoTrackControlButtons.qml"
	rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/VideoPlaybackScreenInfoContent.qml"
	rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/VideoTrackControlButtons.qml"
	rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+lincoln-MY20/VideoPlayerPipe.qml"
	rm -f "/fs/mp/fordhmi/qml/themes/lincoln-MY20/images/night/media/videomedia_player_bgr_main.png"
	rm -f "/fs/mp/fordhmi/qml/themes/lincoln-MY20/images/day/media/videomedia_player_bgr_main.png"
	# Remove video_support.sh from folder: /fs/mp/scripts/
	chmod a+x "/fs/mp/scripts/fmods/"*
	rm -f "/fs/mp/scripts/fmods/video_support.sh"
	# Below an example of a remove command to delete added files
	# rm -f "/fs/mp/fordhmi/qml/hminavigation/homewidget/HomeClock.qml"
	# END BLOCK REMOVING OTHER FILES AFTER UNPATCH.
	if grep -q "${MODNAME}" 																	"${MODS_JSON_PATH}"; then
		output "${MODNAME} detected. Changing JSON entry ..." 1
		jq --arg modName "${MODNAME}" '(.mods[] | select(.modName == $modName)).modUninstallFile = "deleted"' "${MODS_JSON_PATH}" > "/tmp/tmp.json"
		if [ -s "/tmp/tmp.json" ] && jq empty "/tmp/tmp.json" >/dev/null 2>&1; then
			mv "/tmp/tmp.json" 																	"${MODS_JSON_PATH}"
		else
			output "ERROR: JSON validation failed! Aborting." 1
			progress 100
			remount_ro.sh
			sync
			sync
			sync
			installationTerminated
		fi
	fi
	progress 80
	if [ -f "${PATCH_DIR}/${MOD_PATCH}" ]; then
		output "Unpatch on SYNC3 of ${MOD_PATCH} for ${MODNAME} was successful." 1
	else
		output "No patch file found - skipping standard unpatch step." 1
	fi
else
	if [ "${PATCH:-0}" -eq 0 ]; then
		progress 80
		output "Manual install or restore..." 1
	fi
fi

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Add your mod inside the list of installed mods.																														#
#########################################################################################################################################################################

if [ "${PATCH:-0}" -eq 1 ] && [ "${UPDATE:-0}" -eq 0 ]; then
	progress 90
	output "Adding ${MODNAME} inside the list of installed mods..." 1
	# Remove the # below if your mod uses the patching system and you want it to be listed so it can not be installed again. If not, DO NOT EDIT.
	if ! grep -q "${MODNAME}" 																	"/fs/mp/etc/installed_mods.txt"; then
		echo "${MODNAME}" >> 																	"/fs/mp/etc/installed_mods.txt"
	fi
fi

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Remount the SYNC 3 OS partition with READ ONLY permissions.																											#
#########################################################################################################################################################################

progress 95
output "Setting RO permissions to FS..." 1
remount_ro.sh
sync
sync
sync

#########################################################################################################################################################################
#	DO NOT EDIT THIS BLOCK.																																				#
#	Display installation success message.																																#
#########################################################################################################################################################################

progress 100
output "Installation completed. Please remove the USB stick to reboot." 1
installationTerminated
