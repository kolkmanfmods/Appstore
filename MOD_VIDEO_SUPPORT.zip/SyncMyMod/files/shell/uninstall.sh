#!/bin/sh
# shellcheck disable=SC2086 disable=SC3006 disable=SC3054
#########################################################################################################################################################################
#	Installation script for Video Player					  																											#
#########################################################################################################################################################################
#																																										#
#					AAA								   TTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEE			   AAA				 MMMMMMMM				MMMMMMMM	#
#				   A:::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			  A:::A				 M:::::::M			   M:::::::M	#
#				  A:::::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			 A:::::A			 M::::::::M			  M::::::::M	#
#				 A:::::::A							   T:::::TT:::::::TT:::::TEE::::::EEEEEEEEE::::E			A:::::::A			 M:::::::::M		 M:::::::::M	#
#				A:::::::::A							   TTTTTT  T:::::T  TTTTTT  E:::::E		  EEEEEE		   A:::::::::A			 M::::::::::M		M::::::::::M	#
#			   A:::::A:::::A								   T:::::T			E:::::E			 			  A:::::A:::::A			 M:::::::::::M	   M:::::::::::M	#
#			  A:::::A A:::::A								   T:::::T			E::::::EEEEEEEEEE			 A:::::A A:::::A		 M:::::::M::::M   M::::M:::::::M	#
#			 A:::::A   A:::::A		   ---------------		   T:::::T			E:::::::::::::::E			A:::::A   A:::::A		 M::::::M M::::M M::::M M::::::M	#
#			A:::::A		A:::::A		   -:::::::::::::-		   T:::::T			E:::::::::::::::E		   A:::::A	   A:::::A		 M::::::M  M::::M::::M  M::::::M	#
#		   A:::::AAAAAAAAA:::::A	   ---------------		   T:::::T			E::::::EEEEEEEEEE		  A:::::AAAAAAAAA:::::A		 M::::::M   M:::::::M   M::::::M	#
#		  A:::::::::::::::::::::A							   T:::::T			E:::::E			 		 A:::::::::::::::::::::A	 M::::::M	 M:::::M	M::::::M	#
#		 A:::::AAAAAAAAAAAAA:::::A							   T:::::T			E:::::E		  EEEEEE	A:::::AAAAAAAAAAAAA:::::A	 M::::::M	  MMMMM		M::::::M	#
#		A:::::A				A:::::A							 TT:::::::TT	  EE::::::EEEEEEEE:::::E   A:::::A			   A:::::A   M::::::M				M::::::M	#
#	   A:::::A				 A:::::A						 T:::::::::T	  E::::::::::::::::::::E  A:::::A				A:::::A  M::::::M				M::::::M	#
#	  A:::::A				  A:::::A						 T:::::::::T	  E::::::::::::::::::::E A:::::A				 A:::::A M::::::M				M::::::M	#
#	 AAAAAAA				   AAAAAAA						 TTTTTTTTTTT	  EEEEEEEEEEEEEEEEEEEEEEAAAAAAA					 AAAAAAAMMMMMMMM				MMMMMMMM	#
#																																										#
#########################################################################################################################################################################
#																																										#
#							 ###############																															#
#							#				#																															#
#						  #					 #					M			 M						 D			 														#
#				 #########	   FFFFFFFFFFF	  #########			MM			MM						 D			 														#
#						#	   FF			   #				M M		   M M   OOOOOOOO	DDDDDDD D   SSSSSSSS		   NN		N  EEEEEEEEEE  TTTTTTTTTT			#
#			############	   FF FFFF			############	M  M	  M  M  O		 O  D		 D  S				   N NN		N  EE			   TT				#
#						#	   FF			   #				M   M	 M   M  O		 O  D		 D   SSSSSSSS		   N   NN   N  EEEEEEEEEE	   TT				#
#				 #########	   FF			  #########			M	  M M	 M  O		 O  D		 D			 S   ###   N	 NN N  EE			   TT				#
#						  #	   FF			 #					M	   M	 M   OOOOOOOO	DDDDDDDD	 SSSSSSSS	 ###   N	   NN  EEEEEEEEEE	   TT				#
#						   #				#																															#
#							################																															#
#																																										#
#########################################################################################################################################################################

# Mod Name		: Video Player ( VIDEO_SUPPORT ).
# Author		: AJC and Au{R}oN | www.fmods.net.
# Creation date	: 2017-12-26.
# Version		: 3.2.
# Update date	: 2025-12-27.
# Update notes	: Adjusted to support FMods Tools 3.2 and added an uninstall script.

#########################################################################################################################################################################
#	Delete commands.																																					#
#########################################################################################################################################################################

MOD_NAME="VIDEO_SUPPORT"
PATH="/fs/rwdata/dev:${PATH}"
MODS_PATH="/fs/images/fmods_mods_data/"
# MODS_JSON_PATH="${MODS_PATH}/mods.json"
SHORT="${MODS_PATH}/${MOD_NAME}"
PATCH_DIR="${SHORT}/patch"
UNPATCH=1

# Remove also the dependencies from the installed_mods.txt and set the status to deleted for all Mods depending on this one to be installed first.
# DEPENDENCY1="RVC_SAFETY_REMOVER"
# DEPENDENCY1_PATH="${MODS_PATH}/${DEPENDENCY1}"
# sed -i -e "/${DEPENDENCY1}/d" 																	"/fs/mp/etc/installed_mods.txt"
# if [ -f "${DEPENDENCY1_PATH}/uninstall/uninstall.sh" ]; then
#	 chmod +x "${DEPENDENCY1_PATH}/uninstall/uninstall.sh"
#	 sh "${DEPENDENCY1_PATH}/uninstall/uninstall.sh"

#	 if grep -q "${DEPENDENCY1}" 																	"${MODS_JSON_PATH}"; then
#		 jq --arg modName "$DEPENDENCY1" '(.mods[] | select(.modName == $modName)).modUninstallFile = "deleted"' "${MODS_JSON_PATH}" > "/tmp/tmp.json"
#		 mv "/tmp/tmp.json" 																		"${MODS_JSON_PATH}"
#	 fi
# fi
if [ "${UNPATCH:-0}" -eq 1 ]; then
	if ! patch -l --dry-run -R -p0 < 																"${PATCH_DIR}/master.patch" > "${SHORT}/patch.log"; then
		MANUAL=1
	else
		patch -l -b -R -p0 < 																		"${PATCH_DIR}/master.patch"
	fi
fi
if [ "${UNPATCH:-0}" -eq 0 ] || [ "${MANUAL:-0}" -eq 1 ]; then
	if ! grep -q "VIDEO_10P_SUPPORT" /fs/mp/etc/installed_mods.txt && ! grep -q "VIDEO_10L_SUPPORT"	"/fs/mp/etc/installed_mods.txt"; then
		if [ -f "${SHORT}/backup/mm-sync.conf" ]; then
			chmod a+x "/fs/mp/etc/mm/"*
			rm -f "/fs/mp/etc/mm/mm-sync.conf"
			cp "${SHORT}/backup/mm-sync.conf"														"/fs/mp/etc/mm/mm-sync.conf"
		fi
		if [ -f "${SHORT}/backup/qmldir" ]; then
			chmod a+x "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/"*
			rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/qmldir"
			cp "${SHORT}/backup/qmldir"								  								"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/qmldir"
		fi
		if [ -f "${SHORT}/backup/MenuBar.qml" ]; then
			chmod a+x "/fs/mp/fordhmi/imports/Hmi/Ford/"*
			rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/MenuBar.qml"
			cp "${SHORT}/backup/MenuBar.qml"														"/fs/mp/fordhmi/imports/Hmi/Ford/MenuBar.qml"
		fi
		if [ -f "${SHORT}/backup/+lincoln-MY20/GeneralUSBScreen.qml" ]; then
			chmod a+x "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/"*
			rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/GeneralUSBScreen.qml"
			cp "${SHORT}/backup/+lincoln-MY20/GeneralUSBScreen.qml"	  								"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/GeneralUSBScreen.qml"
		fi
		if [ -f "${SHORT}/backup/+lincoln-MY20/SongInformationView.qml" ]; then
			chmod a+x "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/"*
			rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/SongInformationView.qml"
			cp "${SHORT}/backup/+lincoln-MY20/SongInformationView.qml"   							"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/SongInformationView.qml"
		fi
		if [ -f "${SHORT}/backup/CoverAlbumButton.qml" ]; then
			chmod a+x "/fs/mp/fordhmi/qml/hmimedia/components/"*
			rm -f "/fs/mp/fordhmi/qml/hmimedia/components/CoverAlbumButton.qml"
			cp "${SHORT}/backup/CoverAlbumButton.qml"												"/fs/mp/fordhmi/qml/hmimedia/components/CoverAlbumButton.qml"
		fi
		if [ -f "${SHORT}/backup/GeneralUSBScreen.qml" ]; then
			chmod a+x "/fs/mp/fordhmi/qml/hmimedia/components/"*
			rm -f "/fs/mp/fordhmi/qml/hmimedia/components/GeneralUSBScreen.qml"
			cp "${SHORT}/backup/GeneralUSBScreen.qml"												"/fs/mp/fordhmi/qml/hmimedia/components/GeneralUSBScreen.qml"
		fi
		if [ -f "${SHORT}/backup/SongInformationView.qml" ]; then
			chmod a+x "/fs/mp/fordhmi/qml/hmimedia/components/"*
			rm -f "/fs/mp/fordhmi/qml/hmimedia/components/SongInformationView.qml"
			cp "${SHORT}/backup/SongInformationView.qml"			 								"/fs/mp/fordhmi/qml/hmimedia/components/SongInformationView.qml"
		fi
		if [ -f "${SHORT}/backup/+lincoln-MY20/SongInformationPage.qml" ]; then
			chmod a+x "/fs/mp/fordhmi/qml/hmimedia/usb/+lincoln-MY20/"*
			rm -f "/fs/mp/fordhmi/qml/hmimedia/usb/+lincoln-MY20/SongInformationPage.qml"
			cp "${SHORT}/backup/+lincoln-MY20/SongInformationPage.qml" 								"/fs/mp/fordhmi/qml/hmimedia/usb/+lincoln-MY20/SongInformationPage.qml"
		fi
		if [ -f "${SHORT}/backup/SongInformationPage.qml" ]; then
			chmod a+x "/fs/mp/fordhmi/qml/hmimedia/usb/"*
			rm -f "/fs/mp/fordhmi/qml/hmimedia/usb/SongInformationPage.qml"
			cp "${SHORT}/backup/SongInformationPage.qml"			 								"/fs/mp/fordhmi/qml/hmimedia/usb/SongInformationPage.qml"
		fi
		chmod a+x "/fs/mp/apps/fmods/"*
		rm -f "/fs/mp/apps/fmods/VPVideoInject"
		rm -f "/fs/mp/apps/fmods/VPVideoDetach"
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/VideoPlaybackScreenInfoContent.qml"
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/VideoTrackControlButtons.qml"
		rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/VideoPlayerPipe.qml"
		rm -f "/fs/mp/fordhmi/qml/themes/ford-MY20/images/night/media/bg_videocontrols.png"
		rm -f "/fs/mp/fordhmi/qml/themes/ford-MY20/images/night/media/PlaceholderCoverArt-Video.png"
		rm -f "/fs/mp/fordhmi/qml/themes/ford-MY20/images/day/media/bg_videocontrols.png"
		rm -f "/fs/mp/fordhmi/qml/themes/ford-MY20/images/day/media/PlaceholderCoverArt-Video.png"
		rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+10inchL/VideoPlayerPipe.qml"
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/VideoPlaybackScreenInfoContent.qml"
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+10inchL/VideoTrackControlButtons.qml"
		rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+10inchP/VideoPlayerPipe.qml"
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+10inchP/VideoPlaybackScreenInfoContent.qml"
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+10inchP/VideoTrackControlButtons.qml"
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/VideoPlaybackScreenInfoContent.qml"
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/VideoTrackControlButtons.qml"
		rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+lincoln-MY20/VideoPlayerPipe.qml"
		rm -f "/fs/mp/fordhmi/qml/themes/lincoln-MY20/images/night/media/videomedia_player_bgr_main.png"
		rm -f "/fs/mp/fordhmi/qml/themes/lincoln-MY20/images/day/media/videomedia_player_bgr_main.png"
		# Remove video_support.sh from folder: /fs/mp/scripts/
		chmod a+x "/fs/mp/scripts/fmods/"*
		rm -f "/fs/mp/scripts/fmods/video_support.sh"
	fi
fi
