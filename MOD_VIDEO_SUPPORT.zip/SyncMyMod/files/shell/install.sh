#!/bin/sh
# shellcheck disable=SC2086 disable=SC3006 disable=SC3054
#########################################################################################################################################################################
#	Installation script for Video Player					  																											#
#########################################################################################################################################################################
#																																										#
#					AAA								   TTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEE			   AAA				 MMMMMMMM				MMMMMMMM	#
#				   A:::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			  A:::A				 M:::::::M			   M:::::::M	#
#				  A:::::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			 A:::::A			 M::::::::M			  M::::::::M	#
#				 A:::::::A							   T:::::TT:::::::TT:::::TEE::::::EEEEEEEEE::::E			A:::::::A			 M:::::::::M		 M:::::::::M	#
#				A:::::::::A							   TTTTTT  T:::::T  TTTTTT  E:::::E		  EEEEEE		   A:::::::::A			 M::::::::::M		M::::::::::M	#
#			   A:::::A:::::A								   T:::::T			E:::::E			 			  A:::::A:::::A			 M:::::::::::M	   M:::::::::::M	#
#			  A:::::A A:::::A								   T:::::T			E::::::EEEEEEEEEE			 A:::::A A:::::A		 M:::::::M::::M   M::::M:::::::M	#
#			 A:::::A   A:::::A		   ---------------		   T:::::T			E:::::::::::::::E			A:::::A   A:::::A		 M::::::M M::::M M::::M M::::::M	#
#			A:::::A		A:::::A		   -:::::::::::::-		   T:::::T			E:::::::::::::::E		   A:::::A	   A:::::A		 M::::::M  M::::M::::M  M::::::M	#
#		   A:::::AAAAAAAAA:::::A	   ---------------		   T:::::T			E::::::EEEEEEEEEE		  A:::::AAAAAAAAA:::::A		 M::::::M   M:::::::M   M::::::M	#
#		  A:::::::::::::::::::::A							   T:::::T			E:::::E			 		 A:::::::::::::::::::::A	 M::::::M	 M:::::M	M::::::M	#
#		 A:::::AAAAAAAAAAAAA:::::A							   T:::::T			E:::::E		  EEEEEE	A:::::AAAAAAAAAAAAA:::::A	 M::::::M	  MMMMM		M::::::M	#
#		A:::::A				A:::::A							 TT:::::::TT	  EE::::::EEEEEEEE:::::E   A:::::A			   A:::::A   M::::::M				M::::::M	#
#	   A:::::A				 A:::::A						 T:::::::::T	  E::::::::::::::::::::E  A:::::A				A:::::A  M::::::M				M::::::M	#
#	  A:::::A				  A:::::A						 T:::::::::T	  E::::::::::::::::::::E A:::::A				 A:::::A M::::::M				M::::::M	#
#	 AAAAAAA				   AAAAAAA						 TTTTTTTTTTT	  EEEEEEEEEEEEEEEEEEEEEEAAAAAAA					 AAAAAAAMMMMMMMM				MMMMMMMM	#
#																																										#
#########################################################################################################################################################################
#																																										#
#							 ###############																															#
#							#				#																															#
#						  #					 #					M			 M						 D			 														#
#				 #########	   FFFFFFFFFFF	  #########			MM			MM						 D			 														#
#						#	   FF			   #				M M		   M M   OOOOOOOO	DDDDDDD D   SSSSSSSS		   NN		N  EEEEEEEEEE  TTTTTTTTTT			#
#			############	   FF FFFF			############	M  M	  M  M  O		 O  D		 D  S				   N NN		N  EE			   TT				#
#						#	   FF			   #				M   M	 M   M  O		 O  D		 D   SSSSSSSS		   N   NN   N  EEEEEEEEEE	   TT				#
#				 #########	   FF			  #########			M	  M M	 M  O		 O  D		 D			 S   ###   N	 NN N  EE			   TT				#
#						  #	   FF			 #					M	   M	 M   OOOOOOOO	DDDDDDDD	 SSSSSSSS	 ###   N	   NN  EEEEEEEEEE	   TT				#
#						   #				#																															#
#							################																															#
#																																										#
#########################################################################################################################################################################

# Mod Name		: Video Player ( VIDEO_SUPPORT ).
# Author		: AJC and Au{R}oN | www.fmods.net.
# Creation date	: 2017-12-26.
# Version		: 3.2.
# Update date	: 2025-12-27.
# Update notes	: Adjusted to support FMods Tools 3.2 and added an uninstall script.

#########################################################################################################################################################################
#	Install commands.																																					#
#########################################################################################################################################################################

MOD_NAME="VIDEO_SUPPORT"
PATH="/fs/rwdata/dev:${PATH}"
MODS_PATH="/fs/images/fmods_mods_data/"
SHORT="${MODS_PATH}/${MOD_NAME}"
PATCH_DIR="${SHORT}/patch"
PATCH=1
if [ "${PATCH;-0}" -eq 1 ]; then
	if ! patch -l --dry-run -p0 < 																	"${PATCH_DIR}/master.patch" > "${SHORT}/patch.log"; then
		MANUAL=1
	else
		patch -l -b -p0 < 																			"${PATCH_DIR}/master.patch"
	fi
fi
if [ "${PATCH:-0}" -eq 0 ] || [ "${MANUAL:-0}" -eq 1 ]; then
	if [ -f "${SHORT}/new/mm-sync.conf" ]; then
		chmod a+x "/fs/mp/etc/mm/"*
		rm -f "/fs/mp/etc/mm/mm-sync.conf"
		cp "${SHORT}/new/mm-sync.conf"																"/fs/mp/etc/mm/mm-sync.conf"
	fi

	if [ -f "${SHORT}/new/qmldir" ]; then
		chmod a+x "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/"*
		rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/Controls/qmldir"
		cp "${SHORT}/new/qmldir"																	"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/qmldir"
	fi

	if [ -f "${SHORT}/new/MenuBar.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/imports/Hmi/Ford/"*
		rm -f "/fs/mp/fordhmi/imports/Hmi/Ford/MenuBar.qml"
		cp "${SHORT}/new/MenuBar.qml"																"/fs/mp/fordhmi/imports/Hmi/Ford/MenuBar.qml"
	fi

	if [ -f "${SHORT}/new/+lincoln-MY20/GeneralUSBScreen.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/"*
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/GeneralUSBScreen.qml"
		cp "${SHORT}/new/+lincoln-MY20/GeneralUSBScreen.qml"										"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/GeneralUSBScreen.qml"
	fi

	if [ -f "${SHORT}/new/+lincoln-MY20/SongInformationView.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/"*
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/SongInformationView.qml"
		cp "${SHORT}/new/+lincoln-MY20/SongInformationView.qml"										"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/SongInformationView.qml"
	fi

	if [ -f "${SHORT}/new/CoverAlbumButton.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmimedia/components/"*
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/CoverAlbumButton.qml"
		cp "${SHORT}/new/CoverAlbumButton.qml"														"/fs/mp/fordhmi/qml/hmimedia/components/CoverAlbumButton.qml"
	fi

	if [ -f "${SHORT}/new/GeneralUSBScreen.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmimedia/components/"*
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/GeneralUSBScreen.qml"
		cp "${SHORT}/new/GeneralUSBScreen.qml"														"/fs/mp/fordhmi/qml/hmimedia/components/GeneralUSBScreen.qml"
	fi

	if [ -f "${SHORT}/new/SongInformationView.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmimedia/components/"*
		rm -f "/fs/mp/fordhmi/qml/hmimedia/components/SongInformationView.qml"
		cp "${SHORT}/new/SongInformationView.qml"													"/fs/mp/fordhmi/qml/hmimedia/components/SongInformationView.qml"
	fi

	if [ -f "${SHORT}/new/+lincoln-MY20/SongInformationPage.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmimedia/usb/+lincoln-MY20/"*
		rm -f "/fs/mp/fordhmi/qml/hmimedia/usb/+lincoln-MY20/SongInformationPage.qml"
		cp "${SHORT}/new/+lincoln-MY20/SongInformationPage.qml"										"/fs/mp/fordhmi/qml/hmimedia/usb/+lincoln-MY20/SongInformationPage.qml"
	fi

	if [ -f "${SHORT}/new/SongInformationPage.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmimedia/usb/"*
		rm -f "/fs/mp/fordhmi/qml/hmimedia/usb/SongInformationPage.qml"
		cp "${SHORT}/new/SongInformationPage.qml"													"/fs/mp/fordhmi/qml/hmimedia/usb/SongInformationPage.qml"
	fi
fi

#Core Files
cp "${SHORT}/new/VPVideoInject"																		"/fs/mp/apps/fmods/"
cp "${SHORT}/new/VPVideoDetach"																		"/fs/mp/apps/fmods/"
cp "${SHORT}/new/video_support.sh"																	"/fs/mp/scripts/fmods/"
chmod +x "/fs/mp/apps/fmods/VPVideoInject"
chmod +x "/fs/mp/apps/fmods/VPVideoDetach"
chmod +x "/fs/mp/scripts/fmods/video_support.sh"

cp "${SHORT}/new/VideoPlaybackScreenInfoContent.qml"												"/fs/mp/fordhmi/qml/hmimedia/components/"
cp "${SHORT}/new/VideoTrackControlButtons.qml"														"/fs/mp/fordhmi/qml/hmimedia/components/"
cp "${SHORT}/new/VideoPlayerPipe.qml"																"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/"
cp "${SHORT}/new/bg_videocontrols_night.png"														"/fs/mp/fordhmi/qml/themes/ford-MY20/images/night/media/bg_videocontrols.png"
cp "${SHORT}/new/bg_videocontrols_day.png"															"/fs/mp/fordhmi/qml/themes/ford-MY20/images/day/media/bg_videocontrols.png"
cp "${SHORT}/new/PlaceholderCoverArt-Video.png"														"/fs/mp/fordhmi/qml/themes/ford-MY20/images/night/media/"
cp "${SHORT}/new/PlaceholderCoverArt-Video.png"														"/fs/mp/fordhmi/qml/themes/ford-MY20/images/day/media/"

cp "${SHORT}/new/LincolnVideoPlaybackScreenInfoContent.qml"											"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/VideoPlaybackScreenInfoContent.qml"
cp "${SHORT}/new/LincolnVideoTrackControlButtons.qml"												"/fs/mp/fordhmi/qml/hmimedia/components/+lincoln-MY20/VideoTrackControlButtons.qml"
cp "${SHORT}/new/VideoPlayerPipe.qml"																"/fs/mp/fordhmi/imports/Hmi/Ford/Controls/+lincoln-MY20/"
cp "${SHORT}/new/videomedia_player_bgr_main_night.png"												"/fs/mp/fordhmi/qml/themes/lincoln-MY20/images/night/media/videomedia_player_bgr_main.png"
cp "${SHORT}/new/videomedia_player_bgr_main_day.png"												"/fs/mp/fordhmi/qml/themes/lincoln-MY20/images/day/media/videomedia_player_bgr_main.png"
