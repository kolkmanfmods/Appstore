#!/bin/sh
# shellcheck disable=SC3014
# Adds video playback support to Sync3.

VIDEOEXT="3G2 3GP M4V MP4 MPEG4 MOV AVI MKV"
printf "" > "/fs/rwdata/fmods/mods/video_control.txt"
for context in /pps/services/multimedia/renderer/context/ZW.*; do
	if [ -e "$context" ]; then
		SCREENRES="$(grep "video mode =" /dev/screen/0/dpy-2 | awk '{print $4 "x" $6}')"
		ROTATION="$(grep "rotation =" /dev/screen/0/dpy-2 | awk -F '[=, ]+' '{print $2}')"
		CONTEXTID="$(echo "$context" | sed 's:.*\/::')"
		MEDIAFILE="$(cat "$context"/input | grep url | sed 's/.*:://')"

		if [ "$MEDIAFILE" != "" ]; then
			MEDIAEXT="$(echo "$MEDIAFILE" | sed 's/.*\.//')"

			# See if it's a video file
			if [ "$(echo "$VIDEOEXT" | grep -ic "$MEDIAEXT")" -ne 0 ]; then
				VIDEOFILE=1
			else
				VIDEOFILE=0
			fi
			# See if we have a video context
			if [ -e "$context"/output1 ]; then
				VIDEOCONTEXT=1
			else
				VIDEOCONTEXT=0
			fi
			# If we have a video file, but no video context is attached, create it
			if [ "$VIDEOFILE $VIDEOCONTEXT" == "1 0" ]; then
				VIDFILE="$(cat /pps/services/multimedia/renderer/context/"$CONTEXTID"/input | grep url | sed 's/.*:://')"
				SEEKPOS="$(cat /pps/services/multimedia/renderer/context/"$CONTEXTID"/status | grep position | sed 's/.*:://')"
				/fs/mp/apps/fmods/VPVideoInject "$CONTEXTID" "$VIDFILE" "$SEEKPOS" "$SCREENRES" "$ROTATION"
			fi
			# If we have an audio file, but a video context is attached, remove it
			if [ "$VIDEOFILE $VIDEOCONTEXT" == "0 1" ]; then
				VIDFILE="$(cat /pps/services/multimedia/renderer/context/"$CONTEXTID"/input | grep url | sed 's/.*:://')"
				SEEKPOS="$(cat /pps/services/multimedia/renderer/context/"$CONTEXTID"/status | grep position | sed 's/.*:://')"
				/fs/mp/apps/fmods/VPVideoDetach "$CONTEXTID" "$VIDFILE" "$SEEKPOS"
			fi
		fi
	fi
	# Update video player pipe file to suppress page elements when video is playing
	CONTROL_STATUS=$(cat /fs/rwdata/fmods/mods/video_control.txt)
	if [ -e "$context"/output1 ]; then
		if [ "$CONTROL_STATUS" != "active" ]; then
			printf "active" > "/fs/rwdata/fmods/mods/video_control.txt"
		fi
	else
		if [ "$CONTROL_STATUS" != "inactive" ]; then
			printf "inactive" > "/fs/rwdata/fmods/mods/video_control.txt"
		fi
	fi
done
