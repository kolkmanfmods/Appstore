import QtQuick 2.0

import HmiGui 1.0

import HmiGuiFramework.Controls 1.0

import Hmi.Ford.Controls 1.0
import AL2HMIBridge 1.0

Column {
    id: root
    objectName: "VideoPlaybackScreenInfoContent"

    property alias elapsedTime: elapsedTimeLabel.text
    property alias totalTime: totalTimeLabel.text
    property alias totalTimeVisible: totalTimeLabel.visible
    property alias elapsedTimeVisible: elapsedTimeLabel.visible
    property alias progress: progressBar.value
    property alias maximumValue: progressBar.maximumValue


    property int currentTrack: 0
    property int totalTracks: 0
    property alias trackInfoPos: trackInformation.horizontalAlignment

    property alias draggingSupported: progressBar.draggingSupported
    property alias dragging: progressBar.dragging
    property alias draggingValue: progressBar.draggingValue
    property alias dragOperationInProgress: progressBar.dragOperationInProgress

    signal jumpTo(real pos)

    LayoutMirroring.enabled: ViewController.rightToLeftLanguageActive
    LayoutMirroring.childrenInherit: true

    anchors {
        top: parent.top
        left: parent.left
        right: parent.right
        bottomMargin: UiTheme.styleRoot.generalMarginMedium
    }

    spacing: UiTheme.styleRoot.generalMarginSmall

    Item {
        id: trackTime
        objectName: "VideoPlaybackScreenInfoContent_trackTime"

        anchors {
            left: parent.left
            leftMargin: UiTheme.styleRoot.generalMarginHuge * 3 + 39
            right: parent.right
            rightMargin: UiTheme.styleRoot.generalMarginHuge * 3 + 39
        }

        height: childrenRect.height

        TextLabel {
            id: elapsedTimeLabel
            objectName: "VideoPlaybackScreenInfoContent_elapsedTimeLabel"
            anchors {
                left: parent.left
                top: parent.top
                topMargin: 8
            }
			color: "#e0e0e0"
			style: Text.Outline
			styleColor: "black"
            variation: HmiGui.DefaultLabelVariation
        }

        TextLabel {
            id: trackInformation
            objectName: "VideoPlaybackScreenInfoContent_trackInformation"

            anchors {
                horizontalCenter: parent.horizontalCenter
                bottom: elapsedTimeLabel.bottom
            }

			color: "#e0e0e0"
			style: Text.Outline
			styleColor: "black"			  
            //~ TextID 38488d12-e6f6-11e7-af74-08002718b8d7
            text: qsTr("%1/%2 ").arg(currentTrack).arg(totalTracks)
            variation: HmiGui.DefaultLabelVariation
            horizontalAlignment: Text.AlignHCenter
            visible: totalTracks > 0 && currentTrack >= 0
        }

        ProgressBar {
            id: progressBar
            objectName: "VideoPlaybackScreenInfoContent_progressBar"

            anchors {
                top: elapsedTimeLabel.bottom
                topMargin: 7
                left: parent.left
                leftMargin: -4
                right: parent.right
                rightMargin: -4
            }

            height: UiTheme.styleRoot.generalMarginBig + UiTheme.styleRoot.generalMarginSmaller
            maximumValue: 100
            minimumValue: 0
            visible: totalTimeLabel.visible

            onJumpTo: root.jumpTo(pos)
        }

        TextLabel {
            id: totalTimeLabel
            objectName: "VideoPlaybackScreenInfoContent_totalTimeLabel"
            anchors {
                right: parent.right
                bottom: elapsedTimeLabel.bottom
            }
			color: "#e0e0e0"
			style: Text.Outline
			styleColor: "black"				  
            variation: HmiGui.DefaultLabelVariation
        }
    }
}