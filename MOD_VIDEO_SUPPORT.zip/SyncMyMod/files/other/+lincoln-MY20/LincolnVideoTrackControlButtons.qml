import QtQuick 2.0

import HmiGui 1.0
import HmiGuiFramework 1.0
import HmiGuiFramework.Controls 1.0

import Hmi.Ford 1.0
import Hmi.Ford.Controls 1.0


Row {
    id: root
    objectName: "TrackControlButtons"

    property bool show30Button: false
    property bool playing: false

    //Adding the style root file for track control buttons in order to add new images and properties based on the theme
    property bool showThumbsButtons: false
    property int buttonRowSpacing: UiTheme.styleRoot.generalMarginMedium + 1


    property alias backButtonActive: backButton.active
    property alias previousButtonVisible: backButton.visible
    property alias playPauseButtonVisible: playPauseButton.visible
    property alias nextButtonVisible: nextButton.visible
    property alias thumbsUpButtonStatus: thumbsupButton.isSelected
    property alias thumbsDownButtonStatus: thumbsdownButton.isSelected
    property alias back30Button: back30Button
    property alias next30Button: next30Button
    property alias thumbsdownButton: thumbsdownButton
    property alias thumbsupButton: thumbsupButton
    property alias backButton: backButton
    property alias nextButton: nextButton
    property alias playPauseButton: playPauseButton

    signal previous30Clicked

    signal previousClicked
    signal previousPressAndHold
    signal previousHoldAndReleased

    signal playPauseClicked

    signal nextClicked
    signal nextPressAndHold
    signal nextHoldAndReleased

    signal next30Clicked
    signal thumbsDownClicked
    signal thumbsUpClicked

    spacing: UiTheme.styleRoot.generalMarginBig + UiTheme.styleRoot.generalMarginSmaller

    //We need this here, because if we report the *real* height of this control, it breaks the other Screens (ex: CD Screen).
    property bool isSiriusScreen: false
    Binding on height
    {
        when: isSiriusScreen
        value: 128
    }

    Panel {

        anchors{
            left: parent.left
            right: parent.right
            verticalCenter: parent.verticalCenter
        }

        visible: nextButtonVisible && previousButtonVisible && playPauseButtonVisible
        backgroundSource: UiTheme.palette.image("media/videomedia_player_bgr_main")
        backgroundRendered: true
    }

    IconPushButton {
        id: back30Button
        defaultVariationStyle: "trackControlPushButtonStyle"
        objectName: "TrackControlButtons_back30Button"
        visible: root.show30Button
        anchors.verticalCenter: playPauseButton.verticalCenter

        shape: HmiGui.Round
        size: HmiGui.VerySmall

        iconId: "media/icon_back_30"

        onClicked: root.previous30Clicked()
    }

    IconPushButton {
        id: thumbsdownButton
        objectName: "TrackControlButtons_thumbsdownButton"
        visible: root.showThumbsButtons
        anchors.verticalCenter: playPauseButton.verticalCenter

        shape: HmiGui.Round
        size: HmiGui.Small

        iconId: "media/icon_thumbs_down"

        onClicked: root.thumbsDownClicked()

    }


    IconPushButton {
        id: backButton
        objectName: "TrackControlButtons_backButton"
        anchors.verticalCenter: playPauseButton.verticalCenter

        property bool hold: false

        shape: HmiGui.Round
        size: HmiGui.Regular

        iconId: "media/icon_rewind"

        active: backButtonActive

        onPressAndHold: {
            hold = true;
            previousPressAndHold()
        }
        clickAfterPressAndHold: false

        onPressed: hold = false

        onExited: {
            if (hold) {
                previousHoldAndReleased()
            }
            hold = false
        }

        onReleased: {
            if (hold) {
                previousHoldAndReleased();
            }
            hold = false;
        }

        onClicked: previousClicked();

    }

    IconPushButton {
        id: playPauseButton
        objectName: "TrackControlButtons_playPauseButton"
        anchors.verticalCenter: parent.verticalCenter

        shape: HmiGui.Round
        size: HmiGui.Bigger

        iconId: root.playing ? "media/icon_pause" : "media/icon_play"

        onClicked: playPauseClicked()

    }

    IconPushButton {
        id: nextButton
        objectName: "TrackControlButtons_nextButton"
        anchors.verticalCenter: playPauseButton.verticalCenter

        property bool hold: false

        shape: HmiGui.Round
        size: HmiGui.Regular

        iconId: "media/icon_fastforward"

        onPressAndHold: {
            hold = true;
            nextPressAndHold()
        }
        clickAfterPressAndHold: false

        onPressed: hold = false

        onExited: {
            if (hold) {
                nextHoldAndReleased()
            }
            hold = false
        }

        onReleased: {
            if (hold) {
                nextHoldAndReleased()
            }
            hold = false
        }

        onClicked: nextClicked()

    }

    IconPushButton {
        id: next30Button
        defaultVariationStyle: "trackControlPushButtonStyle"
        objectName: "TrackControlButtons_next30Button"
        visible: root.show30Button
        anchors.verticalCenter: playPauseButton.verticalCenter

        shape: HmiGui.Round
        size: HmiGui.VerySmall

        iconId: "media/icon_forward_30"

        onClicked: root.next30Clicked()

    }

    IconPushButton {
        id: thumbsupButton
        objectName: "TrackControlButtons_thumbsupButton"
        visible: root.showThumbsButtons
        anchors.verticalCenter: playPauseButton.verticalCenter

        shape: HmiGui.Round
        size: HmiGui.Small

        iconId: "media/icon_thumbs_up"

        onClicked: root.thumbsUpClicked()
    }

}
