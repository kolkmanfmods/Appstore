import QtQuick 2.0
import HmiGui 1.0
import HmiOverrides 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0
import HmiCore.Instrumentation 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge

TransformableItem {
    id: root
    objectName: "MenuBar"
    property QtObject _style: UiTheme.styleSelect("menuBar", root);

    z: parent ? parent.menuBarLayer
              : 0

    signal moduleRequest(int domain, string moduleRootView)

    property bool showBackgroundImage: true

    readonly property int iconDimensions: 40

    HmiImage {
        id: backgroundButton
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        height: UiTheme.styleRoot.navigationBarHeight + UiTheme.styleRoot.navBarHeightOffset
        source: root.showBackgroundImage ? UiTheme.palette.image(root._style.backgroundSource(listView.count)) : ""
    }

    function moduleText(domain) {
        var textOverrides = HmiOverrides.nameOverrides;

        if (textOverrides.indexOf(domain) !== -1) {
            return  HmiOverrides.nameOverride(domain);
        }

        switch (domain) {
        case HmiGui.HomeDomain:
            //~ GroupID fordhmi/lincoln-moduletext-0001
//~ TextID 38488c9e-e6f6-11e7-af74-08002718b8d7
            return qsTr("Home")
        case HmiGui.PhoneDomain:
            //~ GroupID fordhmi/lincoln-moduletext-0001
//~ TextID 38488c9f-e6f6-11e7-af74-08002718b8d7
            return qsTr("Phone")
        case HmiGui.MediaDomain:
            //~ GroupID fordhmi/lincoln-moduletext-0001
//~ TextID 38488ca0-e6f6-11e7-af74-08002718b8d7
            return qsTr("Audio")
        case HmiGui.AppsDomain:
            //~ GroupID fordhmi/lincoln-moduletext-0001
//~ TextID 38488ca1-e6f6-11e7-af74-08002718b8d7
            return qsTr("Apps")
        case HmiGui.NavigationDomain:
            //~ GroupID fordhmi/lincoln-moduletext-0001
//~ TextID 38488ca2-e6f6-11e7-af74-08002718b8d7
            return qsTr("Nav")
        case HmiGui.SettingsDomain:
            //~ GroupID fordhmi/lincoln-moduletext-0001
//~ TextID 38488ca3-e6f6-11e7-af74-08002718b8d7
            return qsTr("Settings")
        case HmiGui.ClimateDomain:
            //~ GroupID fordhmi/lincoln-moduletext-0001
//~ TextID 38488ca4-e6f6-11e7-af74-08002718b8d7
            return qsTr("Climate")
        case HmiGui.AppsGALProjectionDomain:
            //~ GroupID fordhmi/lincoln-moduletext-0001
//~ TextID 38488ca6-e6f6-11e7-af74-08002718b8d7
            return qsTr("Android Auto")
        case HmiGui.AppsDIOProjectionDomain:
            //~ GroupID fordhmi/lincoln-moduletext-0001
//~ TextID 38488ca8-e6f6-11e7-af74-08002718b8d7
            return qsTr("Apple CarPlay")
        case HmiGui.NavigationProjectionDomain:
            //~ GroupID fordhmi/lincoln-moduletext-0001
//~ TextID 38488ca9-e6f6-11e7-af74-08002718b8d7
            return qsTr("Maps")
        default:
            //~ GroupID fordhmi/lincoln-moduletext-0001
//~ TextID f6272cdc-269e-11e8-823a-08002718b8d7
            return qsTr("Unknown", "lincoln-defaultModuleTextMenuBar")
        }
    }

    function moduleBackground(domain) {
        switch (domain) {
        case HmiGui.HomeDomain:
            return "_home"
        case HmiGui.PhoneDomain:
            return "_phone"
        case HmiGui.MediaDomain:
            return qsTr("Media")
        case HmiGui.AppsDIOProjectionDomain:
        case HmiGui.AppsGALProjectionDomain:
        case HmiGui.AppsDomain:
            return "_apps"
        case HmiGui.NavigationProjectionDomain:
        case HmiGui.NavigationDomain:
            return "_nav"
        case HmiGui.SettingsDomain:
            return "_settings"
        case HmiGui.ClimateDomain:
            return "_climate"
        default:
            return "Unknown"
        }
    }

    function delegateWidth(index, count) {
        var width = 0;

        switch (count) {
        case 7:
            switch (index) {
            case 0:
            case 1:
            case 5:
            case 6:
                width = 115;
                break;
            default:
                width = 114;
                break;
            }
            break;
        case 6:
            switch (index) {
            case 0:
            case 5:
                width = 134;
                break;
            default:
                width = 133;
                break;
            }
            break;
        case 5:
            width = 160;
            break;
        case 4:
            width = 200;
            break;
        default:
            width = 133;
            break;
        }

        return width;
    }

    function delegateBackground(index, count, name) {
        var url = "";

        if (name !== "")
            url = delegateWidth(index, count) + "x" + UiTheme.styleRoot.navigationBarHeight + "_"  + name;

        return url;
    }

    function delegateBackgroundHighlight(index, count, name) {
        var url = "";
        var height = UiTheme.styleRoot.navigationBarHeight

        if (name !== "")
            url = delegateWidth(index, count) + "x" + height + "_"  + name;

        return url;
    }

    function delegateIcon(domain, iconUrl, postfix) {
        var iconOverrides = HmiOverrides.iconOverrides;
        if (iconOverrides.indexOf(domain) !== -1) {
			return HmiOverrides.iconOverride(domain, postfix);
        }
        return UiTheme.palette.icon(iconUrl, postfix);
    }

    function checkMediaEnabled(moduleDomain) {
        if(moduleDomain === HmiGui.MediaDomain) {
            return !AL2HMIBridge.phoneSource.callConnected || (AL2HMIBridge.phoneSource.callConnected && AL2HMIBridge.phoneSource.privateMode && !AL2HMIBridge.phoneSource.muteAudioInPrivacy);
        }
        return true;
    }

    Component {
        id: navBarButtonDelegate

        Item {
            id: itemRoot
            property alias itemMouseArea : itemMouseArea

            readonly property string instrumentationEventName: root.moduleText(moduleDomain)
            property bool active: moduleDomain === ViewManager.activeDomain
            property int listViewCount: listView.count

            enabled: ViewController.activeMenuDomains.indexOf(moduleDomain) !== -1 && !moduleBlocked && root.checkMediaEnabled(moduleDomain)
            opacity: enabled ? 1.0 : 0.5

            width: root.delegateWidth(index, listViewCount)
            height: root.height
            anchors.bottom: parent.bottom

            HmiImage {
                id: pressedHighlight
                anchors.fill: parent
                source: UiTheme.palette.image(root.delegateBackground(index, listViewCount,
                                                              root._style.delegateStyle.pressedSource))
                opacity: itemMouseArea.pressed ? 1.0 : 0.0
                visible: opacity > 0.01
                Behavior on opacity {
                    NumberAnimation {
                        duration: 200
                    }
                }
            }

            HmiImage {
                anchors.left: pressedHighlight.left
                anchors.verticalCenter: parent.verticalCenter
                source: UiTheme.palette.image(root._style.delegateStyle.dividerSource)
                visible: {
                    if(ViewManager.activeDomain === HmiGui.HomeDomain)
                        return index !== 0
                    else
                        return index !== 0 && !itemRoot.active && index !== (listView.currentIndex + 1)
                }
            }

            HmiImage {
                // We reuse the active icon for the "pressed" state
                id: moduleIcon
                property string iconPostfix: {
                    if (!itemRoot.active && itemMouseArea.pressed) { // not highlighted domain with press
                        return "_activepressed"
                    } else if (itemRoot.active && itemMouseArea.pressed){ // highlighted domain with press
                         return "_selectedpressed"
                    } else if (itemRoot.active) { // highlighted domain
                         return "_selected"
                    }
                     return "_active" // not highlighted domain
                }
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: moduleNameText.top
                anchors.bottomMargin: root._style.delegateStyle.iconBottomMargin
                height: root.iconDimensions
                width: root.iconDimensions

                fillMode: Image.PreserveAspectFit
                // source: root.delegateIcon(moduleDomain, iconUrl, iconPostfix) // TODO: Uncomment this one when Qt > 5.2.1
                source: iconPostfix ? root.delegateIcon(moduleDomain, iconUrl, iconPostfix) : "" // Workaround Qt 5.2.1 bug, which calls UiTheme.palette.icon() before evaluating iconPostfix
                smooth: true
            }

            TextLabel {
                id: moduleNameText
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                anchors.bottomMargin: root._style.delegateStyle.bottomMargin

                elide: Text.ElideRight
                text: root.moduleText(moduleDomain)
                horizontalAlignment: Text.AlignHCenter
                color: itemMouseArea.pressed ? root._style.delegateStyle.pressedTextColor : (!root._style.hasOverlay && itemRoot.active) ? root._style.delegateStyle.activatedTextColor
                                                                                             : root._style.delegateStyle.textColor
                variation: itemMouseArea.pressed || (!root._style.hasOverlay && itemRoot.active) ? root._style.delegateStyle.textLabelVariationPressed
                                                                                                 : root._style.delegateStyle.textLabelVariation
            }

            MouseArea {
                id: itemMouseArea
                anchors.fill: parent
                onClicked: {
                    root.moduleRequest(moduleDomain, moduleRootView)
                    ViewController.buttonClicked(itemMouseArea)
                    Instrumentation.onButtonClicked(itemRoot)
                }
                property bool beepOnClick: true
            }

            function syncActivity() {
                if (active) {
                    if (listView.highlightItem != undefined && listView.highlightItem.opacity === 0.0)
                        listView.highlightMoveDuration = 0
                    else
                        listView.highlightMoveDuration = listView.normalHighlighMoveDuration
                    listView.currentIndex = index
                }
            }

            onActiveChanged: syncActivity()
            Connections {
                target: listView
                onReadyChanged: {
                    if (itemRoot.active)
                        itemRoot.syncActivity()
                }
                onCountChanged: {
                    if (itemRoot.active)
                        itemRoot.syncActivity()
                }
            }


        }
    }

    Component {
        id: navBarHighlightDelegate
        Item {
            HmiImage {
                id: itemRoot
                anchors.bottom: parent ? parent.bottom : undefined
                anchors.left: parent ? parent.left : undefined
                anchors.leftMargin: (listView.currentIndex > 0)? 1 : 0
                source: UiTheme.palette.getImageForDomain(root.delegateBackgroundHighlight(listView.currentIndex, listView.count,
                                                                                          root._style.delegateStyle.activeSource),
                                                          ViewManager.activeDomain)
                opacity: _menuModuleCollection.containsModule(ViewManager.activeDomain) ? 1.0  : 0.0
                visible: !root._style.hasOverlay && opacity > 0.01

                Behavior on opacity {
                    NumberAnimation {
                        duration: 200
                    }
                }
            }
        }
    }

    ListView {
        id: listView

        property int normalHighlighMoveDuration: root._style.highlightMoveDuration
        property bool ready: false

        anchors.bottom: parent.bottom
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        width: parent.width

        interactive: false

        model: _modulesModel
        delegate: navBarButtonDelegate
        highlight: navBarHighlightDelegate

        orientation: ListView.Horizontal
        highlightFollowsCurrentItem: true
        highlightMoveDuration: normalHighlighMoveDuration

        onCurrentIndexChanged: {
            if (!genericAnimationTimer.running) {
                UiTransition.genericUIAnimationStarted()
                genericAnimationTimer.start()
            } else {
                genericAnimationTimer.restart()
            }
       }

        Timer {
            id: genericAnimationTimer
            interval: listView.highlightMoveDuration
            repeat: false
            onTriggered: UiTransition.genericUIAnimationStopped()
            Component.onDestruction: UiTransition.genericUIAnimationStopped()
        }
    }

    property QtObject masterLayout: UiTheme.styleSelect("masterLayout", root)
    property double menuBarOnScreenX: masterLayout.menuBarX
    property double menuBarOnScreenY: masterLayout.menuBarY
    property double menuBarOnScreenWidth: masterLayout.menuBarWidth
    property double menuBarOnScreenHeight: masterLayout.menuBarHeight

    x: menuBarOnScreenX + (!ViewManager.rootReloaded ? menuBarOnScreenWidth : 0)
    y: menuBarOnScreenY + (!ViewManager.rootReloaded ? menuBarOnScreenHeight : 0)
    width: menuBarOnScreenWidth
    height: menuBarOnScreenHeight

    Component.onCompleted: {
        listView.currentIndex = -1;
        syncTimer.start()
    }

    Timer {
        id: syncTimer
        interval: 25
        repeat: true
        onTriggered: listView.ready = true
    }

    function hide() {
        showAnimation.stop()
        hideAnimation.start()
    }

    function hideWithoutAnimation() {
        showAnimation.stop()
        hideAnimation.stop()
        y = menuBarOnScreenY + masterLayout.menuBarHeight
    }

    function show() {
        hideAnimation.stop()
        showAnimation.start()
    }

    function showWithoutAnimation() {
        showAnimation.stop()
        hideAnimation.stop()
        y = menuBarOnScreenY
    }

    PropertyAnimation {
        id: hideAnimation
        duration: root._style.showHideAnimationDuration
        target: root
        property: 'y'
        to: root.menuBarOnScreenY + root.masterLayout.menuBarHeight
    }

    PropertyAnimation {
        id: showAnimation
        duration: root._style.showHideAnimationDuration
        target: root
        property: 'y'
        to: root.menuBarOnScreenY
    }

}
