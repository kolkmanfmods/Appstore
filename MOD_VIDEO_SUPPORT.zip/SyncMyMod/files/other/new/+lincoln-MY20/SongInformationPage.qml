import QtQuick 2.6
import QtQuick.Layouts 1.2

import HmiMedia 1.0

import HmiGui 1.0
import Hmi.Ford.Controls 1.0
import HmiCore 1.0
import Hmi.Ford 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge
import HmiGuiFramework 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Views 1.0
import "../MediaUtils.js" as MediaUtils

import "../components"

SongInformationView {
    id: root
    objectName: "SongInformationPage"

    property QtObject _styleStatusBar: UiTheme.styleSelect("statusBar", root)

    coverAlbumObjectName: "SongInformationPage_coverAlbum"
    songTitle: AL2HMIBridge.mediaSource.title
    coverArt: AL2HMIBridge.mediaSource.coverArtAvailable ? AL2HMIBridge.mediaSource.coverArt :""
    coverArtDriverRestiction: AL2HMIBridge.globalSource.driverRestrictionsAlbumArtActive

	transparentWindow: VideoPlayerPipe.isActive
	property bool buttonVisible: true
	
	states: State {
		name: "transitionToAudio"
		when: (!VideoPlayerPipe.isActive) // When no longer playing video files, go back to Main Audio Screen
		StateChangeScript {
			name: "transitionToAudioScript"
			script: {
				restoreOpacity.start();
				_hmiMedia.mediaController.back();
				console.log("STEFANO: no more videos, going back")
			}
		}
	}
	
	onShownChanged: { // Page loaded, show GUI elements
		root._showMenuBar();
		root.showTitleBar = true
		root.backButton.visible = true;
		
		if (shown && VideoPlayerPipe.isActive) { // If playing a video, start the Timer for the GUI elements
			btnTimer.restart();
			buttonVisible = true;
			console.log("STEFANO: Page Loaded, timer started and GUI elements loaded")
		}
		if (!shown) { // On page quit, stop the Timer
			btnTimer.stop();
			console.log("STEFANO: Page Quit, timer stopped")
		}
	}
	
	Timer {
		id: btnTimer
		interval: 5000
		running: false
		repeat: false
		onTriggered: { // Timer ended, hide all GUI elements
			removeOpacity.start();
			root._hideMenuBar();
			console.log("STEFANO: Timer Ended")
		}
	}
	
	userIdleReporting: true // Call the onUserActive event when the user touches the screen.
	
	onUserActive: {
		if (VideoPlayerPipe.isActive) { // Screen touched, show all GUI elements
			if (trackControlButtons.opacity == 0) {
				restoreOpacity.start();
				console.log("STEFANO: Screen Touched")
			}
			root._showMenuBar();
			btnTimer.restart();
		}
	}
	
	PunchThroughBackground { //Video View
		id: videoImage
		visible: VideoPlayerPipe.isActive
		
		punchThroughX: 0
		punchThroughY: 0
		punchThroughHeight: 480
		punchThroughWidth: 800
	
		width: UiTheme.styleRoot.applicationWidth
		height: UiTheme.styleRoot.applicationHeight
		x: -parent.x
		y: -parent.y
	
		property TransformableItem punchThroughWidget: root
		punchThroughTransformationSource: punchThroughWidget
	}
	
	VideoPlaybackScreenInfoContent {
			id: videoProgressBar
			opacity: 1.0
			visible: VideoPlayerPipe.isActive
			enabled: (opacity == 1) // Enable the buttons only when opacity is 1 (GUI elements visible)
			
			anchors.top: parent.top
			anchors.topMargin: 128
			anchors.leftMargin: 0
			anchors.rightMargin: 0
			
			draggingSupported: AL2HMIBridge.mediaSource.progressBarJumpSupported
			elapsedTime: MediaUtils.getElapsedTime(dragging, draggingValue, AL2HMIBridge.mediaSource.totalHours,
												AL2HMIBridge.mediaSource.totalMinutes, AL2HMIBridge.mediaSource.totalSeconds, AL2HMIBridge.mediaSource.elapsedHours,
												AL2HMIBridge.mediaSource.elapsedMinutes, AL2HMIBridge.mediaSource.elapsedSeconds)
	
			elapsedTimeVisible: AL2HMIBridge.mediaSource.endOfLastSongRepeatOff ? false
																	: AL2HMIBridge.mediaSource.totalHours !== AL2HMIBridge.mediaSource.elapsedHours
																	|| AL2HMIBridge.mediaSource.totalMinutes !== AL2HMIBridge.mediaSource.elapsedMinutes
																	|| AL2HMIBridge.mediaSource.totalSeconds !== AL2HMIBridge.mediaSource.elapsedSeconds
			totalTime: FormattingUtils.formatTimer(AL2HMIBridge.mediaSource.totalHours,
												AL2HMIBridge.mediaSource.totalMinutes,
												AL2HMIBridge.mediaSource.totalSeconds)
	
			totalTimeVisible: AL2HMIBridge.mediaSource.endOfLastSongRepeatOff ? false
																: (AL2HMIBridge.mediaSource.totalHours > 0
																	|| AL2HMIBridge.mediaSource.totalMinutes > 0
																	|| AL2HMIBridge.mediaSource.totalSeconds > 0)
																	&& (AL2HMIBridge.mediaSource.elapsedHours >= 0
																		&& AL2HMIBridge.mediaSource.elapsedMinutes >= 0
																		&& AL2HMIBridge.mediaSource.elapsedSeconds >= 0)
																	&& (AL2HMIBridge.mediaSource.elapsedHours < AL2HMIBridge.mediaSource.totalHours
																		|| (AL2HMIBridge.mediaSource.elapsedHours == AL2HMIBridge.mediaSource.totalHours
																			&& AL2HMIBridge.mediaSource.elapsedMinutes < AL2HMIBridge.mediaSource.totalMinutes)
																		|| (AL2HMIBridge.mediaSource.elapsedHours == AL2HMIBridge.mediaSource.totalHours
																			&& AL2HMIBridge.mediaSource.elapsedMinutes ==AL2HMIBridge.mediaSource.totalMinutes
																			&& AL2HMIBridge.mediaSource.elapsedSeconds <= AL2HMIBridge.mediaSource.totalSeconds))
			progress: AL2HMIBridge.mediaSource.scanningProgress;
			maximumValue: AL2HMIBridge.mediaSource.maxScanningProgressValue
			currentTrack: AL2HMIBridge.mediaSource.mediaCurrentObject
			totalTracks: AL2HMIBridge.mediaSource.mediaTotalObjects
			trackInfoPos: Text.AlignHCenter
			onJumpTo: _hmiMedia.mediaController.requestMediaJump(pos)
	}
	
	VideoTrackControlButtons {
		id: trackControlButtons
		opacity: 1.0
		visible: VideoPlayerPipe.isActive
		enabled: (opacity == 1) // Enable the buttons only when opacity is 1 (GUI elements visible)
		
		anchors.bottom: parent.bottom
		anchors.horizontalCenter: parent.horizontalCenter
		anchors.bottomMargin: 20
	
		playing:(AL2HMIBridge.mediaSource.audioStatus === AL2HMIBridge.MediaSource.Playing)
		backButtonActive: isTrackBackButtonActive
	
		onPreviousClicked: _hmiMedia.mediaController.mediaPrevious()
		onPreviousPressAndHold: _hmiMedia.mediaController.mediaPreviousLong(AL2HMIBridge.MediaSource.Pressed)
		onPreviousHoldAndReleased: _hmiMedia.mediaController.mediaPreviousLong(AL2HMIBridge.MediaSource.Released)
	
		onPlayPauseClicked: _hmiMedia.mediaController.mediaTogglePlayPause()
	
		onNextClicked: _hmiMedia.mediaController.mediaNext()
		onNextPressAndHold: _hmiMedia.mediaController.mediaNextLong(AL2HMIBridge.MediaSource.Pressed)
		onNextHoldAndReleased: _hmiMedia.mediaController.mediaNextLong(AL2HMIBridge.MediaSource.Released)
	}
	
	NumberAnimation { // Remove Opacity
		id: removeOpacity
		targets: [trackControlButtons, videoProgressBar, root.titleBarObject]
		properties: "opacity"
		from: 1.0
		to: 0.0
		duration: 500
	}
	
	NumberAnimation { // Restore Opacity
		id: restoreOpacity
		targets: [trackControlButtons, videoProgressBar, root.titleBarObject]
		properties: "opacity"
		from: 0.0
		to: 1.0
		duration: 500
	}

    customTitle: RowLayout {
        anchors {
            fill: parent
            leftMargin: backButton.width + UiTheme.styleRoot.generalMarginSmall
        }

        LayoutMirroring.enabled: false
        spacing: 0

        HorizontallyScrolledTextLabel {
            id: titleLabel
            objectName: "SongInformationView_titleLabel"

            isButtonText: false
            text: songTitle

            Layout.fillHeight: true
            Layout.fillWidth: true
            Layout.rightMargin: UiTheme.styleRoot.generalMarginSmall
        }

        HmiImage {
            id: separator

            anchors.verticalCenter: hearIt_IconTextPushButton_SongInformationPage.verticalCenter
            source: UiTheme.palette.image(root._styleStatusBar.seperatorImage)
        }

        IconTextPushButton {
            id: hearIt_IconTextPushButton_SongInformationPage
            objectName: "SongInformationPage_hearIt_IconTextPushButton_SongInformationPage"

            shape: HmiGui.Flatter
            size: HmiGui.Small
            iconId: "shared/icon_hearit"
            active: !AL2HMIBridge.phoneSource.incomingCallActive && !AL2HMIBridge.phoneSource.callConnected
            //~ TextID 38488dea-e6f6-11e7-af74-08002718b8d7
            text: qsTr("Hear It")
            textLocation: ViewController.rightToLeftLanguageActive ? HmiGui.Left : HmiGui.Right
            backgroundSource: UiTheme.palette.getImageForDomain(_styleStatusBar.statusBarButtonPressedImage,
                                                                hearIt_IconTextPushButton_SongInformationPage.domain)
            showBackground: hearIt_IconTextPushButton_SongInformationPage.buttonState === HmiGui.Pressed

            onClicked: _hmiMedia.mediaController.hearMediaTrackType()
        }
    }

    +    model: VideoPlayerPipe.isActive ? false : (AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.Music ? musicModel() :
                                                                           AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.ItunesRadio ? itunesMusicModel() :
                                                                                                                                                AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.AudioBook ? audioBookModel() :
                                                                                                                                                                                                                   AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.PodCast ? podCastModel() : []).filter(labelNonEmpty)


    function labelNonEmpty(row) {
        return row.label !== ""
    }

    function musicModel() {
        return [{ "label": AL2HMIBridge.mediaSource.album, "icon": "media/icon_album" },
                { "label": AL2HMIBridge.mediaSource.artist, "icon": "media/icon_artistlist" },
                { "label": AL2HMIBridge.mediaSource.composer, "icon": "media/icon_author" },
                { "label": AL2HMIBridge.mediaSource.genre, "icon": "media/icon_boxes" },
                { "label": AL2HMIBridge.mediaSource.filename, "icon": "media/icon_file" },
                { "label": AL2HMIBridge.mediaSource.foldername, "icon": "media/icon_folder" }]
    }

    function itunesMusicModel() {
        return [{ "label": AL2HMIBridge.mediaSource.album, "icon": "media/icon_album" },
                { "label": AL2HMIBridge.mediaSource.artist, "icon": "media/icon_artistlist" },
                { "label": AL2HMIBridge.mediaSource.composer, "icon": "media/icon_author" },
                { "label": AL2HMIBridge.mediaSource.genre, "icon": "media/icon_boxes" },
                { "label": AL2HMIBridge.mediaSource.filename, "icon": "media/icon_file" },
                { "label": AL2HMIBridge.mediaSource.foldername, "icon": "media/icon_folder" }]
    }


    function audioBookModel() {
        return [{ "label": AL2HMIBridge.mediaSource.artist, "icon": "media/icon_author" }, // Author
                { "label": AL2HMIBridge.mediaSource.composer, "icon": "media/icon_narrator" }, // Narrator
                { "label": AL2HMIBridge.mediaSource.chapter, "icon": "media/icon_chapter" },
                { "label": AL2HMIBridge.mediaSource.genre, "icon": "media/icon_boxes" },
                { "label": AL2HMIBridge.mediaSource.filename, "icon": "media/icon_file" },
                { "label": AL2HMIBridge.mediaSource.foldername, "icon": "media/icon_folder" }]
    }

    function podCastModel() {
        return [{ "label": AL2HMIBridge.mediaSource.artist, "icon": "media/icon_episode" }, // Episode
                { "label": AL2HMIBridge.mediaSource.composer, "icon": "media/icon_author" }, // Author
                { "label": AL2HMIBridge.mediaSource.genre, "icon": "media/icon_boxes" },
                { "label": AL2HMIBridge.mediaSource.filename, "icon": "media/icon_file" },
                { "label": AL2HMIBridge.mediaSource.foldername, "icon": "media/icon_folder" }]
    }
}
