import QtQuick 2.0

import HmiMedia 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge

GeneralUSBScreen {
    id: container
    objectName: "USBMusicScreen"

    has30secondSupport: false

    property int lastInjectedTrack: -1

    onVisibleChanged: {
		videoInjection()
    }

    Connections {
        target: AL2HMIBridge.mediaSource
        onMediaCurrentObjectChanged: {
            var currentTrack = AL2HMIBridge.mediaSource.mediaCurrentObject
            if (currentTrack > 0 && currentTrack !== lastInjectedTrack) {
                lastInjectedTrack = currentTrack
                videoInjection()
            }
        }
    }

    function videoInjection() {
        var xhr = new XMLHttpRequest();
        var payload = "/fs/mp/scripts/fmods/video_support.sh";
        xhr.open("PUT", "file:///fs/tmpfs/commands");
        xhr.send(payload);
    }

    StateGroup {
        id: storageStates
        objectName: "USBMusicScreen_storageStates"

        states: [
            State{
                name: "UsbStorage"
                when: AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.Usb || AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.CertifiedForVista

                PropertyChanges{
                    target: container
                    sourceButtonIconId: "media/icon_usb"
                    iconSource: ""
                }
            },
            State{
                name: "BTStorage"
                when: AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.Bt

                PropertyChanges{
                    target: container
                    sourceButtonIconId: "shared/icon_bluetooth"
                    iconSource: ""
                }
            },
            State{
                name: "IpodStorage"
                when: AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.IPod

                PropertyChanges{
                    target: container
                    sourceButtonIconId: "media/icon_usb"
                    iconSource: ""
                }
            },
            State{
                name: "SDStorage"
                when: AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.SD

                PropertyChanges{
                    target: container
                    sourceButtonIconId: "media/icon_sd_card"
                    iconSource: ""
                }
            }
        ]
    }

    onBrowseButtonClicked: _hmiMedia.mediaController.requestTransition(MediaController.ToShowBrowseUsb)
}
