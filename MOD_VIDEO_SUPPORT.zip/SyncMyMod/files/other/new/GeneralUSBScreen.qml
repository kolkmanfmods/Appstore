import QtQuick 2.0

import HmiMedia 1.0
import HmiGui 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0
import HmiMedia 1.0
import HmiCore 1.0
import Hmi.Ford 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge
import QtGraphicalEffects 1.0
import Hmi.Ford.Views 1.0
import HmiGuiFramework.Transitions 1.0
import HmiGuiFramework 1.0

import "../MediaUtils.js" as MediaUtils

ExtendedMediaScreen {
    id: container
    objectName: "GeneralUsbScreen_container"
	
	property bool videoActive: VideoPlayerPipe.isActive
    property int selectedDevice: _hmiMedia.mediaController.lastSelectedDevice;
    property bool has30secondSupport: true
    property bool hasThumbsButtonSupport: false
    property bool isTrackBackButtonActive: true
    property string iconSource:""

    property alias hasShuffleSupport: shuffleButtons.hasShuffleSupport
    property alias hasRepeatSupport: shuffleButtons.hasRepeatSupport
    property alias deviceName: deviceName.text
    property string deviceTitle: ""
    property bool songInformationSupported: true
    property bool passengerExpectionAvailable: DrivingRestrictions.inUSConditionally(AL2HMIBridge.globalSource.driverRestrictionsGeneralAppsActive)
                                               && AL2HMIBridge.globalSource.passengerAvailable
                                               && !_hmiMedia.mediaController.passengerExceptionReset
    signal browseButtonClicked()

    property bool infoButtonAvailable: !AL2HMIBridge.mediaSource.endOfLastSongRepeatOff && AL2HMIBridge.mediaSource.mediaPlayerTrackType!== AL2HMIBridge.MediaSource.ItunesRadio

    background: [
        Loader {
            id: albumArtBackgroundLoader
            anchors {
                top: parent.top
                bottom: parent.bottom
                right: parent.right
                left: parent.horizontalCenter
            }
            sourceComponent: albumArtBackgroundComponent
            active: container.visible
        }

    ]
	
	onVideoActiveChanged: { if (VideoPlayerPipe.isActive) _hmiMedia.mediaController.requestTransition(MediaController.ToShowSongInformationUsb) }

    topRightButtons: [
        MediaTextButton {
            id: browseButton
            objectName: "GeneralUsbScreen_browseButton"

            size: HmiGui.Bigger

            //~ TextID 9463136e-a883-11e3-97ec-c8d719f8cdfe
            text: qsTr("Browse")
            textComponent.variation: HmiGui.SemiBigLabelMediaVariation
            onClicked: {
                if (passengerExpectionAvailable) {
                    ViewController.showDriverRestrictionPopup(ViewController.DriverRestrictionTypeKPopup,MediaController.TemplatedBrowseItem);
                } else {
                    container.browseButtonClicked()
                }
            }
            visible: MediaUtils.browseVisible()
        }
    ]

    rightContentItem: [
        Loader {
            id: albumArtLoader
            anchors.centerIn: parent
            sourceComponent: albumArtComponent
            active: container.visible
        }
    ]

    topContainer: [
        Row {
            id: titleContainer

            anchors {
                horizontalCenter: parent.horizontalCenter
                top: topLeftButtonRow.top
                bottom: topLeftButtonRow.bottom
            }

            LayoutMirroring.enabled: ViewController.rightToLeftLanguageActive

            HmiImage {
                id:sourceIcon
                anchors {
                    verticalCenter: parent.verticalCenter
                }
                source: UiTheme.palette.icon(iconSource, "_active", HmiGui.IconMedium)
            }
            TextLabel {
                id: deviceName
                //If the width of the device name is wider than the given space it will be shortened to the avaiable space
                width: Math.min(implicitWidth, 344)
                anchors {
                    verticalCenter: parent.verticalCenter
                    verticalCenterOffset: UiTheme.styleRoot.generalMarginTiny
                }
                variation: HmiGui.SmallLabelMediaVariation
                text: MediaUtils.getMediaDeviceName(AL2HMIBridge.mediaSource.curSelectedDevice)
                elide: Text.ElideRight
            }
        }
    ]


    content: [
        Item {
            anchors.fill: parent
            anchors.leftMargin: UiTheme.styleRoot.globalMarginNarrow

            PlaybackScreenInfoContent {
                id: usbInfoContent
                draggingSupported: AL2HMIBridge.mediaSource.progressBarJumpSupported
                elapsedTime: MediaUtils.getElapsedTime(dragging, draggingValue, AL2HMIBridge.mediaSource.totalHours,
                                                       AL2HMIBridge.mediaSource.totalMinutes, AL2HMIBridge.mediaSource.totalSeconds, AL2HMIBridge.mediaSource.elapsedHours,
                                                       AL2HMIBridge.mediaSource.elapsedMinutes, AL2HMIBridge.mediaSource.elapsedSeconds)

                elapsedTimeVisible: AL2HMIBridge.mediaSource.endOfLastSongRepeatOff ? false
                                                                        : AL2HMIBridge.mediaSource.totalHours !== AL2HMIBridge.mediaSource.elapsedHours
                                                                          || AL2HMIBridge.mediaSource.totalMinutes !== AL2HMIBridge.mediaSource.elapsedMinutes
                                                                          || AL2HMIBridge.mediaSource.totalSeconds !== AL2HMIBridge.mediaSource.elapsedSeconds
                totalTime: FormattingUtils.formatTimer(AL2HMIBridge.mediaSource.totalHours,
                                                       AL2HMIBridge.mediaSource.totalMinutes,
                                                       AL2HMIBridge.mediaSource.totalSeconds)

                //The progress bar and total play time shall not be displayed if the total play time is unknown or equal to 0.
                //The progress bar and total play time shall not be displayed if the elapsed time is greater than the total time or
                //equals -1 (Hex 0xFFFFFFFF).
                //The progress bar and total play time shall not be displayed if the total play time equals -1 (Hex 0xFFFFFFFF)
                totalTimeVisible: AL2HMIBridge.mediaSource.endOfLastSongRepeatOff ? false
                                                                      : (AL2HMIBridge.mediaSource.totalHours > 0
                                                                         || AL2HMIBridge.mediaSource.totalMinutes > 0
                                                                         || AL2HMIBridge.mediaSource.totalSeconds > 0)
                                                                        && (AL2HMIBridge.mediaSource.elapsedHours >= 0
                                                                            && AL2HMIBridge.mediaSource.elapsedMinutes >= 0
                                                                            && AL2HMIBridge.mediaSource.elapsedSeconds >= 0)
                                                                        && (AL2HMIBridge.mediaSource.elapsedHours < AL2HMIBridge.mediaSource.totalHours
                                                                            || (AL2HMIBridge.mediaSource.elapsedHours == AL2HMIBridge.mediaSource.totalHours
                                                                                && AL2HMIBridge.mediaSource.elapsedMinutes < AL2HMIBridge.mediaSource.totalMinutes)
                                                                            || (AL2HMIBridge.mediaSource.elapsedHours == AL2HMIBridge.mediaSource.totalHours
                                                                                && AL2HMIBridge.mediaSource.elapsedMinutes ==AL2HMIBridge.mediaSource.totalMinutes
                                                                                && AL2HMIBridge.mediaSource.elapsedSeconds <= AL2HMIBridge.mediaSource.totalSeconds))
                progress: AL2HMIBridge.mediaSource.scanningProgress;
                maximumValue: AL2HMIBridge.mediaSource.maxScanningProgressValue
                artist: AL2HMIBridge.mediaSource.artist
                songTitle: AL2HMIBridge.mediaSource.title
                album: AL2HMIBridge.mediaSource.album
                currentTrack: AL2HMIBridge.mediaSource.mediaCurrentObject
                totalTracks: AL2HMIBridge.mediaSource.mediaTotalObjects
                trackInfoPos: Text.AlignHCenter
                onJumpTo: _hmiMedia.mediaController.requestMediaJump(pos)
                trackInformationVariation: HmiGui.SmallLabelMediaVariation
            }
            states: [
                State{
                    name: "musicSource"
                    when: AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.Music
                    PropertyChanges {
                        target: usbInfoContent

                        artist: AL2HMIBridge.mediaSource.artist
                        songTitle: AL2HMIBridge.mediaSource.title
                        album: AL2HMIBridge.mediaSource.album
                    }
                },
                State{
                    name: "iTunesMusicSource"
                    when: AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.ItunesRadio
                    PropertyChanges {
                        target: usbInfoContent

                        artist: AL2HMIBridge.mediaSource.artist
                        songTitle: AL2HMIBridge.mediaSource.title
                        album: ""
                    }
                },
                State{
                    name: "audioBookSource"
                    when: AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.AudioBook
                    PropertyChanges {
                        target: usbInfoContent

                        artist: AL2HMIBridge.mediaSource.title
                        songTitle: AL2HMIBridge.mediaSource.chapter
                        album: AL2HMIBridge.mediaSource.artist
                    }
                },
                State{
                    name: "podcastSource"
                    when: AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.PodCast
                    PropertyChanges {
                        target: usbInfoContent

                        artist: AL2HMIBridge.mediaSource.title
                        songTitle: AL2HMIBridge.mediaSource.artist
                        album: AL2HMIBridge.mediaSource.composer
                    }
                }
            ]
        }
    ]

    controlButtonsContent: [
        TrackControlButtons {
            id: trackControlButtons_GeneralUsbScreen

            anchors.left: parent.left

            width: childrenRect.width
            height: childrenRect.height

            playing:(AL2HMIBridge.mediaSource.audioStatus === AL2HMIBridge.MediaSource.Playing)
            show30Button: has30secondSupport
            showThumbsButtons: hasThumbsButtonSupport
            backButtonActive: isTrackBackButtonActive

            thumbsUpButtonStatus: AL2HMIBridge.mediaSource.thumbsUpButtonSelectedStatus
            thumbsDownButtonStatus: AL2HMIBridge.mediaSource.thumbsDownButtonSelectedStatus

            onPrevious30Clicked: _hmiMedia.mediaController.previous30SecPressed()

            onPreviousClicked: _hmiMedia.mediaController.mediaPrevious()
            onPreviousPressAndHold: _hmiMedia.mediaController.mediaPreviousLong(AL2HMIBridge.MediaSource.Pressed)
            onPreviousHoldAndReleased: _hmiMedia.mediaController.mediaPreviousLong(AL2HMIBridge.MediaSource.Released)

            onPlayPauseClicked: _hmiMedia.mediaController.mediaTogglePlayPause()

            onNextClicked: _hmiMedia.mediaController.mediaNext()
            onNextPressAndHold: _hmiMedia.mediaController.mediaNextLong(AL2HMIBridge.MediaSource.Pressed)
            onNextHoldAndReleased: _hmiMedia.mediaController.mediaNextLong(AL2HMIBridge.MediaSource.Released)

            onNext30Clicked: _hmiMedia.mediaController.next30SecPressed()

            onThumbsDownClicked: _hmiMedia.mediaController.toggleThumbsDownStatus()
            onThumbsUpClicked: _hmiMedia.mediaController.toggleThumbsUpStatus()
        },
        ShuffleButtons {
            id: shuffleButtons
            objectName: "CDScreen_shuffleButtons"

            anchors.left: trackControlButtons_GeneralUsbScreen.right
            anchors.leftMargin: UiTheme.styleRoot.generalMarginSmall

            width: childrenRect.width

            hasShuffleSupport: AL2HMIBridge.mediaSource.shuffleSupported
            hasRepeatSupport: AL2HMIBridge.mediaSource.repeatSupported

            onShuffleClicked: _hmiMedia.mediaController.mediaShuffle()
            onRepeatClicked: _hmiMedia.mediaController.mediaRepeat()

            shuffleStatus: AL2HMIBridge.mediaSource.shuffleStatus
            repeatStatus: AL2HMIBridge.mediaSource.repeatStatus !== AL2HMIBridge.MediaSource.None


            repeatIconId: AL2HMIBridge.mediaSource.repeatStatus === AL2HMIBridge.MediaSource.Single
                          ? "media/icon_repeat_1x" : "media/icon_repeat"
        }
    ]

    Component{
        id: albumArtComponent

        Item {
            id: albumArtContainer

            anchors.fill: parent

            HmiBorderImage {
                id: _dropShadow
                source: UiTheme.palette.image("media/postage_stamp_drop_shadow")
                width: albumArt.width + 80
                height: albumArt.height + 40
                border {
                    left: 40
                    top: 0
                    right: 40
                    bottom: 40
                }

                anchors {
                    centerIn: parent
                    verticalCenterOffset: 27
                }
                visible: false
            }

            Rectangle {
                id: _opacityMask
                anchors.fill: _dropShadow
                color: "#88FFFFFF"
                visible: false
            }

            OpacityMask {
                id: dropShadowMask
                anchors.fill: _dropShadow
                source: _dropShadow
                maskSource: _opacityMask
                visible: parent.visible
            }

            CoverAlbumButton {
                id: albumArt

                anchors.centerIn: parent

                infoButtonAvailable: container.infoButtonAvailable
                coverArtAvailable: AL2HMIBridge.mediaSource.coverArtAvailable
				coverArtSource: if (AL2HMIBridge.mediaSource.coverArtAvailable && AL2HMIBridge.mediaSource.coverArt !== "" && !AL2HMIBridge.globalSource.driverRestrictionsAlbumArtActive && !AL2HMIBridge.mediaSource.endOfLastSongRepeatOff) {
									AL2HMIBridge.mediaSource.coverArt
								} else {
									!VideoPlayerPipe.isActive ? UiTheme.palette.image("media/PlaceholderCoverArt-Media") : UiTheme.palette.image("media/PlaceholderCoverArt-Video")
								}

                albumArtObjectName: "albumArt_GeneralUSBScreen"

                onClicked: _hmiMedia.mediaController.requestTransition(MediaController.ToShowSongInformationUsb)
            }
        }
    }

    Component {
        id: albumArtBackgroundComponent
        MediaAlbumArtBackground {
            id: albumArtBackgroundContainer
            albumArtObjectName: "GeneralUSBScreen_albumArtBackground"

            visible: AL2HMIBridge.globalSource.regionalVariant !== AL2HMIBridge.GlobalSource.NorthAmerica

            anchors.fill: parent

            coverArtSource: if (AL2HMIBridge.mediaSource.coverArtAvailable && AL2HMIBridge.mediaSource.coverArt !== "" && !AL2HMIBridge.globalSource.driverRestrictionsAlbumArtActive && !AL2HMIBridge.mediaSource.endOfLastSongRepeatOff) {
								AL2HMIBridge.mediaSource.coverArt
							} else {
								!VideoPlayerPipe.isActive ? UiTheme.palette.image("media/PlaceholderCoverArt-Media") : UiTheme.palette.image("media/PlaceholderCoverArt-Video")
							} 
        }
    }
}
