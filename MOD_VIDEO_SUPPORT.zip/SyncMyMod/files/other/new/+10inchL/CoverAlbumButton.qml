import QtQuick 2.0

import HmiGui 1.0

import Hmi.Ford.Controls 1.0

Item {
    id: root
    property alias mouseArea_CoverAlbumButton_squishID: mouseArea_CoverAlbumButton.squishID


    property bool coverArtShown: false
    property bool endOfPlayList:false
    property alias coverArtSource: coverAlbum.source


    signal clicked

    height: coverAlbum.height
    width: infoButton.width

    HmiImage {
        id: coverAlbum

        height: infoButton.visible ? 130 : 170
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: infoButton.visible ? infoButton.top : parent.bottom
        fillMode: Image.PreserveAspectFit

        HmiImage {
            id: infoIcon

            visible: root.coverArtShown && !VideoPlayerPipe.isActive

            source: UiTheme.palette.icon("shared/icon_info", "_active", HmiGui.IconSmall)

            anchors.right: parent.right
            anchors.rightMargin: UiTheme.styleRoot.generalMarginSmall + (coverAlbum.width - coverAlbum.paintedWidth) / 2
            anchors.bottom: parent.bottom
            anchors.bottomMargin: UiTheme.styleRoot.generalMarginSmall + (coverAlbum.height - coverAlbum.paintedHeight) / 2
        }

        MouseArea {
            id: mouseArea_CoverAlbumButton
            property string squishID
            anchors.fill: parent
            enabled: root.coverArtShown && ! root.endOfPlayList
            property bool beepOnClick: true
            onClicked: {
                root.clicked()
                ViewController.buttonClicked(mouseArea_CoverAlbumButton)
            }
        }
    }
}
