import QtQuick 2.0

import HmiMedia 1.0
import HmiGui 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0
import Hmi.Ford 1.0
import HmiMedia 1.0
import HmiCore 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge
import QtQuick.Layouts 1.2
import Hmi.Ford.Views 1.0
import HmiGuiFramework.Transitions 1.0
import HmiGuiFramework 1.0

import "../MediaUtils.js" as MediaUtils



ExtendedMediaScreen {
    id: container
    property bool videoActive: VideoPlayerPipe.isActive
    property int selectedDevice: _hmiMedia.mediaController.lastSelectedDevice
    property bool has30secondSupport: true
    property bool hasThumbsButtonSupport: false
    property bool isTrackBackButtonActive: true
    property bool songInformationSupported: true

    property alias hasShuffleSupport: shuffleButtons.hasShuffleSupport
    property alias hasRepeatSupport: shuffleButtons.hasRepeatSupport
    property alias deviceName: deviceName.text
    property bool passengerExpectionAvailable: DrivingRestrictions.inUSConditionally(AL2HMIBridge.globalSource.driverRestrictionsGeneralAppsActive)
                                               && AL2HMIBridge.globalSource.passengerAvailable
                                               && !_hmiMedia.mediaController.passengerExceptionReset
    signal browseButtonClicked()

    onVideoActiveChanged: { if (VideoPlayerPipe.isActive) _hmiMedia.mediaController.requestTransition(MediaController.ToShowSongInformationUsb) }

    topRightButtons: [
        TextPushButton {
            id: browseButton
            objectName: "GeneralUsbScreen_browseButton"
            property string squishID

            shape: HmiGui.Square
            size: HmiGui.Large

            //~ TextID 9463136e-a883-11e3-97ec-c8d719f8cdfe
            text: qsTr("Browse")
            onClicked: {
                if (passengerExpectionAvailable) {
                    ViewController.showDriverRestrictionPopup(ViewController.DriverRestrictionTypeKPopup,MediaController.TemplatedBrowseItem);
                } else {
                    container.browseButtonClicked();
                }
            }
            //Visible when set to false disrupts the whole layout,since all the components are dependent on the topRightButtons component.
            //Hence Opacity and Active together are being used as an alternative.

            active:  MediaUtils.browseVisible()
            opacity:  active ? 1.0 : 0.0
        }
    ]

    HmiImage {
        id: albumArt
        sourceSize: Qt.size(180, 180)
        fillMode: Image.PreserveAspectFit
        anchors.horizontalCenter: sourceButton.horizontalCenter
        anchors.top: sourceButton.bottom
        anchors.topMargin: UiTheme.styleRoot.generalMarginSmall*2
        source: AL2HMIBridge.mediaSource.coverArtAvailable ? AL2HMIBridge.mediaSource.coverArt : ""
        visible: !AL2HMIBridge.globalSource.driverRestrictionsAlbumArtActive && !AL2HMIBridge.mediaSource.endOfLastSongRepeatOff
    }

    title: TextLabel {
        id: deviceName
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        variation: HmiGui.LargeLabelVariationMedium
        text: MediaUtils.getMediaDeviceName(AL2HMIBridge.mediaSource.curSelectedDevice)
        elide: Text.ElideRight
    }


    content: Item {
        width: UiTheme.styleRoot.gridSizes.rightColumn1Right - UiTheme.styleRoot.gridSizes.column1Left

        PlaybackScreenInfoContent {
            id: playbackInfo
            draggingSupported: AL2HMIBridge.mediaSource.progressBarJumpSupported
            elapsedTime: dragOperationInProgress ? (FormattingUtils.formatTimerSeconds(Math.round((AL2HMIBridge.mediaSource.totalHours * 3600
                                                                        + AL2HMIBridge.mediaSource.totalMinutes * 60
                                                                        + AL2HMIBridge.mediaSource.totalSeconds)
                                                                        * displayedValue)))
                                  : FormattingUtils.formatTimer(AL2HMIBridge.mediaSource.elapsedHours, AL2HMIBridge.mediaSource.elapsedMinutes, AL2HMIBridge.mediaSource.elapsedSeconds)

            elapsedTimeVisible: AL2HMIBridge.mediaSource.endOfLastSongRepeatOff ? false
                                                                    : AL2HMIBridge.mediaSource.totalHours !== AL2HMIBridge.mediaSource.elapsedHours
                                                                      || AL2HMIBridge.mediaSource.totalMinutes !== AL2HMIBridge.mediaSource.elapsedMinutes
                                                                      || AL2HMIBridge.mediaSource.totalSeconds !== AL2HMIBridge.mediaSource.elapsedSeconds
            totalTime: FormattingUtils.formatTimer(AL2HMIBridge.mediaSource.totalHours,
                                                   AL2HMIBridge.mediaSource.totalMinutes,
                                                   AL2HMIBridge.mediaSource.totalSeconds)

            //The progress bar and total play time shall not be displayed if the total play time is unknown or equal to 0.
            //The progress bar and total play time shall not be displayed if the elapsed time is greater than the total time or
            //equals -1 (Hex 0xFFFFFFFF).
            //The progress bar and total play time shall not be displayed if the total play time equals -1 (Hex 0xFFFFFFFF)
            totalTimeVisible: AL2HMIBridge.mediaSource.endOfLastSongRepeatOff ? false
                                                                  : (AL2HMIBridge.mediaSource.totalHours > 0
                                                                     || AL2HMIBridge.mediaSource.totalMinutes > 0
                                                                     || AL2HMIBridge.mediaSource.totalSeconds > 0)
                                                                    && (AL2HMIBridge.mediaSource.elapsedHours >= 0
                                                                        && AL2HMIBridge.mediaSource.elapsedMinutes >= 0
                                                                        && AL2HMIBridge.mediaSource.elapsedSeconds >= 0)
                                                                    && (AL2HMIBridge.mediaSource.elapsedHours < AL2HMIBridge.mediaSource.totalHours
                                                                        || (AL2HMIBridge.mediaSource.elapsedHours === AL2HMIBridge.mediaSource.totalHours
                                                                            && AL2HMIBridge.mediaSource.elapsedMinutes < AL2HMIBridge.mediaSource.totalMinutes)
                                                                        || (AL2HMIBridge.mediaSource.elapsedHours === AL2HMIBridge.mediaSource.totalHours
                                                                            && AL2HMIBridge.mediaSource.elapsedMinutes ===AL2HMIBridge.mediaSource.totalMinutes
                                                                            && AL2HMIBridge.mediaSource.elapsedSeconds <= AL2HMIBridge.mediaSource.totalSeconds))
            progress: AL2HMIBridge.mediaSource.scanningProgress;
            maximumValue: AL2HMIBridge.mediaSource.maxScanningProgressValue
            artist: AL2HMIBridge.mediaSource.artist
            songTitle: AL2HMIBridge.mediaSource.title
            currentTrack: AL2HMIBridge.mediaSource.mediaCurrentObject
            totalTracks: AL2HMIBridge.mediaSource.mediaTotalObjects
            wishListVisible: hasWishlistSupport

            anchors.top: parent.top
            anchors.left: parent.left
            anchors.right: parent.right
            height: childrenRect.height
        }

        TrackControlButtons {
            id: trackControlButtons_GeneralUsbScreen

            anchors.top: playbackInfo.bottom
            anchors.topMargin: 7

            anchors.horizontalCenter: parent.horizontalCenter
            height: 207

            playing:(AL2HMIBridge.mediaSource.audioStatus === AL2HMIBridge.MediaSource.Playing)

            show30Button: has30secondSupport
            showThumbsButtons: hasThumbsButtonSupport
            backButtonActive: isTrackBackButtonActive

            thumbsUpButtonStatus: AL2HMIBridge.mediaSource.thumbsUpButtonSelectedStatus
            thumbsDownButtonStatus: AL2HMIBridge.mediaSource.thumbsDownButtonSelectedStatus

            onPrevious30Clicked: _hmiMedia.mediaController.previous30SecPressed()

            onPreviousClicked: _hmiMedia.mediaController.mediaPrevious()
            onPreviousPressAndHold: _hmiMedia.mediaController.mediaPreviousLong(AL2HMIBridge.MediaSource.Pressed)
            onPreviousHoldAndReleased: _hmiMedia.mediaController.mediaPreviousLong(AL2HMIBridge.MediaSource.Released)

            onPlayPauseClicked: _hmiMedia.mediaController.mediaTogglePlayPause()

            onNextClicked: _hmiMedia.mediaController.mediaNext()
            onNextPressAndHold: _hmiMedia.mediaController.mediaNextLong(AL2HMIBridge.MediaSource.Pressed)
            onNextHoldAndReleased: _hmiMedia.mediaController.mediaNextLong(AL2HMIBridge.MediaSource.Released)

            onNext30Clicked: _hmiMedia.mediaController.next30SecPressed()

            onThumbsDownClicked: _hmiMedia.mediaController.toggleThumbsDownStatus()
            onThumbsUpClicked: _hmiMedia.mediaController.toggleThumbsUpStatus()
        }

        ShuffleButtons {
            id: shuffleButtons
            height: childrenRect.height

            anchors.left: parent.left
            anchors.leftMargin: -1
            anchors.verticalCenter: trackControlButtons_GeneralUsbScreen.verticalCenter
            anchors.verticalCenterOffset: 31

            hasShuffleSupport: AL2HMIBridge.mediaSource.shuffleSupported
            hasRepeatSupport: AL2HMIBridge.mediaSource.repeatSupported

            onShuffleClicked: _hmiMedia.mediaController.mediaShuffle()
            onRepeatClicked: _hmiMedia.mediaController.mediaRepeat()

            shuffleStatus: AL2HMIBridge.mediaSource.shuffleStatus
            shuffleIconId: "media/icon_shuffle"

            repeatStatus: AL2HMIBridge.mediaSource.repeatStatus !== AL2HMIBridge.MediaSource.None

            repeatIconId: AL2HMIBridge.mediaSource.repeatStatus === AL2HMIBridge.MediaSource.Single
                          ? "media/icon_repeat_1x" : "media/icon_repeat"
        }

        HmiImage {
            id: _img_shuffloopEmboss
            anchors.verticalCenter: shuffleButtons.verticalCenter
            anchors.horizontalCenter: shuffleButtons.horizontalCenter
            anchors.horizontalCenterOffset: 1
            visible: hasShuffleSupport || hasRepeatSupport

            source: UiTheme.palette.image("media/button_shuffle_loop_background")
        }

        Item {

            anchors.horizontalCenter: parent.right
            anchors.horizontalCenterOffset: -(UiTheme.styleRoot.gridSizes.horizontalSpacing/2 + UiTheme.styleRoot.gridSizes.columnWidth - 18)
            anchors.verticalCenter: trackControlButtons_GeneralUsbScreen.verticalCenter
            anchors.verticalCenterOffset: 13

            width: childrenRect.width
            height: childrenRect.height

            IconPushButton {
                id: infoButton
                objectName: "GeneralUsbScreen_infoButton"

                property string squishID
                anchors.bottom: parent.bottom

                shape: HmiGui.Round
                size: HmiGui.Big
                borderOffset: 0
                visible: !AL2HMIBridge.mediaSource.endOfLastSongRepeatOff && AL2HMIBridge.mediaSource.mediaPlayerTrackType!== AL2HMIBridge.MediaSource.ItunesRadio
                iconId: !VideoPlayerPipe.isActive ? "shared/icon_info" : "trlink/icon_movie_title"
                iconSize: HmiGui.IconMedium

                onClicked: _hmiMedia.mediaController.requestTransition(MediaController.ToShowSongInformationUsb)
            }

            HmiImage {
                id: _img_infoEmboss
                anchors.centerIn: infoButton
                source: UiTheme.palette.image("media/backward_30_emboss")
                visible: !AL2HMIBridge.mediaSource.endOfLastSongRepeatOff && AL2HMIBridge.mediaSource.mediaPlayerTrackType!== AL2HMIBridge.MediaSource.ItunesRadio
            }
        }
    }
}
