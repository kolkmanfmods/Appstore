import QtQuick 2.0

import HmiGui 1.0

import Hmi.Ford.Controls 1.0


MediaAlbumArt {
    id: coverAlbum
    objectName: "CoverAlbumButton"

    property bool infoButtonAvailable
    property bool coverArtAvailable
    signal clicked

    anchors.centerIn: parent

    HmiImage {
        id: infoIcon
        objectName: "CoverAlbumButton_infoIcon"

        anchors {
            right: parent.right
            rightMargin: 2
            bottom: parent.bottom
            bottomMargin: 2
        }

        visible: mouseArea_CoverAlbumButton.enabled && !VideoPlayerPipe.isActive

        source: UiTheme.palette.icon("media/icon_info", "_active", HmiGui.IconMedium)
    }

    MouseArea {
        id: mouseArea_CoverAlbumButton
        objectName: "CoverAlbumButton_mouseArea_CoverAlbumButton"

        enabled: infoButtonAvailable

        anchors.fill: parent
        property bool beepOnClick: true

        onClicked: {
            coverAlbum.clicked()
            ViewController.buttonClicked(mouseArea_CoverAlbumButton)
        }
    }

}
