import QtQuick 2.0
import HmiGui 1.0
import HmiOverrides 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0
import HmiCore.Instrumentation 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge
import QtGraphicalEffects 1.0

//
// TODO: This file is identical to +ford-MY20/MenuBar.qml
//

TransformableItem {
    id: root
    objectName: "MenuBar"

    readonly property QtObject _style: UiTheme.styleSelect("menuBar", root);
    readonly property QtObject _masterLayout: UiTheme.styleSelect("masterLayout", root)

    signal moduleRequest(int domain, string moduleRootView)

    // Functions provided for the view manager

    function hide() {
        showAnimation.stop();
        hideAnimation.start();
    }

    function hideWithoutAnimation() {
        showAnimation.stop();
        hideAnimation.stop();
        y = _private._menuBarOnScreenY + _masterLayout.menuBarHeight;
    }

    function show() {
        hideAnimation.stop();
        showAnimation.start();
    }

    function showWithoutAnimation() {
        showAnimation.stop();
        hideAnimation.stop();
        y = _private._menuBarOnScreenY;
    }

    function checkMediaEnabled(moduleDomain) {
        if(moduleDomain === HmiGui.MediaDomain) {
            return !AL2HMIBridge.phoneSource.callConnected || (AL2HMIBridge.phoneSource.callConnected && AL2HMIBridge.phoneSource.privateMode && !AL2HMIBridge.phoneSource.muteAudioInPrivacy);
        }
        return true;
    }

    x: _private._menuBarOnScreenX
    y: _private._menuBarOnScreenY
    z: parent && parent.menuBarLayer ? parent.menuBarLayer : 0
    width: _private._menuBarOnScreenWidth
    height: _private._menuBarOnScreenHeight

    QtObject {
        id: _private

        readonly property string    _backgroundUnselectedAsset: "navbar_background"
        readonly property double    _menuBarOnScreenX: _masterLayout.menuBarX
        readonly property double    _menuBarOnScreenY: _masterLayout.menuBarY
        readonly property double    _menuBarOnScreenWidth: _masterLayout.menuBarWidth
        readonly property double    _menuBarOnScreenHeight: _masterLayout.menuBarHeight
        readonly property int       _dividerWidthPx: 2
        readonly property real      _defaultDelegateWidth: (listView.width-_dividerWidthPx)/listView.count

        function getBackgroundAssetPrefix(){
             return "133x108_navbar_background";
        }

        function getPressedAsset(){
             return "133x108_navbar_background_pressed";
        }

        function getDelegateWidth(index){
            return index === listView.count-1 ? _private._defaultDelegateWidth+1 : _private._defaultDelegateWidth;
        }

        function getDelegateIcon(domain, iconUrl, postfix) {
            var iconOverrides = HmiOverrides.iconOverrides;
            if (iconOverrides.indexOf(domain) !== -1) {
                return HmiOverrides.iconOverride(domain, postfix);
            }
            return UiTheme.palette.icon(iconUrl, postfix);
        }

        function getModuleName(domain) {
            var textOverrides = HmiOverrides.nameOverrides;

            if (textOverrides.indexOf(domain) !== -1) {
                return  HmiOverrides.nameOverride(domain);
            }

            switch (domain) {
            case HmiGui.HomeDomain:
                if(AL2HMIBridge.projectionSource.projectionMode === AL2HMIBridge.ProjectionSource.Projection_GAL) {
                    //~ GroupID fordhmi/10p-moduletext-0001
                    //~ TextID c0433c54-5379-11e8-9b8a-08002718b8d7
                    return qsTr("Android Auto", "10inchP-getModuleNameHomeDomain")
                } else if(AL2HMIBridge.projectionSource.projectionMode === AL2HMIBridge.ProjectionSource.Projection_DIO) {
                    //~ GroupID fordhmi/10p-moduletext-0001
                    //~ TextID c0433c55-5379-11e8-9b8a-08002718b8d7
                    return qsTr("Apple CarPlay", "10inchP-appleCarPlayModuleNameHomeDomain")
                } else if (AL2HMIBridge.projectionSource.projectionMode === AL2HMIBridge.ProjectionSource.Projection_CARLIFE) {
                    //~ GroupID fordhmi/10p-moduletext-0001
                    //~ TextID 1c8870e2-06b8-11e8-b98a-0800270422e6
                    return qsTr("Baidu CarLife")
                } else {
                    //~ GroupID fordhmi/10p-moduletext-0001
                    //~ TextID 38488c9e-e6f6-11e7-af74-08002718b8d7
                    return qsTr("Home")
                }
            case HmiGui.PhoneDomain:
                //~ GroupID fordhmi/10p-moduletext-0001
                //~ TextID 38488c9f-e6f6-11e7-af74-08002718b8d7
                return qsTr("Phone")
            case HmiGui.MediaDomain:
                //~ GroupID fordhmi/10p-moduletext-0001
                //~ TextID 38488ca0-e6f6-11e7-af74-08002718b8d7
                return qsTr("Media")
            case HmiGui.AppsDomain:
                //~ GroupID fordhmi/10p-moduletext-0001
                //~ TextID 38488ca1-e6f6-11e7-af74-08002718b8d7
                return qsTr("Apps")
            case HmiGui.NavigationDomain:
                //~ GroupID fordhmi/10p-moduletext-0001
                //~ TextID 38488ca2-e6f6-11e7-af74-08002718b8d7
                return qsTr("Nav")
            case HmiGui.SettingsDomain:
                //~ GroupID fordhmi/10p-moduletext-0001
                //~ TextID 38488ca3-e6f6-11e7-af74-08002718b8d7
                return qsTr("Settings")
            case HmiGui.ClimateDomain:
                //~ GroupID fordhmi/10p-moduletext-0001
                //~ TextID 38488ca4-e6f6-11e7-af74-08002718b8d7
                return qsTr("Climate")
            case HmiGui.AppsGALProjectionDomain:
                //~ GroupID fordhmi/10p-moduletext-0001
                //~ TextID 38488ca6-e6f6-11e7-af74-08002718b8d7
                return qsTr("Android Auto", "10inchP-getModuleNameGALProjectionDomain")
            case HmiGui.AppsDIOProjectionDomain:
                //~ GroupID fordhmi/10p-moduletext-0001
                //~ TextID 38488ca8-e6f6-11e7-af74-08002718b8d7
                return qsTr("Apple CarPlay", "10inchP-appleCarPlayModuleNameHomeDomain2")
            case HmiGui.NavigationProjectionDomain:
                //~ GroupID fordhmi/10p-moduletext-0001
                //~ TextID 38488ca9-e6f6-11e7-af74-08002718b8d7
                return qsTr("Maps")
            default:
                //~ GroupID fordhmi/10p-moduletext-0001
                //~ TextID f6272cdc-269e-11e8-823a-08002718b8d7
                return qsTr("Unknown", "10inchP-defaultModuleTextMenuBar")
            }
        }
    }

    HmiImage {
        // Menu bar background
        anchors {
            left: root.left
            right: root.right
            bottom: root.bottom
        }
        height: sourceSize.height
        source: UiTheme.palette.image(_private._backgroundUnselectedAsset)

        // Dividers are added here so that the opacity mask will hide them
        Row {
            anchors {
                left: parent.left
                right: parent.right
                bottom: parent.bottom
            }
            spacing: _private._defaultDelegateWidth-2

            Repeater {
                objectName: "menuBar_Repeater"
                model: listView.count + 1
                delegate: HmiImage {
                    source: UiTheme.palette.image(_style.delegateStyle.dividerSource)
                    height: _private._menuBarOnScreenHeight-2
                    visible: index !== 0
                }
            }
        }
    }

    // Items to handle selection animation

    Row {
        id: backgroundActiveSource

        height: childrenRect.height
        visible: false
        anchors {
            left: parent.left
            right: parent.right
            bottom: parent.bottom
        }

        Repeater {
            model: listView.count
            delegate: HmiImage {
                source: UiTheme.palette.image(_private.getBackgroundAssetPrefix()+"_highlight")
                width: listView.width/listView.count
                height: sourceSize.height
            }
        }
    }

    Item {
        // Mask source object must have same dimensions as the opacity source
        id: highlightMask

        anchors.fill: backgroundActiveSource
        visible: false

        Rectangle {
            color: Qt.rgba(1,1,1,1) // Not a visible color, just used as an alpha source
            x: animationSource.x
            opacity: animationSource.opacity
            width: animationSource.width
            height: animationSource.height
            anchors.bottom: parent.bottom
        }
    }

    Item {
        id: animationSource

        width: _private.getDelegateWidth(listView.currentIndex)
        height: _private._menuBarOnScreenHeight
        anchors.bottom: highlightMask.bottom
        x: _hmiSettings.controller.hmiRequestedLanguageChange ? (_private._menuBarOnScreenWidth - (_private._menuBarOnScreenWidth/listView.count) - 1)
                                                                          : (listView.currentIndex * _private._defaultDelegateWidth)+1.0 // accomodate 2px-wide divider

        // These are for fading out the current selection when the current domain is not on the menu bar

        opacity: _hmiSettings.controller.hmiRequestedLanguageChange || _menuModuleCollection.containsModule(ViewManager.activeDomain) ? 1.0 : 0.0

        Behavior on opacity {
            NumberAnimation {
                duration: _style.highlightMoveDuration
                easing.type: Easing.InOutQuad
            }
        }

        Behavior on x {
            NumberAnimation {
                duration: _style.highlightMoveDuration
                easing.type: Easing.InOutQuad
            }
        }
    }

    // Drop shadow that follows the current selected item
    HmiBorderImage {
        // drop shadow assets are built against the 133px button backgrounds,
        // hardcoded for now
        readonly property real borderSizeX: 25

        imageSource: UiTheme.palette.image("navbar_dropshadow")
        height: sourceSize.height - 1 // fixes 1px gap on top in night mode
        opacity: animationSource.opacity
        border {
            top: Math.max(sourceSize.height - _private._menuBarOnScreenHeight, 0)
            left: borderSizeX
            right: borderSizeX
            bottom: 0
        }
        anchors {
            left: animationSource.left
            leftMargin: -borderSizeX
            right: animationSource.right
            rightMargin: -borderSizeX
            bottom: animationSource.bottom
        }
    }

    OpacityMask {
        anchors.fill: backgroundActiveSource
        source: backgroundActiveSource
        maskSource: highlightMask
    }

    // List view components

    Component {
        id: navBarButtonDelegate

        Item {
            id: delegateRoot

            readonly property string instrumentationEventName: _private.getModuleName(moduleDomain)
            readonly property bool isActiveDomain: index === listView.currentIndex && _menuModuleCollection.containsModule(ViewManager.activeDomain)

            enabled: ViewController.activeMenuDomains.indexOf(moduleDomain) !== -1 && root.checkMediaEnabled(moduleDomain)
            opacity: enabled ? 1.0 : 0.5

            width: _private.getDelegateWidth(index)
            height: _private._menuBarOnScreenHeight

            // This is a work-around for a segfault caused by binding to ViewManager directly
            Component.onCompleted: ViewManager.activeDomainChanged.connect(handleDomainChange)
            Component.onDestruction: ViewManager.activeDomainChanged.disconnect(handleDomainChange)

            function handleDomainChange(newDomain, oldDomain){
                if(newDomain === moduleDomain){
                    listView.currentIndex = index;
                }
            }

            MouseArea {
                id: itemMouseArea

                property bool beepOnClick: true

                anchors.fill: parent
                onClicked: {
                    root.moduleRequest(moduleDomain, moduleRootView);
                    ViewController.buttonClicked(itemMouseArea);
                    Instrumentation.onButtonClicked(delegateRoot)
                }
            }

            HmiImage {
                // Button pressed highlight
                anchors {
                    left: parent.left
                    right: parent.right
                    bottom: parent.bottom
                }
                source: UiTheme.palette.image(_private.getPressedAsset())
                opacity: itemMouseArea.pressed ? 1.0 : 0.0
                visible: opacity > 0.01
                height: sourceSize.height

                Behavior on opacity {
                    NumberAnimation {
                        duration: 200
                    }
                }
            }

            HmiImage {
                // Icon
                id: moduleIcon

                property string postfix: "_active"
                anchors {
                    horizontalCenter: parent.horizontalCenter
                    top: parent.top
                    topMargin: _style.delegateStyle.iconTopMargin
                }
                width: 50
                height: 50
                fillMode: Image.PreserveAspectFit
                source: _private.getDelegateIcon(moduleDomain, iconUrl, postfix)
            }

            TextLabel {
                // Module name
                id: moduleNameLabel

                anchors {
                    left: parent.left
                    leftMargin: UiTheme.styleRoot.generalMarginSmall
                    right: parent.right
                    rightMargin: UiTheme.styleRoot.generalMarginSmall
                    verticalCenter: moduleIcon.verticalCenter

                    // This is anchored from the vertical center so that it doesn't depend on the actual height of the text element
                    verticalCenterOffset: (11) + _style.delegateStyle.iconBottomMargin + (moduleIcon.height/2)
                }
                elide: Text.ElideRight
                text: _private.getModuleName(moduleDomain)
                horizontalAlignment: Text.AlignHCenter
                color: {
                    if( !isActiveDomain && itemMouseArea.pressed ){
                        return _style.delegateStyle.activatedTextColor;
                    } else if (isActiveDomain && itemMouseArea.pressed) {
                        return _style.delegateStyle.pressedTextColor;
                    } else if (isActiveDomain){
                        return _style.delegateStyle.activatedTextColor;
                    }
                    return _style.delegateStyle.textColor;
                }
                variation: {
                    if( !isActiveDomain && itemMouseArea.pressed ){
                        return _style.delegateStyle.textLabelVariationPressed;
                    } else if (isActiveDomain && itemMouseArea.pressed) {
                        return _style.delegateStyle.textLabelVariationPressed;
                    } else if (isActiveDomain){
                        return _style.delegateStyle.textLabelVariationPressed;
                    }
                    return _style.delegateStyle.textLabelVariation;
                }
            }

            states : [
                State {
                    name:"activepressed"
                    when: !isActiveDomain && itemMouseArea.pressed
                    PropertyChanges {target: moduleIcon; postfix: "_activepressed"}
                },
                State {
                    name:"pressed"
                    when: isActiveDomain && itemMouseArea.pressed
                    PropertyChanges {target: moduleIcon; postfix: "_selectedpressed"}
                },
                State {
                    name:"selected"
                    when: isActiveDomain
                    PropertyChanges {target: moduleIcon; postfix: "_selected"}
                },
                State {
                    name:"active"
                    when: !isActiveDomain
                    PropertyChanges {target: moduleIcon; postfix: "_active"}
                }
            ]
        }
    }

    ListView {
        id: listView

        anchors.fill: root
        orientation: ListView.Horizontal
        interactive: false
        model: _modulesModel
        delegate: navBarButtonDelegate
        currentIndex: 1
        onCurrentIndexChanged: genericAnimationTimer.restart()

        Timer {
            id: genericAnimationTimer
            interval: _style.highlightMoveDuration
            onRunningChanged: {
                if(running){
                    UiTransition.genericUIAnimationStarted();
                } else {
                    UiTransition.genericUIAnimationStopped();
                }
            }
            Component.onDestruction: stop()
        }
    }

    PropertyAnimation {
        id: hideAnimation
        duration: _style.showHideAnimationDuration
        target: root
        property: 'y'
        to: _private._menuBarOnScreenY + _masterLayout.menuBarHeight
    }

    PropertyAnimation {
        id: showAnimation
        duration: _style.showHideAnimationDuration
        target: root
        property: 'y'
        to: _private._menuBarOnScreenY
    }
}
