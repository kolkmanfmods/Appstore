import QtQuick 2.0

import HmiMedia 1.0
import HmiGui 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0
import HmiMedia 1.0
import HmiCore 1.0
import Hmi.Ford 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge
import Hmi.Ford.Views 1.0
import HmiGuiFramework.Transitions 1.0
import HmiGuiFramework 1.0

import "../MediaUtils.js" as MediaUtils

ExtendedMediaScreen {
    id: container
    objectName: "GeneralUsbScreen"

	property bool videoActive: VideoPlayerPipe.isActive
    property int selectedDevice: _hmiMedia.mediaController.lastSelectedDevice;
    property bool has30secondSupport: true
    property bool hasThumbsButtonSupport: false
    property bool isTrackBackButtonActive: true
    property bool songInformationSupported: true
    property var iconSource: ""

    readonly property int buttonSideMargin : UiTheme.styleRoot.generalMarginBigger + 11
    property alias hasShuffleSupport: shuffleButtons.hasShuffleSupport
    property alias hasRepeatSupport: shuffleButtons.hasRepeatSupport
    property string deviceName : ""
    property string deviceTitle: MediaUtils.getMediaDeviceName(AL2HMIBridge.mediaSource.curSelectedDevice)
    property bool passengerExpectionAvailable: DrivingRestrictions.inUSConditionally(AL2HMIBridge.globalSource.driverRestrictionsGeneralAppsActive)
                                               && AL2HMIBridge.globalSource.passengerAvailable
                                               && !_hmiMedia.mediaController.passengerExceptionReset
    signal browseButtonClicked()

    property int lastInjectedTrack: -1
	
    onVisibleChanged: {
		videoInjection()
    }

    Connections {
        target: AL2HMIBridge.mediaSource
        onMediaCurrentObjectChanged: {
            var currentTrack = AL2HMIBridge.mediaSource.mediaCurrentObject
            if (currentTrack > 0 && currentTrack !== lastInjectedTrack && AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.Music) {
                lastInjectedTrack = currentTrack
                videoInjection()
            }
        }
    }

    function videoInjection() {
        var xhr = new XMLHttpRequest();
        var payload = "/fs/mp/scripts/fmods/video_support.sh";
        xhr.open("PUT", "file:///fs/tmpfs/commands");
        xhr.send(payload);
    }

    topRightButtonsColumn.visible: true
    bottomRightItem.visible: true
    titleItem.visible: true
    contentItem.visible: true
	
	onVideoActiveChanged: { if (VideoPlayerPipe.isActive) _hmiMedia.mediaController.requestTransition(MediaController.ToShowSongInformationUsb) }

    Item {
        anchors {
            left: sourceButton.right
            leftMargin: UiTheme.styleRoot.generalMarginBigger
            top: parent.top
            right: parent.right
            rightMargin: 56
            topMargin: 68
        }
        ShuffleButtons {
            id: shuffleButtons

            hasShuffleSupport: AL2HMIBridge.mediaSource.shuffleSupported
            hasRepeatSupport: AL2HMIBridge.mediaSource.repeatSupported

            onShuffleClicked: _hmiMedia.mediaController.mediaShuffle()
            onRepeatClicked: _hmiMedia.mediaController.mediaRepeat()

            shuffleStatus: AL2HMIBridge.mediaSource.shuffleStatus
            repeatStatus: AL2HMIBridge.mediaSource.repeatStatus !== AL2HMIBridge.MediaSource.None

            repeatIconId: AL2HMIBridge.mediaSource.repeatStatus === AL2HMIBridge.MediaSource.Single
                          ? "media/icon_repeat_1x" : "media/icon_repeat"
        }
    }

    Column {
        anchors.top: sourceButton.bottom
        anchors.topMargin: 16
        anchors.left: parent.left
        anchors.leftMargin: buttonSideMargin
        spacing: 16

        IconTextPushButton {
            id: browseIconTextPushButton
            objectName: "GeneralUsbScreen_browseButton"

            textLocation: ViewController.rightToLeftLanguageActive ? HmiGui.Left : HmiGui.Right
            textComponent.horizontalAlignment: Text.AlignLeft
            shape: HmiGui.Flatter
            size: HmiGui.Big
            iconSize: HmiGui.IconMedium
            variation: HmiGui.TileButtonVariation
            //~ TextID 9463136e-a883-11e3-97ec-c8d719f8cdfe
            text: qsTr("Browse")
            iconId: "media/icon_browse"
            onClicked: {
                if (passengerExpectionAvailable) {
                    ViewController.showDriverRestrictionPopup(ViewController.DriverRestrictionTypeKPopup,MediaController.TemplatedBrowseItem);
                } else {
                    container.browseButtonClicked()
                }
            }
            visible: MediaUtils.browseVisible()
        }

        IconTextPushButton {
            id: infoPushButton
            objectName: "GeneralUsbScreen_infoButton"

            textLocation: ViewController.rightToLeftLanguageActive ? HmiGui.Left : HmiGui.Right
            textComponent.horizontalAlignment: Text.AlignLeft
            shape: HmiGui.Flatter
            size: HmiGui.Big
            iconSize: HmiGui.IconMedium
            variation: HmiGui.TileButtonVariation
            iconId: !VideoPlayerPipe.isActive ? "shared/icon_info" : "trlink/icon_movie_title"
            visible: !AL2HMIBridge.mediaSource.endOfLastSongRepeatOff && AL2HMIBridge.mediaSource.mediaPlayerTrackType!== AL2HMIBridge.MediaSource.ItunesRadio

            //~ TextID 24f6a636-38ad-11e8-9cdc-08002718b8d7
            text: !VideoPlayerPipe.isActive ? qsTr("Info") : qsTr("Video")
            onClicked: {
                if (songInformationSupported)
                    _hmiMedia.mediaController.requestTransition(MediaController.ToShowSongInformationUsb)
            }
        }
    }

   Item {
        id: albumArt_Item
        anchors.top: sourceButton.bottom
        anchors.topMargin: 222
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.horizontalCenterOffset: -80
        Column {
            CoverAlbumButton {
                id: coverAlbumButton_GeneralUsbScreen
                coverArtSource: AL2HMIBridge.mediaSource.coverArtAvailable ? AL2HMIBridge.mediaSource.coverArt :""
                endOfPlayList:  AL2HMIBridge.mediaSource.endOfLastSongRepeatOff
                coverArtDriverRestiction: AL2HMIBridge.globalSource.driverRestrictionsAlbumArtActive
            }
        }
    }

    Item {
        id: playBackScreenIforContentItem
        anchors {
            top: sourceButton.bottom
            left: parent.left
            right: parent.right
            topMargin: 388
        }

        PlaybackScreenInfoContent {
            id: playbackscreeninfoContent

            anchors.leftMargin: UiTheme.styleRoot.generalMarginLarge
            anchors.rightMargin: UiTheme.styleRoot.generalMarginLarge

            artist: AL2HMIBridge.mediaSource.artist
            songTitle: AL2HMIBridge.mediaSource.title
            album: AL2HMIBridge.mediaSource.album
            currentTrack: AL2HMIBridge.mediaSource.mediaCurrentObject
            totalTracks: AL2HMIBridge.mediaSource.mediaTotalObjects
        }
    }

    Column {
        id: progressBarColumn

        anchors.bottom: trackControlButtons_GeneralUsbScreen.top
        anchors.bottomMargin: 29
        anchors.left: parent.left
        anchors.right: parent.right
        spacing: UiTheme.styleRoot.generalMarginBig
        height: 84

        Item {
            id: itemTimeLabel

            anchors{
                left: parent.left
                leftMargin: UiTheme.styleRoot.generalMarginLarge
                right: parent.right
                rightMargin: UiTheme.styleRoot.generalMarginLarge
            }

            height:  84

            LayoutMirroring.enabled: ViewController.rightToLeftLanguageActive
            LayoutMirroring.childrenInherit: true

            TextLabel {
                id: elapsedTimeLabel
                objectName: "PlaybackScreenInfoContent_elapsedTimeLabel"
                anchors.left: parent.left
                variation: HmiGui.BigLabelVariation
                text: MediaUtils.getElapsedTime(progressBar.dragging, progressBar.displayedValue, AL2HMIBridge.mediaSource.totalHours, AL2HMIBridge.mediaSource.totalMinutes,
                                                AL2HMIBridge.mediaSource.totalSeconds, AL2HMIBridge.mediaSource.elapsedHours, AL2HMIBridge.mediaSource.elapsedMinutes,
                                                AL2HMIBridge.mediaSource.elapsedSeconds)
                visible: (AL2HMIBridge.mediaSource.totalHours !== AL2HMIBridge.mediaSource.elapsedHours
                          || AL2HMIBridge.mediaSource.totalMinutes !== AL2HMIBridge.mediaSource.elapsedMinutes
                          || AL2HMIBridge.mediaSource.totalSeconds !== AL2HMIBridge.mediaSource.elapsedSeconds)
            }
            TextLabel {
                id: totalTimeLabel
                objectName: "PlaybackScreenInfoContent_totalTimeLabel"
                anchors.right: parent.right
                variation: HmiGui.BigLabelVariation
                text: FormattingUtils.formatTimer(AL2HMIBridge.mediaSource.totalHours,
                                                  AL2HMIBridge.mediaSource.totalMinutes,
                                                  AL2HMIBridge.mediaSource.totalSeconds)
                visible: (AL2HMIBridge.mediaSource.totalHours > 0
                          || AL2HMIBridge.mediaSource.totalMinutes > 0
                          || AL2HMIBridge.mediaSource.totalSeconds > 0)
                         && (AL2HMIBridge.mediaSource.elapsedHours >= 0
                             && AL2HMIBridge.mediaSource.elapsedMinutes >= 0
                             && AL2HMIBridge.mediaSource.elapsedSeconds >= 0)
                         && (AL2HMIBridge.mediaSource.elapsedHours < AL2HMIBridge.mediaSource.totalHours
                             || (AL2HMIBridge.mediaSource.elapsedHours == AL2HMIBridge.mediaSource.totalHours
                                 && AL2HMIBridge.mediaSource.elapsedMinutes < AL2HMIBridge.mediaSource.totalMinutes)
                             || (AL2HMIBridge.mediaSource.elapsedHours == AL2HMIBridge.mediaSource.totalHours
                                 && AL2HMIBridge.mediaSource.elapsedMinutes ==AL2HMIBridge.mediaSource.totalMinutes
                                 && AL2HMIBridge.mediaSource.elapsedSeconds <= AL2HMIBridge.mediaSource.totalSeconds))
            }

            ProgressBar {
                id: progressBar
                objectName: "PlaybackScreenInfoContent_progressBar"

                anchors.bottom:  parent.bottom
                anchors.left: itemTimeLabel.left
                anchors.right: itemTimeLabel.right
                value: AL2HMIBridge.mediaSource.scanningProgress
                maximumValue: AL2HMIBridge.mediaSource.maxScanningProgressValue
                minimumValue: 0
                draggingSupported: AL2HMIBridge.mediaSource.progressBarJumpSupported
                visible:  totalTimeLabel.visible
                onJumpTo: _hmiMedia.mediaController.requestMediaJump(pos)

            }
        }
    }

    TrackControlButtons {
        id: trackControlButtons_GeneralUsbScreen

        anchors.bottom: parent.bottom
        anchors.bottomMargin: 46
        anchors.horizontalCenter: parent.horizontalCenter

        height: 92

        playing:(AL2HMIBridge.mediaSource.audioStatus === AL2HMIBridge.MediaSource.Playing)

        show30Button: has30secondSupport
        showThumbsButtons: hasThumbsButtonSupport
        backButtonActive: isTrackBackButtonActive

        thumbsUpButtonStatus: AL2HMIBridge.mediaSource.thumbsUpButtonSelectedStatus
        thumbsDownButtonStatus: AL2HMIBridge.mediaSource.thumbsDownButtonSelectedStatus

        onPrevious30Clicked: _hmiMedia.mediaController.previous30SecPressed()

        onPreviousClicked: _hmiMedia.mediaController.mediaPrevious()
        onPreviousPressAndHold: _hmiMedia.mediaController.mediaPreviousLong(AL2HMIBridge.MediaSource.Pressed)
        onPreviousHoldAndReleased: _hmiMedia.mediaController.mediaPreviousLong(AL2HMIBridge.MediaSource.Released)

        onPlayPauseClicked: _hmiMedia.mediaController.mediaTogglePlayPause()

        onNextClicked: _hmiMedia.mediaController.mediaNext()
        onNextPressAndHold: _hmiMedia.mediaController.mediaNextLong(AL2HMIBridge.MediaSource.Pressed)
        onNextHoldAndReleased: _hmiMedia.mediaController.mediaNextLong(AL2HMIBridge.MediaSource.Released)

        onNext30Clicked: _hmiMedia.mediaController.next30SecPressed()

        onThumbsDownClicked: _hmiMedia.mediaController.toggleThumbsDownStatus()
        onThumbsUpClicked: _hmiMedia.mediaController.toggleThumbsUpStatus()
    }
}
