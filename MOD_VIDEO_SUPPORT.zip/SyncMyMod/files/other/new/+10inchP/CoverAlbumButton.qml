import QtQuick 2.0

import HmiGui 1.0

import Hmi.Ford.Controls 1.0

HmiImage {
    id: coverAlbum
    objectName: "CoverAlbumButton"


    property bool endOfPlayList:false
    property bool coverArtDriverRestiction:false
    property alias coverArtSource: coverAlbum.source

    signal clicked

    sourceSize: Qt.size(160, 160)
    fillMode: Image.PreserveAspectFit
    visible: coverArtDriverRestiction ? false : (!coverAlbum.endOfPlayList)

    HmiImage {
        id: infoIcon
        objectName: "CoverAlbumButton_infoIcon"

        visible: !_progressBarStyle.alignProgressBarToBottom && !coverAlbum.endOfPlayList && !VideoPlayerPipe.isActive

        source: UiTheme.palette.icon("shared/icon_info", "_active", HmiGui.IconSmall)

        anchors{
            right: parent.right
            rightMargin: UiTheme.styleRoot.generalMarginSmall + (coverAlbum.width - coverAlbum.paintedWidth) / 2
            bottom: parent.bottom
            bottomMargin: UiTheme.styleRoot.generalMarginSmall + (coverAlbum.height - coverAlbum.paintedHeight) / 2
        }
    }

    MouseArea {
        id: mouseArea_CoverAlbumButton
        objectName: "CoverAlbumButton_mouseArea_CoverAlbumButton"
        anchors.fill: parent
        enabled: !coverAlbum.endOfPlayList
        property bool beepOnClick: true
        onClicked: {
            coverAlbum.clicked()
            ViewController.buttonClicked(mouseArea_CoverAlbumButton)
        }
    }

}
