import QtQuick 2.0

import HmiGui 1.0

import HmiGuiFramework.Controls 1.0

import Hmi.Ford.Controls 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge

Column {
    id: root
    objectName: "PlaybackScreenInfoContent"

    property alias songTitle: songTitleLabel.text
    property alias artist: artistLabel.text
    property alias album: albumLabel.text

    property int currentTrack: 0
    property int totalTracks: 0

    anchors.left: parent.left
    anchors.right: parent.right
    anchors.bottomMargin: UiTheme.styleRoot.generalMarginSmall

    spacing: UiTheme.styleRoot.generalMarginSmall
    Item {
        id: albumInfo
        anchors.left: parent.left
        anchors.right: parent.right
        height: textInfo.height


        Column{
            id: textInfo
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.leftMargin: 0

            TextLabel {
                id: artistLabel
                objectName: "PlaybackScreenInfoContent_artistLabel"
                anchors.left: parent.left
                anchors.right: parent.right
                elide: Text.ElideRight

                horizontalAlignment: Text.AlignHCenter
                variation: HmiGui.BigLabelVariation
            }

            TextLabel {
                id: songTitleLabel
                objectName: "PlaybackScreenInfoContent_songTitleLabel"
                anchors.left: parent.left
                anchors.right: parent.right
                elide: Text.ElideRight
                horizontalAlignment: Text.AlignHCenter
                variation: HmiGui.BigLabelVariationMedium
                color: UiTheme.palette.fontColorSelected
            }

            TextLabel {
                id: albumLabel
                objectName: "PlaybackScreenInfoContent_albumLabel"

                anchors.left: parent.left
                anchors.right: parent.right

                visible: _progressBarStyle.alignAlbumLabel && ((AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.Usb)
                                                                        || (AL2HMIBridge.cdSource.album === text)
                                                                        || (AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.Bt))

                elide: Text.ElideRight
                horizontalAlignment: Text.AlignHCenter

                variation: HmiGui.DefaultLabelVariation
            }

            TextLabel {
                id: trackInformation
                objectName: "PlaybackScreenInfoContent_trackInformation"
                anchors.horizontalCenter: parent.horizontalCenter
//~ TextID 38488d12-e6f6-11e7-af74-08002718b8d7
                text: qsTr("%1/%2 ").arg(currentTrack).arg(totalTracks)

                variation: HmiGui.DefaultLabelVariation
                horizontalAlignment: Text.AlignHCenter
                visible: totalTracks > 0 && currentTrack >= 0
            }
        }
    }
}
