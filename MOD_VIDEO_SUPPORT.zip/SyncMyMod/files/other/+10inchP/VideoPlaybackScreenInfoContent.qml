import QtQuick 2.0

import HmiGui 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0

Column {
    id: root
    objectName: "VideoPlaybackScreenInfoContent"

    property alias songTitle: songTitleLabel.text

    property int currentTrack: 0
    property int totalTracks: 0

	anchors.left: parent.left
    anchors.right: parent.right
    anchors.bottomMargin: UiTheme.styleRoot.generalMarginSmall

    spacing: UiTheme.styleRoot.generalMarginSmall
    Item {
        id: albumInfo
        anchors.left: parent.left
        anchors.right: parent.right
        height: textInfo.height


        Column{
            id: textInfo
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.leftMargin: 0

            TextLabel {
                id: songTitleLabel
                objectName: "VideoPlaybackScreenInfoContent_songTitleLabel"
				anchors.horizontalCenter: parent.horizontalCenter
				anchors.left: parent.left
				anchors.right: parent.right
				anchors.margins: 100
				anchors.bottom: trackInformation.bottom
				anchors.bottomMargin: 680
				
                elide: Text.ElideRight
                horizontalAlignment: Text.AlignHCenter
                variation: HmiGui.BigLabelVariationMedium
                color: UiTheme.palette.fontColorSelected
            }

            TextLabel {
                id: trackInformation
                objectName: "VideoPlaybackScreenInfoContent_trackInformation"
                anchors.horizontalCenter: parent.horizontalCenter
                text: qsTr("%1/%2 ").arg(currentTrack).arg(totalTracks)

                variation: HmiGui.DefaultLabelVariation
                horizontalAlignment: Text.AlignHCenter
                visible: totalTracks > 0 && currentTrack >= 0
            }
        }
    }
}
