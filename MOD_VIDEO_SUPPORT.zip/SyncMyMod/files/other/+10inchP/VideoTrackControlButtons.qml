import QtQuick 2.0

import HmiGui 1.0
import HmiGuiFramework 1.0
import HmiGuiFramework.Controls 1.0

import Hmi.Ford 1.0
import Hmi.Ford.Controls 1.0

Row {
    id: root
    objectName: "VideoTrackControlButtons"

    property bool playing: false

    property QtObject _style: UiTheme.styleSelect("trackControlButton", root)
    property int buttonRowSpacing : root._style.buttonRowSpacing

    property alias backButtonActive: backButton.active
    property alias previousButtonVisible: backButton.visible
    property alias playPauseButtonVisible: playPauseButton.visible
    property alias nextButtonVisible: nextButton.visible

    property alias backButton: backButton
    property alias nextButton: nextButton
    property alias playPauseButton: playPauseButton

    signal previousClicked
    signal previousPressAndHold
    signal previousHoldAndReleased

    signal playPauseClicked

    signal nextClicked
    signal nextPressAndHold
    signal nextHoldAndReleased


    spacing: buttonRowSpacing// Make stylable

    function getBackgroundSource(size, state, position) {
        var suffix = "";

        switch(state) {
        case HmiGui.Pressed:
            suffix = "_activepressed";
            break;
        case HmiGui.Selected:
            suffix = "_selected";
            break;
        case HmiGui.PressedSelected:
            suffix = "_selectedpressed";
            break;
        case HmiGui.Active:
        default:
            suffix = "_active";
        }
        return UiTheme.palette.image(size + "_button_tile" + suffix + position);
    }

    IconPushButton {
        id: backButton
        objectName: "VideoTrackControlButtons_backButton"
        anchors.verticalCenter: playPauseButton.verticalCenter

        property bool hold: false

        shape: HmiGui.Flat
        size: HmiGui.Small
        variation: HmiGui.TileButtonVariation

        iconId: "media/icon_rewind"

        active: backButtonActive

        onPressAndHold: {
            hold = true;
            previousPressAndHold()
        }
        clickAfterPressAndHold: false

        onPressed: hold = false

        onExited: {
            if (hold) {
                previousHoldAndReleased()
            }
            hold = false
        }

        onReleased: {
            if (hold) {
                previousHoldAndReleased();
            }
            hold = false;
        }

        onClicked: previousClicked();

        backgroundSource: getBackgroundSource(definedSize.width+"x"+definedSize.height, buttonState, "_left")
    }

    IconPushButton {
        id: playPauseButton
        objectName: "VideoTrackControlButtons_playPauseButton"
        anchors.verticalCenter: parent.verticalCenter

        shape: HmiGui.Flat
        size: HmiGui.Small
        variation: HmiGui.TileButtonVariation

        iconId: root.playing ? "media/icon_pause" : "media/icon_play"

        onClicked: playPauseClicked()

        backgroundSource: getBackgroundSource(definedSize.width+"x"+definedSize.height, buttonState, "_middle")
    }

    IconPushButton {
        id: nextButton
        objectName: "VideoTrackControlButtons_nextButton"
        anchors.verticalCenter: playPauseButton.verticalCenter

        property bool hold: false

        shape: HmiGui.Flat
        size: HmiGui.Small
        variation: HmiGui.TileButtonVariation

        iconId: "media/icon_fastforward"

        onPressAndHold: {
            hold = true;
            nextPressAndHold()
        }
        clickAfterPressAndHold: false

        onPressed: hold = false

        onExited: {
            if (hold) {
                nextHoldAndReleased()
            }
            hold = false
        }

        onReleased: {
            if (hold) {
                nextHoldAndReleased()
            }
            hold = false
        }

        onClicked: nextClicked()

        backgroundSource:  getBackgroundSource(definedSize.width+"x"+definedSize.height, buttonState, "_right")
    }
}
