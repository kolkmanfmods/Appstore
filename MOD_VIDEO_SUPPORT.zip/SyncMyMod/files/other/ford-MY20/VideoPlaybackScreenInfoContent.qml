import QtQuick 2.0

import HmiGui 1.0

import HmiGuiFramework.Controls 1.0

import Hmi.Ford.Controls 1.0

Item {
    id: root
    objectName: "VideoPlaybackScreenInfoContent"

    property string elapsedTime
    property string totalTime
    property alias totalTimeVisible: totalTimeLabel.visible
    property alias elapsedTimeVisible: elapsedTimeLabel.visible
    property alias progress: progressBar.value
    property alias maximumValue: progressBar.maximumValue

    property int currentTrack: 0
    property int totalTracks: 0
    property alias trackInfoPos: trackInformation.horizontalAlignment

    property alias draggingSupported: progressBar.draggingSupported
    property alias dragging: progressBar.dragging
    property alias draggingValue: progressBar.draggingValue
    signal jumpTo(real pos)

    property int trackInformationVariation: HmiGui.BigLabelVariationLight

    anchors.fill: parent

    Item {
        id: trackTime
        objectName: "VideoPlaybackScreenInfoContent_trackTime"

        anchors{
            top: albumInfo.bottom
            left: parent.left
            right: parent.right
        }

        height: childrenRect.height

        LayoutMirroring.enabled: ViewController.rightToLeftLanguageActive
        LayoutMirroring.childrenInherit: true

        TextLabel {
            id: elapsedTimeLabel
            objectName: "VideoPlaybackScreenInfoContent_elapsedTimeLabel"

            anchors{
                top: progressBar.verticalCenter
                topMargin: UiTheme.styleRoot.generalMarginSmall
                left: parent.left
            }
			
			color: "#e0e0e0"
			style: Text.Outline
			styleColor: "black"

            text: elapsedTime

            height: implicitHeight

            variation: HmiGui.SemiBigLabelMediaVariation
        }
        TextLabel {
            id: trackInformation
            objectName: "VideoPlaybackScreenInfoContent_trackInformation"

            anchors {
                bottom: elapsedTimeLabel.bottom
                horizontalCenter: parent.horizontalCenter
            }

            height: implicitHeight
			
			color: "#e0e0e0"
			style: Text.Outline
			styleColor: "black"

            //~ TextID 38488d12-e6f6-11e7-af74-08002718b8d7
            text: qsTr("%1/%2 ").arg(currentTrack).arg(totalTracks)
            variation: trackInformationVariation
            horizontalAlignment: Text.AlignHCenter
            visible: totalTracks > 0 && currentTrack >= 0
        }

        ProgressBar {
            id: progressBar
            objectName: "PlaybackScreenInfoContent_progressBar"

            anchors{
                top: parent.top
                left: parent.left
                right: parent.right
            }

            maximumValue: 100
            minimumValue: 0
            visible: totalTimeLabel.visible

            onJumpTo: root.jumpTo(pos)
        }

        TextLabel {
            id: totalTimeLabel
            objectName: "VideoPlaybackScreenInfoContent_totalTimeLabel"

            anchors{
                bottom: elapsedTimeLabel.bottom
                right: parent.right
            }

            height: implicitHeight
			
			color: "#e0e0e0"
			style: Text.Outline
			styleColor: "black"

            text: totalTime

            variation: HmiGui.SemiBigLabelMediaVariation
        }
    }


}
