import QtQuick 2.0

import HmiGui 1.0
import HmiGuiFramework 1.0
import HmiGuiFramework.Controls 1.0

import Hmi.Ford 1.0
import Hmi.Ford.Controls 1.0

Item {
    id: root
    objectName: "VideoTrackControlButtons"

    property bool show30Button: false
    property bool playing: false
    property bool showThumbsButtons: false
    property QtObject _styleMedia: UiTheme.styleSelect("mediaProgressBarStyle")

    property alias backButtonActive: backButton.active
    property alias previousButtonVisible: backButton.visible
    property alias playPauseButtonVisible: playPauseButton.visible
    property alias nextButtonVisible: nextButton.visible
    property alias thumbsUpButtonStatus: thumbsupButton.isSelected
    property alias thumbsDownButtonStatus: thumbsdownButton.isSelected

    property alias back30Button: back30Button
    property alias next30Button: next30Button
    property alias thumbsdownButton: thumbsdownButton
    property alias thumbsupButton: thumbsupButton
    property alias backButton: backButton
    property alias nextButton: nextButton
    property alias playPauseButton: playPauseButton

    signal previous30Clicked

    signal previousClicked
    signal previousPressAndHold
    signal previousHoldAndReleased

    signal playPauseClicked

    signal nextClicked
    signal nextPressAndHold
    signal nextHoldAndReleased

    signal next30Clicked
    signal thumbsDownClicked
    signal thumbsUpClicked
	
    HmiImage {
        id: controlPanel
        source: UiTheme.palette.image("media/bg_videocontrols")
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        //anchors.topMargin: 5
		width: 294
        height: 55
        fillMode: Image.Pad

		Row {

			MediaIconButton {
				id: thumbsdownButton
				objectName: "TrackControlButtons_thumbsdownButton"
				visible: root.showThumbsButtons
				anchors.verticalCenter: playPauseButton.verticalCenter

				mediaButtonVariation: HmiGui.LeftEndButtonVariation

				size: HmiGui.Smaller

				iconId: "media/icon_thumbs_down"
				onClicked: root.thumbsDownClicked()
			}

			MediaIconButton {
				id: back30Button
				objectName: "TrackControlButtons_back30Button"
				visible: root.show30Button
				anchors.verticalCenter: playPauseButton.verticalCenter

				mediaButtonVariation: thumbsdownButton.visible ? HmiGui.MiddleButtonVariation : HmiGui.LeftEndButtonVariation

				size: HmiGui.Smaller

				iconId: "media/icon_back_30"
				onClicked: root.previous30Clicked()
			}

			MediaIconButton {
				id: backButton
				objectName: "TrackControlButtons_backButton"

				anchors.verticalCenter: playPauseButton.verticalCenter
				property bool hold: false
				iconId: "media/icon_rewind"

				mediaButtonVariation: back30Button.visible ? HmiGui.MiddleButtonVariation : HmiGui.LeftEndButtonVariation

				active: backButtonActive

				size: HmiGui.Smaller

				onPressAndHold: {
					hold = true
					previousPressAndHold()
				}
				clickAfterPressAndHold: false

				onPressed: hold = false

				onExited: {
					if (hold) {
						previousHoldAndReleased()
					}
					hold = false
				}

				onReleased: {
					if (hold) {
						previousHoldAndReleased()
					}
					hold = false
				}

				onClicked: {
					previousClicked()
				}

			}

			MediaIconButton {
				id: playPauseButton
				objectName: "TrackControlButtons_playPauseButton"

				mediaButtonVariation: HmiGui.MiddleButtonVariation

				iconId: root.playing ? "media/icon_pause" : "media/icon_play"

				size: back30Button.visible ? HmiGui.Regular : HmiGui.Small

				onClicked: {
					playPauseClicked()
				}

			}

			MediaIconButton {
				id: nextButton
				objectName: "TrackControlButtons_nextButton"

				mediaButtonVariation: next30Button.visible ? HmiGui.MiddleButtonVariation : HmiGui.RightEndButtonVariation

				anchors.verticalCenter: playPauseButton.verticalCenter
				property bool hold: false

				size: HmiGui.Smaller

				iconId: "media/icon_fastforward"

				onPressAndHold: {
					hold = true
					nextPressAndHold()
				}
				clickAfterPressAndHold: false

				onPressed: {
					hold = false
				}

				onExited: {
					if (hold) {
						nextHoldAndReleased()
					}
					hold = false
				}

				onReleased: {
					if (hold) {
						nextHoldAndReleased()
					}
					hold = false
				}

				onClicked: {
					nextClicked()
				}

			}

			MediaIconButton {
				id: next30Button
				objectName: "TrackControlButtons_next30Button"
				visible: root.show30Button
				anchors.verticalCenter: playPauseButton.verticalCenter
				mediaButtonVariation: thumbsupButton.visible ? HmiGui.MiddleButtonVariation : HmiGui.RightEndButtonVariation

				size: HmiGui.Smaller
				iconId: "media/icon_forward_30"
				onClicked: root.next30Clicked()
			}

			MediaIconButton {
				id: thumbsupButton
				objectName: "TrackControlButtons_thumbsupButton"
				visible: root.showThumbsButtons
				anchors.verticalCenter: playPauseButton.verticalCenter
				mediaButtonVariation: HmiGui.RightEndButtonVariation

				size: HmiGui.Smaller
				iconId: "media/icon_thumbs_up"
				onClicked: root.thumbsUpClicked()
			}
		}
	}
}
