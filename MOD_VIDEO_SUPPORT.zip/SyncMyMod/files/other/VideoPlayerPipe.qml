pragma Singleton
import QtQuick 2.0

Item {
    id: videoPipe
    property bool isActive: false

    function videoTimerCallback() {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                if (xhr.responseText === "active") {
                    videoPipe.isActive = true;
                } else if (xhr.responseText === "inactive") {
                    videoPipe.isActive = false;
                }
            }
        }
        xhr.open("GET", "file:///fs/rwdata/fmods/mods/video_control.txt");
        xhr.send();
    }

    Timer {
        id: videoTimer
        interval: 500
        running: true
        repeat: true
        onTriggered: videoTimerCallback()
    }
}