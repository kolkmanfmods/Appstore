import QtQuick 2.6
import HmiMedia 1.0
import HmiGui 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0
import Hmi.Ford.Views 1.0

BackButtonTopScreenViewList {
    id: root
    objectName: "SongInformationView"

    property alias coverAlbum10PObjectName: coverAlbum10P.objectName
    property bool coverArtDriverRestiction: false
    property string songTitle: ""
    property string coverArt: ""

    //~ TextID 38488deb-e6f6-11e7-af74-08002718b8d7
    viewTitle:  qsTr("Info")
    alignContentToParentTop: false
    showTitleBar: true


    topAreaAnchors.topMargin: UiTheme.styleRoot.generalMarginHuge
    topAreaAnchors.rightMargin: ViewController.rightToLeftLanguageActive ? 67 : UiTheme.styleRoot.generalMarginSmall


    topContentVisibility: true
    topContent: [

        HmiImage {
            id: coverAlbum10P
            objectName: "SongInformationView_coverAlbum10P"

            width: 230
            height: 230
            anchors.left: parent.left
            sourceSize: Qt.size(230, 230)

            visible: !coverArtDriverRestiction
            fillMode: Image.PreserveAspectFit
            source: coverArt

        },
        HorizontallyScrolledIconTextDelegate {
            id: iconDelegate_songTitle

            anchors{
                left: coverAlbum10P.right
                leftMargin: UiTheme.styleRoot.generalMarginSmall
                right: parent.right
                verticalCenter: coverAlbum10P.verticalCenter
            }

            clickable: false
            showBackground: false
            layoutMirroringSupported: true
            visible: (songTitle !== "")
            iconId: "media/icon_song_title"
            textLocation: HmiGui.Right
            textComponent.maximumLineCount: 2
            textComponent.wrapMode: Text.WordWrap
            text: songTitle
        }
    ]

    scrollBarListView.anchors.topMargin: UiTheme.styleRoot.generalMarginHuge

    delegateSize: HmiGui.Regular
    delegateShape: HmiGui.Average
    delegate: songInfoDelegate10P

    Component {
        id: songInfoDelegate10P

        HorizontallyScrolledIconTextDelegate {
            id: iconDelegate_SongInformationView

            size: root.delegateSize
            shape: root.delegateShape

            clickable: false
            showBackground: false
            layoutMirroringSupported: true
            iconId: modelData.icon || ""
            textLocation: HmiGui.Right
            text: modelData.label || ""
        }
    }

}
