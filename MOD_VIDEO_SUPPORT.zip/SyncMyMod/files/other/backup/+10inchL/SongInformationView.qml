import QtQuick 2.6
import HmiMedia 1.0
import HmiGui 1.0

import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0
import Hmi.Ford.Views 1.0

BackButtonTopScreenViewList {
    id: root
    property string squishID
    property alias titleLabel_prvText_squishID: titleLabel.prvText_squishID
    property alias titleLabel_nextText_squishID: titleLabel.nextText_squishID

    property alias songTitle: titleLabel.text
    property alias coverArt: coverAlbum.source

    property alias coverAlbumObjectName: coverAlbum.objectName
    property bool coverArtDriverRestiction: false

    property string songInfoBtn_prvText_squishID
    property string songInfoBtn_nextText_squishID

    property int delegateScrollbarOffset: 1

    onBack: _hmiMedia.mediaController.back()

    verticalAligmentOfFilterButton: "TOP"
    horizontalAligmentOfFilterButton: "RIGHT"

    customTitle: HorizontallyScrolledTextLabel {
        id: titleLabel

        anchors {
            fill: parent
            rightMargin: UiTheme.styleRoot.generalMarginSmall
            leftMargin: UiTheme.styleRoot.generalMarginSmall
            verticalCenter: parent.verticalCenter
        }
        isButtonText: false
        variation: HmiGui.ExtraLargeLabelVariation
    }


    leftButtons: HmiImage {
        id: coverAlbum

        sourceSize: Qt.size(330, 330)
        fillMode: Image.PreserveAspectFit
        anchors.top: parent.top
        anchors.topMargin: UiTheme.styleRoot.gridSizes.rowHeightWithMargin
        visible: !coverArtDriverRestiction

    }

    delegateShape: HmiGui.Average
    delegateSize: HmiGui.Regular

    delegate: ListItemBase {
        id: iconDelegate_SongInformationView
        property string squishID: root.squishID
        property string squishIndex: index
        size: root.delegateSize
        shape: root.delegateShape

        anchors.right: parent.right
        LayoutMirroring.enabled: ViewController.rightToLeftLanguageActive
        LayoutMirroring.childrenInherit: true

        Row {
            id: infoRow
            anchors.fill: parent
            spacing: 15
            Item {
                width: 100
                height: parent.height
                anchors.verticalCenter: parent.verticalCenter                
                ButtonStateIcon {
                    anchors.centerIn: parent
                    fillMode: Image.PreserveAspectFit
                    iconId: modelData.icon
                }
            }
            HorizontallyScrolledTextLabel {
                id: songInfoBtn
                prvText_squishID: root.songInfoBtn_prvText_squishID
                prvText_squishIndex: index
                nextText_squishID: root.songInfoBtn_nextText_squishID
                nextText_squishIndex: index

                anchors.verticalCenter: parent.verticalCenter
                width: 560 - delegateScrollbarOffset
                text: modelData.label
                variation: HmiGui.LargeLabelVariation
            }
        }
        HmiImage {
            source: UiTheme.palette.getImageForDomain("divider_lg", root.domain)
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: infoRow.top
            anchors.bottomMargin: Math.floor(UiTheme.styleRoot.gridSizes.verticalSpacing / 2)
        }
    }
}
