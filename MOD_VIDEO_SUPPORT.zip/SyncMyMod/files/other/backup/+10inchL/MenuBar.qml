import QtQuick 2.0
import HmiGui 1.0
import HmiOverrides 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0
import HmiCore.Instrumentation 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge

TransformableItem {
    id: root
    objectName: "MenuBar"
    property string squishID
    property QtObject _style: UiTheme.styleSelect("menuBar", root);

    z: parent ? parent.menuBarLayer
              : 0

    signal moduleRequest(int domain, string moduleRootView)

    property bool showBackgroundImage: true
    readonly property int iconDimensions: 60

    HmiImage {
        id: bgImage
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.right: parent.right

        source: root.showBackgroundImage ? UiTheme.palette.image(root._style.backgroundSource(listView.count)) : ""
        Repeater {
            objectName: "menuBar_Repeater"
            model: listView.count - 1

            HmiImage {
                x: (index + 1) * delegateWidth(index, listView.count);
                anchors.verticalCenter: bgImage.verticalCenter
                source: UiTheme.palette.image("domainbar_divider");
                width: 2
            }
        }
    }

    function moduleText(domain) {
        var textOverrides = HmiOverrides.nameOverrides;
        if (textOverrides.indexOf(domain) !== -1)
            return  HmiOverrides.nameOverride(domain);
        switch (domain) {
        case HmiGui.HomeDomain:
            //~ GroupID fordhmi/moduletext-0001
//~ TextID 38488c9e-e6f6-11e7-af74-08002718b8d7
            return qsTr("Home")
        case HmiGui.PhoneDomain:
            //~ GroupID fordhmi/moduletext-0001
//~ TextID 38488c9f-e6f6-11e7-af74-08002718b8d7
            return qsTr("Phone")
        case HmiGui.MediaDomain:
            //~ GroupID fordhmi/moduletext-0001
//~ TextID 38488ca0-e6f6-11e7-af74-08002718b8d7
            return qsTr("Audio")
        case HmiGui.AppsDomain:
            //~ GroupID fordhmi/moduletext-0001
//~ TextID 38488ca1-e6f6-11e7-af74-08002718b8d7
            return qsTr("Apps")
        case HmiGui.NavigationDomain:
            //~ GroupID fordhmi/moduletext-0001
//~ TextID 38488ca2-e6f6-11e7-af74-08002718b8d7
            return qsTr("Nav")
        case HmiGui.SettingsDomain:
            //~ GroupID fordhmi/moduletext-0001
//~ TextID 38488ca3-e6f6-11e7-af74-08002718b8d7
            return qsTr("Settings")
        case HmiGui.ClimateDomain:
            //~ GroupID fordhmi/moduletext-0001
//~ TextID 38488ca4-e6f6-11e7-af74-08002718b8d7
            return qsTr("Climate")
        case HmiGui.AppsGALProjectionDomain:
            //~ GroupID fordhmi/moduletext-0001
//~ TextID 38488ca6-e6f6-11e7-af74-08002718b8d7
            return qsTr("Android Auto")
        case HmiGui.AppsDIOProjectionDomain:
            //~ GroupID fordhmi/moduletext-0001
//~ TextID 38488ca8-e6f6-11e7-af74-08002718b8d7
            return qsTr("Apple CarPlay")
        case HmiGui.NavigationProjectionDomain:
            //~ GroupID fordhmi/moduletext-0001
//~ TextID 38488ca9-e6f6-11e7-af74-08002718b8d7
            return qsTr("Maps")
        default:
            //~ GroupID fordhmi/moduletext-0001
//~ TextID f6272cdc-269e-11e8-823a-08002718b8d7
            return qsTr("Unknown")
        }
    }

    function moduleBackground(domain) {
        switch (domain) {
        case HmiGui.HomeDomain:
            return "_home"
        case HmiGui.PhoneDomain:
            return "_phone"
        case HmiGui.MediaDomain:
            return "_media"
        case HmiGui.AppsDIOProjectionDomain:
        case HmiGui.AppsGALProjectionDomain:
        case HmiGui.AppsDomain:
            return "_apps"
        case HmiGui.NavigationProjectionDomain:
        case HmiGui.NavigationDomain:
            return "_nav"
        case HmiGui.SettingsDomain:
            return "_settings"
        case HmiGui.ClimateDomain:
            return "_climate"
        default:
            return "Unknown"
        }
    }

    function delegateWidth(index, count) {
        return AppSettings.screenWidth / count;
    }

    function delegateBackground(index, count, name) {
        var url = "";

        if (name !== "")
            url = name;

        return url;
    }

    function delegateIcon(domain, iconUrl, postfix) {
        var iconOverrides = HmiOverrides.iconOverrides;
        if (iconOverrides.indexOf(domain) !== -1)
            return HmiOverrides.iconOverride(domain, postfix);
        return UiTheme.palette.icon(iconUrl, postfix);
    }

    function checkMediaEnabled(moduleDomain) {
        if(moduleDomain === HmiGui.MediaDomain) {
            return !AL2HMIBridge.phoneSource.callConnected || (AL2HMIBridge.phoneSource.callConnected && AL2HMIBridge.phoneSource.privateMode && !AL2HMIBridge.phoneSource.muteAudioInPrivacy);
        }
        return true;
    }

    Component {
        id: navBarButtonDelegate

        Item {
            id: itemRoot
            objectName: "menuBar_"+ moduleText(moduleDomain) +"_button"
            readonly property string instrumentationEventName: moduleText(moduleDomain)
            property bool active: moduleDomain === ViewManager.activeDomain
            property int listViewCount: listView.count

            enabled: ViewController.activeMenuDomains.indexOf(moduleDomain) !== -1 && !moduleBlocked && root.checkMediaEnabled(moduleDomain)
            opacity: enabled ? 1.0 : 0.5

            width: root.delegateWidth(index, listViewCount)
            height: 136
            anchors.bottom: parent.bottom

            HmiImage {
                // We reuse the active icon for the "pressed" state
                id: moduleIcon
                property string iconPostFix: itemMouseArea.pressed || (!root._style.hasOverlay && itemRoot.active) ? "_active"
                                                                                                                   : "_active"
                visible: true
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: moduleNameText.top
                anchors.bottomMargin: 8 //root._style.delegateStyle.iconBottomMargin

                height: root.iconDimensions
                width: root.iconDimensions
                fillMode: Image.PreserveAspectFit
                smooth: true

                // source: root.delegateIcon(moduleDomain, iconUrl, iconPostFix) // TODO: Uncomment this one when Qt > 5.2.1
                source: iconPostFix ? root.delegateIcon(moduleDomain, iconUrl, iconPostFix) : "" // Workaround Qt 5.2.1 bug, which calls UiTheme.palette.icon() before evaluating iconPostFix
            }

            TextLabel {
                id: moduleNameText

                anchors {
                    verticalCenter: parent.verticalCenter
                    verticalCenterOffset: moduleIcon.height/2 + moduleNameText.font.pixelSize/2 - 11
                    left: parent.left
                    right: parent.right
                }

                elide: Text.ElideRight
                text: root.moduleText(moduleDomain)
                horizontalAlignment: Text.AlignHCenter
                color: itemMouseArea.pressed || (!root._style.hasOverlay && itemRoot.active) ? root._style.delegateStyle.activatedTextColor
                                                                                             : root._style.delegateStyle.textColor
                variation: HmiGui.BigLabelVariation

                layer.enabled: true
                layer.effect: ColorizeShaderEffect {
                    mainSource: moduleNameText
                    selected: itemRoot.active
                }
            }

            MouseArea {
                id: itemMouseArea
                property string squishID: root.squishID
                property string squishIndex: index
                anchors.fill: parent
                onClicked: {
                    root.moduleRequest(moduleDomain, moduleRootView)
                    ViewController.buttonClicked(itemMouseArea)
                    _iconAnimation.start()
                    Instrumentation.onButtonClicked(itemRoot)
                }
                property bool beepOnClick: true
            }

            SequentialAnimation{
                id: _iconAnimation

                NumberAnimation {
                    target: colorizeItemIcon;
                    property: "scale";
                    from: 1;
                    to: .5;
                    duration: 150;
                    easing.type: Easing.Linear
                }
                NumberAnimation {
                    target: colorizeItemIcon;
                    property: "scale";
                    from: .5; to: 1;
                    duration: 150;
                    easing.type: Easing.Linear
                }
            }

            ColorizeShaderEffect {
                id: colorizeItemIcon
                anchors.fill: moduleIcon
                mainSource: moduleIcon
                selected: itemRoot.active
                visible: HmiOverrides.iconOverrides.indexOf(moduleDomain) === -1
            }
        }
    }

    ListView {
        id: listView

        property int normalHighlighMoveDuration: root._style.highlightMoveDuration
        property bool ready: false

        anchors.bottom: parent.bottom
        anchors.top: parent.top
        width: parent.width

        interactive: false

        model: _modulesModel
        delegate: navBarButtonDelegate

        orientation: ListView.Horizontal
    }

    Item {
        id: os
        anchors.bottom: parent.bottom
        anchors.left: listView.left
        anchors.right: listView.right
        height: root._style.overlaySource !== "" ? 83 : 0

        visible: false

        Row {
            anchors.top: parent.top
            anchors.bottom: parent.bottom


            Repeater {
                model: listView.model
                height: 136
                delegate: HmiImage {
                    anchors.bottom: parent ? parent.bottom : undefined

                    source: root._style.overlaySource !== "" ? UiTheme.palette.image(root.delegateBackground(
                                                                                 index, listView.count,
                                                                                 root._style.overlaySource)
                                                                             + root.moduleBackground(moduleDomain))
                                                             : ""

                    HmiImage {
                        id: moduleIcon
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.bottom: moduleNameText.top
                        anchors.bottomMargin: root._style.delegateStyle.iconBottomMargin
                        source: root.delegateIcon(moduleDomain, iconUrl, "_active")
                        width: 60
                        height: 60
                        fillMode: Image.PreserveAspectFit
                    }

                    TextLabel {
                        id: moduleNameText
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.bottom: parent.bottom
                        anchors.bottomMargin: root._style.delegateStyle.bottomMargin
                        elide: Text.ElideRight
                        text: root.moduleText(moduleDomain)
                        horizontalAlignment: Text.AlignHCenter
                        color: root._style.delegateStyle.activatedTextColor
                        variation: HmiGui.LargeLabelVariation
                    }
                }
            }
        }
    }

    property QtObject masterLayout: UiTheme.styleSelect("masterLayout", root)
    property double menuBarOnScreenX: masterLayout.menuBarX
    property double menuBarOnScreenY: masterLayout.menuBarY
    property double menuBarOnScreenWidth: masterLayout.menuBarWidth
    property double menuBarOnScreenHeight: masterLayout.menuBarHeight

    x: menuBarOnScreenX + (!ViewManager.rootReloaded ? menuBarOnScreenWidth : 0)
    y: menuBarOnScreenY + (!ViewManager.rootReloaded ? menuBarOnScreenHeight : 0)
    width: menuBarOnScreenWidth
    height: menuBarOnScreenHeight

    Component.onCompleted: {
        listView.currentIndex = -1;
    }

    function hide() {
        showAnimation.stop()
        hideAnimation.start()
    }

    function hideWithoutAnimation() {
        showAnimation.stop()
        hideAnimation.stop()
        y = menuBarOnScreenY + masterLayout.menuBarHeight
    }

    function show() {
        hideAnimation.stop()
        showAnimation.start()
    }

    function showWithoutAnimation() {
        showAnimation.stop()
        hideAnimation.stop()
        y = menuBarOnScreenY
    }

    PropertyAnimation {
        id: hideAnimation
        duration: root._style.showHideAnimationDuration
        target: root
        property: 'y'
        to: root.menuBarOnScreenY + root.masterLayout.menuBarHeight
    }

    PropertyAnimation {
        id: showAnimation
        duration: root._style.showHideAnimationDuration
        target: root
        property: 'y'
        to: root.menuBarOnScreenY
    }
}
