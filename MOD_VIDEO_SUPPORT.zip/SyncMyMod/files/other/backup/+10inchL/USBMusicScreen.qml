import QtQuick 2.0

import HmiMedia 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge

GeneralUSBScreen {
    id: container

    has30secondSupport: false

    StateGroup {
        id: storageStates

        states: [
            State{
                name: "UsbStorage"
                when: AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.Usb || AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.CertifiedForVista

                PropertyChanges{
                    target: container
                    sourceButtonIconId: "media/icon_usb"
                }
            },
            State{
                name: "BTStorage"
                when: AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.Bt

                PropertyChanges{
                    target: container
                    sourceButtonIconId: "shared/icon_bluetooth"
                }
            },
            State{
                name: "IpodStorage"
                when: AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.IPod

                PropertyChanges{
                    target: container
                    sourceButtonIconId: "media/icon_usb"
                }
            },
            State{
                name: "SDStorage"
                when: AL2HMIBridge.mediaSource.storageType === AL2HMIBridge.MediaSource.SD

                PropertyChanges{
                    target: container
                    sourceButtonIconId: "media/icon_sd_card"
                }
            }
        ]
    }

    onBrowseButtonClicked: _hmiMedia.mediaController.requestTransition(MediaController.ToShowBrowseUsb)
}
