import QtQuick 2.6
import QtQuick.Layouts 1.2

import HmiMedia 1.0

import HmiGui 1.0
import Hmi.Ford.Controls 1.0
import HmiCore 1.0
import Hmi.Ford 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge

import "../components"

SongInformationView {
    id: root
    objectName: "SongInformationPage"

    property QtObject _styleStatusBar: UiTheme.styleSelect("statusBar", root)

    coverAlbumObjectName: "SongInformationPage_coverAlbum"
    songTitle: AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.AudioBook ? AL2HMIBridge.mediaSource.chapter :                                         //AL2HMIBridge.mediaSource.artist = Episode for Podcast
                                                                                  AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.PodCast ? AL2HMIBridge.mediaSource.artist : AL2HMIBridge.mediaSource.title
    coverArt: (AL2HMIBridge.mediaSource.coverArtAvailable && AL2HMIBridge.mediaSource.coverArt !== "") ? AL2HMIBridge.mediaSource.coverArt
                                                                               : UiTheme.palette.image("media/PlaceholderCoverArt-Media")

    coverArtDriverRestiction: AL2HMIBridge.globalSource.driverRestrictionsAlbumArtActive

    customTitle: RowLayout {
        anchors {
            fill: parent
            leftMargin: UiTheme.styleRoot.generalMarginSmall
        }

        LayoutMirroring.enabled: false
        spacing: 0

        HorizontallyScrolledTextLabel {
            id: titleLabel
            objectName: "SongInformationView_titleLabel"

            isButtonText: false
            text: songTitle

            Layout.fillHeight: true
            Layout.fillWidth: true
            Layout.rightMargin: UiTheme.styleRoot.generalMarginSmall
        }

        HmiImage {
            id: separator

            anchors.verticalCenter: hearIt_IconTextPushButton_SongInformationPage.verticalCenter
            source: UiTheme.palette.image(root._styleStatusBar.seperatorImage)
        }

        IconTextPushButton {
            id: hearIt_IconTextPushButton_SongInformationPage
            objectName: "SongInformationPage_hearIt_IconTextPushButton_SongInformationPage"

            shape: HmiGui.Flatter
            size:  HmiGui.Regular
            iconId: "shared/icon_hearit"
            active: !AL2HMIBridge.phoneSource.incomingCallActive && !AL2HMIBridge.phoneSource.callConnected
            //~ TextID 38488dea-e6f6-11e7-af74-08002718b8d7
            text: qsTr("Hear It")
            textLocation: ViewController.rightToLeftLanguageActive ? HmiGui.Left : HmiGui.Right
            backgroundSource: UiTheme.palette.getImageForDomain(_styleStatusBar.statusBarButtonPressedImage,
                                                                hearIt_IconTextPushButton_SongInformationPage.domain)
            showBackground: hearIt_IconTextPushButton_SongInformationPage.buttonState === HmiGui.Pressed

            onClicked: _hmiMedia.mediaController.hearMediaTrackType()
        }
    }

    model: (AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.Music ? musicModel() :
                                                                           AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.ItunesRadio ? itunesMusicModel() :
                                                                                                                                                AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.AudioBook ? audioBookModel() :
                                                                                                                                                                                                                   AL2HMIBridge.mediaSource.mediaPlayerTrackType === AL2HMIBridge.MediaSource.PodCast ? podCastModel() : []).filter(labelNonEmpty)


    function labelNonEmpty(row) {
        return row.label !== ""
    }

    function musicModel() {
        return [{ "label": AL2HMIBridge.mediaSource.artist, "icon": "media/icon_artistlist" },
                { "label": AL2HMIBridge.mediaSource.album, "icon": "media/icon_album" },
                { "label": AL2HMIBridge.mediaSource.composer, "icon": "media/icon_author" },
                { "label": AL2HMIBridge.mediaSource.genre, "icon": "media/icon_boxes" },
                { "label": AL2HMIBridge.mediaSource.filename, "icon": "media/icon_file" },
                { "label": AL2HMIBridge.mediaSource.foldername, "icon": "media/icon_folder" }]
    }

    function itunesMusicModel() {
        return [{ "label": AL2HMIBridge.mediaSource.artist, "icon": "media/icon_artistlist" },
                { "label": AL2HMIBridge.mediaSource.album, "icon": "media/icon_album" },
                { "label": AL2HMIBridge.mediaSource.composer, "icon": "media/icon_author" },
                { "label": AL2HMIBridge.mediaSource.genre, "icon": "media/icon_boxes" },
                { "label": AL2HMIBridge.mediaSource.filename, "icon": "media/icon_file" },
                { "label": AL2HMIBridge.mediaSource.foldername, "icon": "media/icon_folder" }]
    }


    function audioBookModel() {
        return [{ "label": AL2HMIBridge.mediaSource.artist, "icon": "media/icon_author" }, // Author
                { "label": AL2HMIBridge.mediaSource.title, "icon": "media/icon_song_title" },
                { "label": AL2HMIBridge.mediaSource.composer, "icon": "media/icon_narrator" }, // Narrator
                { "label": AL2HMIBridge.mediaSource.genre, "icon": "media/icon_boxes" },
                { "label": AL2HMIBridge.mediaSource.filename, "icon": "media/icon_file" },
                { "label": AL2HMIBridge.mediaSource.foldername, "icon": "media/icon_folder" }]
    }

    function podCastModel() {
        return [{ "label": AL2HMIBridge.mediaSource.composer, "icon": "media/icon_author" }, // Author
                { "label": AL2HMIBridge.mediaSource.title, "icon": "media/icon_episode" },
                { "label": AL2HMIBridge.mediaSource.genre, "icon": "media/icon_boxes" },
                { "label": AL2HMIBridge.mediaSource.filename, "icon": "media/icon_file" },
                { "label": AL2HMIBridge.mediaSource.foldername, "icon": "media/icon_folder" }]
    }
}
