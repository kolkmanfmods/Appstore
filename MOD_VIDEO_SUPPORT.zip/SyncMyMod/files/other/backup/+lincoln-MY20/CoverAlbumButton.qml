import QtQuick 2.0

import HmiGui 1.0

import Hmi.Ford.Controls 1.0

Item {
    id: root
    objectName: "CoverAlbumButton_root"

    property bool coverArtShown: false
    property bool endOfPlayList: false
    property bool showIconOnly: false
    property alias coverArtSource: coverAlbum.source
    property bool coverArtDriverRestiction:false

    signal clicked

    height: coverAlbum.height
    width: infoButton.width

    HmiImage {
        id: coverAlbum
        objectName: "CoverAlbumButton_coverAlbum"

        height: infoButton.visible ? 130 : 170
        anchors{
            left: parent.left
            right: parent.right
            bottom: infoButton.visible ? infoButton.top : parent.bottom
        }

        fillMode: Image.PreserveAspectFit

        HmiImage {
            id: infoIcon
            objectName: "CoverAlbumButton_infoIcon"

            visible: root.coverArtShown

            source: UiTheme.palette.icon("shared/icon_info", "_active", HmiGui.IconSmall)

            anchors{
                right: parent.right
                rightMargin: UiTheme.styleRoot.generalMarginSmall + (coverAlbum.width - coverAlbum.paintedWidth) / 2
                bottom: parent.bottom
                bottomMargin: UiTheme.styleRoot.generalMarginSmall + (coverAlbum.height - coverAlbum.paintedHeight) / 2
            }

        }

        MouseArea {
            id: mouseArea_CoverAlbumButton
            objectName: "CoverAlbumButton_mouseArea_CoverAlbumButton"
            anchors.fill: parent
            enabled: root.coverArtShown && ! root.endOfPlayList
            property bool beepOnClick: true
            onClicked: {
                root.clicked()
                ViewController.buttonClicked(mouseArea_CoverAlbumButton)
            }
        }
    }

    IconTextPushButton {
        id: infoButton
        objectName: "CoverAlbumButton_infoButton"
        visible: !root.coverArtShown && ! root.endOfPlayList && !showIconOnly

        anchors{
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: parent.bottom
        }

        shape: HmiGui.Flatter
        size: HmiGui.Regular

//~ OldTextID 93d6d900-a883-11e3-8a78-c8d719f8cdfe
//~ TextID 08cef350-3b1b-11e7-b9a7-0800276e80f7
        text: qsTr("Info")
        iconId: "shared/icon_info"
        textLocation: HmiGui.LeftCentered

        onClicked: root.clicked()
    }

    IconPushButton {
        id: infoIconButton
        objectName: "CoverAlbumButton_infoIconButton"
        visible: !root.coverArtShown && ! root.endOfPlayList && showIconOnly
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter

        shape: HmiGui.Round
        size: HmiGui.Small

        iconId: "shared/icon_info"

        onClicked: root.clicked()
    }
}
