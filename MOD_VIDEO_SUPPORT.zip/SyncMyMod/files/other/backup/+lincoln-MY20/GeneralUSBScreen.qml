import QtQuick 2.0

import HmiMedia 1.0
import HmiGui 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0
import HmiMedia 1.0
import HmiCore 1.0
import Hmi.Ford 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge
import QtQuick.Layouts 1.2

import "../MediaUtils.js" as MediaUtils

ExtendedMediaScreen {
    id: container
    objectName: "GeneralUsbScreen_container"

    property int selectedDevice: _hmiMedia.mediaController.lastSelectedDevice;
    property bool has30secondSupport: true
    property bool hasThumbsButtonSupport: false
    property bool isTrackBackButtonActive: true
    property bool songInformationSupported: false
    property string iconSource:""

    property alias hasShuffleSupport: shuffleButtons.hasShuffleSupport
    property alias hasRepeatSupport: shuffleButtons.hasRepeatSupport
    property alias onlyShuffleOrOnlyRepeatSupported: shuffleButtons.onlyShuffleOrOnlyRepeatSupported
    property alias deviceName: deviceName.text
    property string deviceTitle: ""
    property bool passengerExpectionAvailable: DrivingRestrictions.inUSConditionally(AL2HMIBridge.globalSource.driverRestrictionsGeneralAppsActive)
                                               && AL2HMIBridge.globalSource.passengerAvailable
                                               && !_hmiMedia.mediaController.passengerExceptionReset
    signal browseButtonClicked()

    titleDividerItem.visible: true
    sourceButton.size: HmiGui.Regular

    topRightButtons: [
        TextPushButton {
            id: browseButton
            objectName: "GeneralUsbScreen_browseButton"

            shape: HmiGui.Flatter
            size: HmiGui.Regular

            //~ TextID 9463136e-a883-11e3-97ec-c8d719f8cdfe
            text: qsTr("Browse")
            onClicked: {
                if (passengerExpectionAvailable) {
                    ViewController.showDriverRestrictionPopup(ViewController.DriverRestrictionTypeKPopup,MediaController.TemplatedBrowseItem);
                } else {
                    container.browseButtonClicked()
                }
            }
            //Visible when set to false disrupts the whole layout,since all the components are dependent on the topRightButtons component.
            //Hence Opacity and Active together are being used as an alternative.

            active: MediaUtils.browseVisible()
            opacity: active ? 1.0 : 0.0
        }
    ]

    topLeftButtons: Item {
        anchors.fill: parent

        HmiImage {
            id: albumCoverImage
            objectName: "coverAlbumButton_LincolnMY20"
            visible: AL2HMIBridge.globalSource.driverRestrictionsAlbumArtActive ? false
                                                                    : !AL2HMIBridge.mediaSource.endOfLastSongRepeatOff
            anchors {
                top: parent.top
                topMargin: UiTheme.styleRoot.generalMarginMedium
                horizontalCenter: parent.horizontalCenter
            }
            sourceSize: Qt.size(105, 105)
            source: AL2HMIBridge.mediaSource.coverArtAvailable ? AL2HMIBridge.mediaSource.coverArt : ""
            fillMode: Image.PreserveAspectFit
        }
    }

    title: TextLabel {
        id: deviceName

        anchors{
            left: parent.left
            right: parent.right
            top: parent.top
        }

        horizontalAlignment: Text.AlignHCenter
        variation: HmiGui.BigLabelVariation
        text: MediaUtils.getMediaDeviceName(AL2HMIBridge.mediaSource.curSelectedDevice)
        elide: Text.ElideRight
        color: "white"
    }


    content: Item {
        anchors.fill: parent
        anchors.bottomMargin: UiTheme.styleRoot.generalMarginSmall

        PlaybackScreenInfoContent {
            draggingSupported: AL2HMIBridge.mediaSource.progressBarJumpSupported
            elapsedTime: MediaUtils.getElapsedTime(dragging, draggingValue, AL2HMIBridge.mediaSource.totalHours,
                                                   AL2HMIBridge.mediaSource.totalMinutes, AL2HMIBridge.mediaSource.totalSeconds, AL2HMIBridge.mediaSource.elapsedHours,
                                                   AL2HMIBridge.mediaSource.elapsedMinutes, AL2HMIBridge.mediaSource.elapsedSeconds)
            elapsedTimeVisible: AL2HMIBridge.mediaSource.endOfLastSongRepeatOff ? false
                                                                    : AL2HMIBridge.mediaSource.totalHours !== AL2HMIBridge.mediaSource.elapsedHours
                                                                      || AL2HMIBridge.mediaSource.totalMinutes !== AL2HMIBridge.mediaSource.elapsedMinutes
                                                                      || AL2HMIBridge.mediaSource.totalSeconds !== AL2HMIBridge.mediaSource.elapsedSeconds
            totalTime: FormattingUtils.formatTimer(AL2HMIBridge.mediaSource.totalHours,
                                                   AL2HMIBridge.mediaSource.totalMinutes,
                                                   AL2HMIBridge.mediaSource.totalSeconds)

            //The progress bar and total play time shall not be displayed if the total play time is unknown or equal to 0.
            //The progress bar and total play time shall not be displayed if the elapsed time is greater than the total time or
            //equals -1 (Hex 0xFFFFFFFF).
            //The progress bar and total play time shall not be displayed if the total play time equals -1 (Hex 0xFFFFFFFF)
            totalTimeVisible: AL2HMIBridge.mediaSource.endOfLastSongRepeatOff ? false
                                                                  : (AL2HMIBridge.mediaSource.totalHours > 0
                                                                     || AL2HMIBridge.mediaSource.totalMinutes > 0
                                                                     || AL2HMIBridge.mediaSource.totalSeconds > 0)
                                                                    && (AL2HMIBridge.mediaSource.elapsedHours >= 0
                                                                        && AL2HMIBridge.mediaSource.elapsedMinutes >= 0
                                                                        && AL2HMIBridge.mediaSource.elapsedSeconds >= 0)
                                                                    && (AL2HMIBridge.mediaSource.elapsedHours < AL2HMIBridge.mediaSource.totalHours
                                                                        || (AL2HMIBridge.mediaSource.elapsedHours == AL2HMIBridge.mediaSource.totalHours
                                                                            && AL2HMIBridge.mediaSource.elapsedMinutes < AL2HMIBridge.mediaSource.totalMinutes)
                                                                        || (AL2HMIBridge.mediaSource.elapsedHours == AL2HMIBridge.mediaSource.totalHours
                                                                            && AL2HMIBridge.mediaSource.elapsedMinutes ==AL2HMIBridge.mediaSource.totalMinutes
                                                                            && AL2HMIBridge.mediaSource.elapsedSeconds <= AL2HMIBridge.mediaSource.totalSeconds))
            progress: AL2HMIBridge.mediaSource.scanningProgress;
            maximumValue: AL2HMIBridge.mediaSource.maxScanningProgressValue
            artist: AL2HMIBridge.mediaSource.artist
            songTitle: AL2HMIBridge.mediaSource.title
            currentTrack: AL2HMIBridge.mediaSource.mediaCurrentObject
            totalTracks: AL2HMIBridge.mediaSource.mediaTotalObjects
            trackInfoPos: Text.AlignHCenter
            onJumpTo: _hmiMedia.mediaController.requestMediaJump(pos)
        }
    }

    controlButtonsContent: RowLayout {
        height: trackControlButtons_GeneralUsbScreen.height
        anchors.fill: parent
        anchors.topMargin: UiTheme.styleRoot.generalMarginMedium
        spacing: 1

        ShuffleButtons {
            id: shuffleButtons
            spacing: 0

            anchors {
                verticalCenter: trackControlButtons_GeneralUsbScreen.verticalCenter
                verticalCenterOffset: 5
            }

            hasShuffleSupport: AL2HMIBridge.mediaSource.shuffleSupported
            hasRepeatSupport: AL2HMIBridge.mediaSource.repeatSupported

            onShuffleClicked: _hmiMedia.mediaController.mediaShuffle()
            onRepeatClicked: _hmiMedia.mediaController.mediaRepeat()

            shuffleStatus: AL2HMIBridge.mediaSource.shuffleStatus
            repeatStatus: AL2HMIBridge.mediaSource.repeatStatus !== AL2HMIBridge.MediaSource.None

            shuffleIconLocation: ViewController.rightToLeftLanguageActive ? HmiGui.Left : HmiGui.Right
            repeatIconLocation: ViewController.rightToLeftLanguageActive ? HmiGui.Right :
                                onlyShuffleOrOnlyRepeatSupported ? HmiGui.Centered :
                                                                   HmiGui.Left
            sourceTypeCD: false

            repeatIconId: AL2HMIBridge.mediaSource.repeatStatus === AL2HMIBridge.MediaSource.Single
                          ? "media/icon_repeat_1x" : "media/icon_repeat"
        }

        TrackControlButtons {
            id: trackControlButtons_GeneralUsbScreen

            anchors.bottom: parent.bottom
            anchors.horizontalCenter: parent.horizontalCenter
            playing:(AL2HMIBridge.mediaSource.audioStatus === AL2HMIBridge.MediaSource.Playing)

            show30Button: has30secondSupport
            showThumbsButtons: hasThumbsButtonSupport
            backButtonActive: isTrackBackButtonActive

            thumbsUpButtonStatus: AL2HMIBridge.mediaSource.thumbsUpButtonSelectedStatus
            thumbsDownButtonStatus: AL2HMIBridge.mediaSource.thumbsDownButtonSelectedStatus

            onPrevious30Clicked: _hmiMedia.mediaController.previous30SecPressed()

            onPreviousClicked: _hmiMedia.mediaController.mediaPrevious()
            onPreviousPressAndHold: _hmiMedia.mediaController.mediaPreviousLong(AL2HMIBridge.MediaSource.Pressed)
            onPreviousHoldAndReleased: _hmiMedia.mediaController.mediaPreviousLong(AL2HMIBridge.MediaSource.Released)

            onPlayPauseClicked: _hmiMedia.mediaController.mediaTogglePlayPause()

            onNextClicked: _hmiMedia.mediaController.mediaNext()
            onNextPressAndHold: _hmiMedia.mediaController.mediaNextLong(AL2HMIBridge.MediaSource.Pressed)
            onNextHoldAndReleased: _hmiMedia.mediaController.mediaNextLong(AL2HMIBridge.MediaSource.Released)

            onNext30Clicked: _hmiMedia.mediaController.next30SecPressed()

            onThumbsDownClicked: _hmiMedia.mediaController.toggleThumbsDownStatus()
            onThumbsUpClicked: _hmiMedia.mediaController.toggleThumbsUpStatus()
        }

        IconPushButton {
             id: infoButton
             objectName: "GeneralUsbScreen_infoButton"

             anchors.verticalCenter: trackControlButtons_GeneralUsbScreen.verticalCenter
             definedSize: Qt.size(_background.paintedHeight,_background.paintedWidth)

             backgroundSource: {
                 if (buttonState === HmiGui.Pressed) {
                     return UiTheme.palette.image("media/media_player_round_button_info_activepressed")
                 }
                 return UiTheme.palette.image("media/media_player_round_button_info_active")
             }

             state: "loaded"
             iconId: "shared/icon_info"
             visible: !AL2HMIBridge.mediaSource.endOfLastSongRepeatOff && AL2HMIBridge.mediaSource.mediaPlayerTrackType!== AL2HMIBridge.MediaSource.ItunesRadio

             onClicked: {
                 _hmiMedia.mediaController.requestTransition(MediaController.ToShowSongInformationUsb)
             }
         }
    }
}
