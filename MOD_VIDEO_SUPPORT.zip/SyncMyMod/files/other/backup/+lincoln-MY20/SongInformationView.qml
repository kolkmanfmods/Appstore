import QtQuick 2.6
import HmiMedia 1.0
import HmiGui 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0
import Hmi.Ford.Views 1.0

BackButtonTopScreenViewList {
    id: root
    objectName: "SongInformationView"

    property alias coverAlbumObjectName: coverAlbum.objectName
    property bool coverArtDriverRestiction: false
    property string songTitle: ""
    property string coverArt: ""

    alignContentToParentTop: false
    showTitleBar: true

    leftButtons: [
        HmiImage {
            id: coverAlbum
            objectName: "SongInformationView_coverAlbum"

            sourceSize: Qt.size(230, 230)
            visible: !coverArtDriverRestiction
            fillMode: Image.PreserveAspectFit
            source: coverArt
        }
    ]

    delegateSize: HmiGui.Regular
    delegateShape: HmiGui.Average
    delegate: songInfoDelegate

    Component {
        id: songInfoDelegate

        IconTextListItem {
            id: iconDelegate_SongInformationView

            anchors.right: parent.right

            size: root.delegateSize
            shape: root.delegateShape

            iconId: modelData.icon
            textLocation: ViewController.rightToLeftLanguageActive ? HmiGui.Left : HmiGui.Right

            HorizontallyScrolledTextLabel {
                id: songInfoBtn

                anchors{
                    left: iconDelegate_SongInformationView.iconComponent.right
                    leftMargin: UiTheme.styleRoot.generalMarginSmall
                    right: parent.right
                    rightMargin: UiTheme.styleRoot.generalMarginSmall
                    verticalCenter: parent.verticalCenter
                }

                text: modelData.label
            }
        }
    }
}
