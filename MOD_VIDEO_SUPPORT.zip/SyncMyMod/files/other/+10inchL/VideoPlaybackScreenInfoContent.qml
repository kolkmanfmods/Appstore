import QtQuick 2.0
import HmiGui 1.0
import HmiMedia 1.0
import HmiGuiFramework.Controls 1.0
import Hmi.Ford.Controls 1.0


Item {
    id: root

    property alias elapsedTime: elapsedTimeLabel.text
    property alias totalTime: totalTimeLabel.text
    property alias totalTimeVisible: totalTimeLabel.visible
    property alias elapsedTimeVisible: elapsedTimeLabel.visible
    property alias progress: progressBar.audioprogress
    property alias maximumValue: progressBar.maximumValue

    property alias artist: artistLabel.text
    property alias songTitle: songTitleLabel.text

    property int currentTrack: 0
    property int totalTracks: 0
    property bool wishListVisible: false

    property alias draggingSupported: progressBar.enabled
    property alias dragging: progressBar.dragging
    property alias displayedValue: progressBar.displayedValue
    property alias dragOperationInProgress: progressBar.dragOperationInProgress

    signal jumpTo(real pos)

    anchors.top: parent.top
    anchors.topMargin: UiTheme.styleRoot.generalMarginSmall*2

    Column {
        id: artistAndTitleLabels
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        anchors.topMargin: UiTheme.styleRoot.generalMarginSmall + 5

        height: UiTheme.styleRoot.gridSizes.rowHeight2x - 5
        width: UiTheme.styleRoot.gridSizes.columnWidth6x + 2*UiTheme.styleRoot.generalMarginSmall
        spacing: UiTheme.styleRoot.gridSizes.verticalSpacing

        LayoutMirroring.enabled: ViewController.rightToLeftLanguageActive
        LayoutMirroring.childrenInherit: true

        TextLabel {
            id: artistLabel
            width: wishListVisible ? 500 : parent.width
            elide: !ViewController.rightToLeftLanguageActive ? Text.ElideRight
                                                             : Text.ElideLeft
            anchors.horizontalCenter: parent.horizontalCenter
            horizontalAlignment: Text.AlignHCenter
        }

        TextLabel {
            id: songTitleLabel
            width: parent.width
            elide: !ViewController.rightToLeftLanguageActive ? Text.ElideRight
                                                             : Text.ElideLeft
            horizontalAlignment: Text.AlignHCenter
            variation: HmiGui.ExtraLargeLabelVariation
        }

        TextLabel {
            id: trackInformation
            width: parent.width
			anchors.horizontalCenter: parent.horizontalCenter
			anchors.horizontalCenterOffset: 5
            //~ TextID 38488d12-e6f6-11e7-af74-08002718b8d7
            text: qsTr("%1/%2 ").arg(currentTrack).arg(totalTracks)
            visible: totalTracks > 0 && currentTrack >= 0
            variation: HmiGui.LargeLabelVariation
            horizontalAlignment: Text.AlignHCenter
        }
    }

    Item {
        anchors.top: artistAndTitleLabels.bottom
        anchors.topMargin: -42
		anchors.horizontalCenter: parent.horizontalCenter
		
        width: UiTheme.styleRoot.gridSizes.rightColumn1Right - UiTheme.styleRoot.gridSizes.column1Left

        Slider {
            id: progressBar
            maximumValue: 100
            minimumValue: 0
            visible: totalTimeLabel.visible
            width: UiTheme.styleRoot.gridSizes.columnWidth5x

            anchors.top: parent.top
            anchors.topMargin: 21
            anchors.horizontalCenter: parent.horizontalCenter
			
            onJumpTo: _hmiMedia.mediaController.requestMediaJump(pos)

            property real audioprogress: 0.0

            onAudioprogressChanged: {
                if (!dragging) {
                    sliderValue = audioprogress
                }
            }
        }

        TextLabel {
            id: elapsedTimeLabel
            anchors.left: progressBar.left
            anchors.top: progressBar.bottom
            anchors.topMargin: 3
            variation: HmiGui.LargeLabelVariation
        }

        TextLabel {
            id: totalTimeLabel
            anchors.right: progressBar.right
            anchors.top: progressBar.bottom
            anchors.topMargin: 3
            horizontalAlignment: Text.AlignRight
            variation: HmiGui.LargeLabelVariation
        }
    }
}
