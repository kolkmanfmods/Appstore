import QtQuick 2.0

import HmiGui 1.0
import HmiGuiFramework 1.0
import HmiGuiFramework.Controls 1.0

import Hmi.Ford 1.0
import Hmi.Ford.Controls 1.0

Item {
    id: root

    property bool playing: false

    property alias backButtonActive: backButton.active
    property alias previousButtonVisible: backButton.visible
    property alias playPauseButtonVisible: playPauseButton.visible
    property alias nextButtonVisible: nextButton.visible

    signal previousClicked
    signal previousPressAndHold
    signal previousHoldAndReleased

    signal playPauseClicked

    signal nextClicked
    signal nextPressAndHold
    signal nextHoldAndReleased


    IconPushButton {
        id: backButton
        property string squishID

        anchors.verticalCenter: playPauseButton.verticalCenter
        anchors.right: playPauseButton.left
        anchors.rightMargin:34

        property bool hold: false
        iconComponent.enableIconState : active
        iconColor: UiTheme.palette.iconColorInactive

        shape: HmiGui.Round
        size: HmiGui.Bigger
        borderOffset: 0
        backgroundSmooth: true

        iconId: "media/icon_rewind"

        active: backButtonActive

        onPressAndHold: {
            hold = true;
            previousPressAndHold()
        }
        clickAfterPressAndHold: false

        onPressed: hold = false

        onExited: {
            if (hold) {
                previousHoldAndReleased()
            }
            hold = false
        }

        onReleased: {
            if (hold) {
                previousHoldAndReleased()
            }
            hold = false
        }

        onClicked: previousClicked()
    }

    IconPushButton {
        id: playPauseButton
        property string squishID

        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom

        shape: HmiGui.Round
        size: HmiGui.Huge
        borderOffset: 0

        iconId: root.playing ? "media/icon_pause" : "media/icon_play"
        backgroundSmooth: true

        onClicked: playPauseClicked()
    }

    HmiImage {
        id: _img_playEmboss
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: playPauseButton.verticalCenter
        anchors.verticalCenterOffset: 1.5
        source: UiTheme.palette.image("media/play_pause_emboss");
        visible: nextButtonVisible && previousButtonVisible && playPauseButtonVisible
        smooth: true
    }

    HmiImage {
        id: _img_playOnlyEmboss
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: playPauseButton.verticalCenter
        // TODO: change image once we have correct asset
        source: UiTheme.palette.image("nav/COMPASS_EMBOSS_BG")
        scale: 0.84
        height: _img_playEmboss.height
        width: height
        visible: playPauseButton.visible && !_img_playEmboss.visible
        smooth: true
    }

    IconPushButton {
        id: nextButton
        property string squishID

        anchors.verticalCenter: playPauseButton.verticalCenter
        anchors.left: playPauseButton.right
        anchors.leftMargin:34

        property bool hold: false

        shape: HmiGui.Round
        size: HmiGui.Bigger
        borderOffset: 0
        backgroundSmooth: true

        iconId: "media/icon_fastforward"

        onPressAndHold: {
            hold = true;
            nextPressAndHold()
        }
        clickAfterPressAndHold: false

        onPressed: hold = false

        onExited: {
            if (hold) {
                nextHoldAndReleased()
            }
            hold = false
        }

        onReleased: {
            if (hold) {
                nextHoldAndReleased()
            }
            hold = false
        }

        onClicked: nextClicked()
    }
}
