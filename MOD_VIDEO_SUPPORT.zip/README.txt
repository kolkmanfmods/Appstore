//***********************************************************************************************************************************************************************//
//*                                                                                                                                                                 	*//
//*                 AAA                                TTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEE               AAA               MMMMMMMM               MMMMMMMM	*//
//*                A:::A                               T:::::::::::::::::::::TE::::::::::::::::::::E              A:::A              M:::::::M             M:::::::M	*//
//*               A:::::A                              T:::::::::::::::::::::TE::::::::::::::::::::E             A:::::A             M::::::::M           M::::::::M	*//
//*              A:::::::A                             T:::::TT:::::::TT:::::TEE::::::EEEEEEEEE::::E            A:::::::A            M:::::::::M         M:::::::::M	*//
//*             A:::::::::A                            TTTTTT  T:::::T  TTTTTT  E:::::E       EEEEEE           A:::::::::A           M::::::::::M       M::::::::::M	*//
//*            A:::::A:::::A                                   T:::::T          E:::::E                       A:::::A:::::A          M:::::::::::M     M:::::::::::M	*//
//*           A:::::A A:::::A                                  T:::::T          E::::::EEEEEEEEEE            A:::::A A:::::A         M:::::::M::::M   M::::M:::::::M	*//
//*          A:::::A   A:::::A         ---------------         T:::::T          E:::::::::::::::E           A:::::A   A:::::A        M::::::M M::::M M::::M M::::::M	*//
//*         A:::::A     A:::::A        -:::::::::::::-         T:::::T          E:::::::::::::::E          A:::::A     A:::::A       M::::::M  M::::M::::M  M::::::M	*//
//*        A:::::AAAAAAAAA:::::A       ---------------         T:::::T          E::::::EEEEEEEEEE         A:::::AAAAAAAAA:::::A      M::::::M   M:::::::M   M::::::M	*//
//*       A:::::::::::::::::::::A                              T:::::T          E:::::E                  A:::::::::::::::::::::A     M::::::M    M:::::M    M::::::M	*//
//*      A:::::AAAAAAAAAAAAA:::::A                             T:::::T          E:::::E       EEEEEE    A:::::AAAAAAAAAAAAA:::::A    M::::::M     MMMMM     M::::::M	*//
//*     A:::::A             A:::::A                          TT:::::::TT      EE::::::EEEEEEEE:::::E   A:::::A             A:::::A   M::::::M               M::::::M	*//
//*    A:::::A               A:::::A                         T:::::::::T      E::::::::::::::::::::E  A:::::A               A:::::A  M::::::M               M::::::M	*//
//*   A:::::A                 A:::::A                        T:::::::::T      E::::::::::::::::::::E A:::::A                 A:::::A M::::::M               M::::::M	*//
//*  AAAAAAA                   AAAAAAA                       TTTTTTTTTTT      EEEEEEEEEEEEEEEEEEEEEEAAAAAAA                   AAAAAAAMMMMMMMM               MMMMMMMM	*//
//*                                                                                                                                                                 	*//
//***********************************************************************************************************************************************************************//
//************************************************************************ SYNC 3 VIDEO PLAYER  *************************************************************************//
//*																																									    *//
//* Developed by AJC and Au{R}oN																																	    *//
//*																																									    *//
//* www.fmods.net																															   		  				    *//
//*																																									    *//
//***************************************************************************** CHANGELOG *******************************************************************************//
//*																																									    *//
//* ## v1.0 - 2017-12-26 																																			    *//
//* - Initial Release, rely on Navigation Screen																													    *//
//*																																									    *//
//* ## v2.0 - 2018-12-09 																																			    *//
//* - Updated QML files to make it works on Music Info Screen, allowing Nav Screen and Video Playback to exist at the same time 									    *//
//* - Added an alternative Music Info image during video files playback (Thanks to Marcus from fordfocus.forumcommunity.net for the image)							    *//
//*																																									    *//
//* ## v2.1 - 2019-02-24 																																			    *//
//* - Created a new branch for SYNC 3 version 3.4																											   		    *//
//*																																									    *//
//* ## v2.2 - 2019-08-30 																																			    *//
//* - Updated the package to works on build 3.4.19200 (dropped support for previous 3.4 builds)																   		    *//
//*																																									    *//
//* ## v2.3 - 2020-09-16 																																			    *//
//* - Updated the package to works on build 3.4.20196 (dropped support for previous 3.4 builds)																   		    *//
//*																																									    *//
//* ## v2.4 - 2021-04-02																																			    *//
//* - Updated the package to works on build 3.4.21020 (dropped support for previous 3.4 builds)																   		    *//
//* - Fixed an issue with Video Control buttons images (Thanks to Multimen for the graphics file)															   		    *//
//*																																									    *//
//* ## v2.5 - 2021-04-09																																			    *//
//* - Installation script updated for new Mods Tools										   																   		    *//
//*																																									    *//
//* ## v2.6 - 2021-07-29 																																			    *//
//* - Updated the package to works on build 3.4.21194 (dropped support for previous 3.4 builds) 																	    *//
//*																																									    *//
//* ## v2.7 - 2021-11-06 																																			    *//
//* - Added support for .mkv (matroska) file extension.												 																    *//
//* - Fixed a graphical issue with video files that contain metadata.									 														   	    *//
//*																																									    *//
//* ## v2.8 - 2024-06-02 																																			    *//
//* - Added support for FMods Tools 2.9 and uninstall script.										 																    *//
//*																																									    *//
//***********************************************************************************************************************************************************************//