#!/bin/sh
PATH="/fs/rwdata/dev:${PATH}"
USBDAY=/fs/usb0/customerBackgrounds/day
USBNIGHT=/fs/usb0/customerBackgrounds/night
SYSTEMDAY=/fs/mp/fordhmi/customerBackgrounds/day
SYSTEMNIGHT=/fs/mp/fordhmi/customerBackgrounds/night

ACTION="$1"
FILEPATH="$2"
COMPLETION_FLAG="/fs/tmpfs/background_operation_complete"
PROGRESS_FILE="/fs/tmpfs/background_operation_progress"
IMAGE_EXTENSIONS="*.[Pp][Nn][Gg] *.[Jj][Pp][Gg] *.[Jj][Pp][Ee][Gg] *.[Bb][Mm][Pp] *.[Gg][Ii][Ff]"

# Since FMods Tools 3.0 autostarts the script, let it Exit when there are no arguments (user action)
if [ -z "$1" ]; then
	exit 0
fi
rm -f "$COMPLETION_FLAG"

initialize_json_files() {
	if [ ! -f "$SYSTEMDAY/viewBackgrounds.json" ]; then
		echo "[]" > "$SYSTEMDAY/viewBackgrounds.json"
	fi

	if [ ! -f "$SYSTEMNIGHT/viewBackgrounds.json" ]; then
		echo "[]" > "$SYSTEMNIGHT/viewBackgrounds.json"
	fi
}

generate_json_files() {
	printf "[" > "$SYSTEMDAY"/viewBackgrounds.json
	for ext in $IMAGE_EXTENSIONS; do
		for i in ${SYSTEMDAY}/${ext}; do
			[ -e "$i" ] || continue
			printf '{"mainImage":"'%s'", "menuBarImageMap":{"default":"navbar_background.png"}},' "$(basename "$i")";
		done
	done | sed -e 's/,$/]/' >> "$SYSTEMDAY"/viewBackgrounds.json
	printf "[" > "$SYSTEMNIGHT"/viewBackgrounds.json
	for ext in $IMAGE_EXTENSIONS; do
		for i in ${SYSTEMNIGHT}/${ext}; do
			[ -e "$i" ] || continue
			printf '{"mainImage":"'%s'", "menuBarImageMap":{"default":"navbar_background.png"}},' "$(basename "$i")";
		done
	done | sed -e 's/,$/]/' >> "$SYSTEMNIGHT"/viewBackgrounds.json
}

delete_backgrounds() {
	echo "Deleting all backgrounds..." > "$PROGRESS_FILE"
	sleep 1.0
	rm -rf "${SYSTEMDAY:?}"/*
	rm -rf "${SYSTEMNIGHT:?}"/*
}

delete_background() {
	filepath="$1"
	filename=$(basename "$filepath")
	echo "Deleting $filename..." > "$PROGRESS_FILE"
	sleep 1.0
	if [ -f "$SYSTEMDAY/$filename" ]; then
		rm -f "$SYSTEMDAY/$filename"
	fi
	if [ -f "$SYSTEMNIGHT/$filename" ]; then
		rm -f "$SYSTEMNIGHT/$filename"
	fi
}

add_backgrounds() {
	total=0
	current=0
	if [ -d "$USBDAY" ]; then
		for ext in $IMAGE_EXTENSIONS; do
			for i in ${USBDAY}/${ext}; do
				[ -e "$i" ] || continue
				total=$((total + 1))
			done
		done
	fi
	if [ -d "$USBNIGHT" ]; then
		for ext in $IMAGE_EXTENSIONS; do
			for i in ${USBNIGHT}/${ext}; do
				[ -e "$i" ] || continue
				total=$((total + 1))
			done
		done
	fi
	if [ -d "$USBDAY" ]; then
		for ext in $IMAGE_EXTENSIONS; do
			for i in ${USBDAY}/${ext}; do
				[ -e "$i" ] || continue
				current=$((current + 1))
				echo "Copying background $current of $total..." > "$PROGRESS_FILE"
				cp "$i" "$SYSTEMDAY"
			done
		done
	fi
	if [ -d "$USBNIGHT" ]; then
		for ext in $IMAGE_EXTENSIONS; do
			for i in ${USBNIGHT}/${ext}; do
				[ -e "$i" ] || continue
				current=$((current + 1))
				echo "Copying background $current of $total..." > "$PROGRESS_FILE"
				cp "$i" "$SYSTEMNIGHT"
			done
		done
	fi
}

remount_rw.sh
sleep 1.0
initialize_json_files

if [ "$ACTION" = "add" ]; then
	add_backgrounds
	elif [ "$ACTION" = "delete" ]; then
		delete_backgrounds
	elif [ "$ACTION" = "delete_single" ]; then
		delete_background "$FILEPATH"
fi

echo "Generating backgrounds list..." > "$PROGRESS_FILE"
generate_json_files
remount_ro.sh
sleep 1.0
sync
sync
sync
echo "done" > "$COMPLETION_FLAG"
exit 0
