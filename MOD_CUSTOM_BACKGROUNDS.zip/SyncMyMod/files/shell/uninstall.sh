#!/bin/sh
# shellcheck disable=SC2086 disable=SC3006 disable=SC3054
#########################################################################################################################################################################
#	Installation script for Custom Background Daemon					  																								#
#########################################################################################################################################################################
#																																										#
#					AAA								   TTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEE			   AAA				 MMMMMMMM				MMMMMMMM	#
#				   A:::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			  A:::A				 M:::::::M			   M:::::::M	#
#				  A:::::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			 A:::::A			 M::::::::M			  M::::::::M	#
#				 A:::::::A							   T:::::TT:::::::TT:::::TEE::::::EEEEEEEEE::::E			A:::::::A			 M:::::::::M		 M:::::::::M	#
#				A:::::::::A							   TTTTTT  T:::::T  TTTTTT  E:::::E		  EEEEEE		   A:::::::::A			 M::::::::::M		M::::::::::M	#
#			   A:::::A:::::A								   T:::::T			E:::::E			 			  A:::::A:::::A			 M:::::::::::M	   M:::::::::::M	#
#			  A:::::A A:::::A								   T:::::T			E::::::EEEEEEEEEE			 A:::::A A:::::A		 M:::::::M::::M   M::::M:::::::M	#
#			 A:::::A   A:::::A		   ---------------		   T:::::T			E:::::::::::::::E			A:::::A   A:::::A		 M::::::M M::::M M::::M M::::::M	#
#			A:::::A		A:::::A		   -:::::::::::::-		   T:::::T			E:::::::::::::::E		   A:::::A	   A:::::A		 M::::::M  M::::M::::M  M::::::M	#
#		   A:::::AAAAAAAAA:::::A	   ---------------		   T:::::T			E::::::EEEEEEEEEE		  A:::::AAAAAAAAA:::::A		 M::::::M   M:::::::M   M::::::M	#
#		  A:::::::::::::::::::::A							   T:::::T			E:::::E			 		 A:::::::::::::::::::::A	 M::::::M	 M:::::M	M::::::M	#
#		 A:::::AAAAAAAAAAAAA:::::A							   T:::::T			E:::::E		  EEEEEE	A:::::AAAAAAAAAAAAA:::::A	 M::::::M	  MMMMM		M::::::M	#
#		A:::::A				A:::::A							 TT:::::::TT	  EE::::::EEEEEEEE:::::E   A:::::A			   A:::::A   M::::::M				M::::::M	#
#	   A:::::A				 A:::::A						 T:::::::::T	  E::::::::::::::::::::E  A:::::A				A:::::A  M::::::M				M::::::M	#
#	  A:::::A				  A:::::A						 T:::::::::T	  E::::::::::::::::::::E A:::::A				 A:::::A M::::::M				M::::::M	#
#	 AAAAAAA				   AAAAAAA						 TTTTTTTTTTT	  EEEEEEEEEEEEEEEEEEEEEEAAAAAAA					 AAAAAAAMMMMMMMM				MMMMMMMM	#
#																																										#
#########################################################################################################################################################################
#																																										#
#							 ###############																															#
#							#				#																															#
#						  #					 #					M			 M						 D			 														#
#				 #########	   FFFFFFFFFFF	  #########			MM			MM						 D			 														#
#						#	   FF			   #				M M		   M M   OOOOOOOO	DDDDDDD D   SSSSSSSS		   NN		N  EEEEEEEEEE  TTTTTTTTTT			#
#			############	   FF FFFF			############	M  M	  M  M  O		 O  D		 D  S				   N NN		N  EE			   TT				#
#						#	   FF			   #				M   M	 M   M  O		 O  D		 D   SSSSSSSS		   N   NN   N  EEEEEEEEEE	   TT				#
#				 #########	   FF			  #########			M	  M M	 M  O		 O  D		 D			 S   ###   N	 NN N  EE			   TT				#
#						  #	   FF			 #					M	   M	 M   OOOOOOOO	DDDDDDDD	 SSSSSSSS	 ###   N	   NN  EEEEEEEEEE	   TT				#
#						   #				#																															#
#							################																															#
#																																										#
#########################################################################################################################################################################

# Mod Name	  : 	Custom Background Loader ( CUSTOM_BACKGROUNDS ).
# Author		: 	Au{R}oN | www.fmods.net.
# Creation date : 	2017-12-28.
# Version	   : 	3.4.
# Update date   : 	2024-06-02.
# Update notes  : 	Adjusted to support FMods Tools 2.8 and added an uninstall script.

#########################################################################################################################################################################
#	Delete commands.																																					#
#########################################################################################################################################################################

MOD_NAME="CUSTOM_BACKGROUNDS"
PATH="/fs/rwdata/dev:${PATH}"
MODS_PATH="/fs/images/fmods_mods_data/"
# MODS_JSON_PATH="${MODS_PATH}/mods.json"
SHORT="${MODS_PATH}/${MOD_NAME}"
PATCH_DIR="${SHORT}/patch"
UNPATCH=1

# Remove also the dependencies from the installed_mods.txt and set the status to deleted for all Mods depending on this one to be installed first.
# DEPENDENCY1="RVC_SAFETY_REMOVER"
# DEPENDENCY1_PATH="${MODS_PATH}/${DEPENDENCY1}"
# sed -i -e "/${DEPENDENCY1}/d" 																	"/fs/mp/etc/installed_mods.txt"
# if [ -f "${DEPENDENCY1_PATH}/uninstall/uninstall.sh" ]; then
#	 chmod +x "${DEPENDENCY1_PATH}/uninstall/uninstall.sh"
#	 sh "${DEPENDENCY1_PATH}/uninstall/uninstall.sh"

#	 if grep -q "${DEPENDENCY1}" 																	"${MODS_JSON_PATH}"; then
#		 jq --arg modName "$DEPENDENCY1" '(.mods[] | select(.modName == $modName)).modUninstallFile = "deleted"' "${MODS_JSON_PATH}" > "/tmp/tmp.json"
#		 mv "/tmp/tmp.json" 																		"${MODS_JSON_PATH}"
#	 fi
# fi
if [ "${UNPATCH:-0}" -eq 1 ]; then
	if ! patch -l --dry-run -R -p0 < 																"${PATCH_DIR}/master.patch" > "${SHORT}/patch.log"; then
		MANUAL=1
	else
		patch -l -b -R -p0 < 																		"${PATCH_DIR}/master.patch"
	fi
fi
if [ "${UNPATCH:-0}" -eq 0 ] || [ "${MANUAL:-0}" -eq 1 ]; then
	if [ -f "${SHORT}/backup/+10inchP/BackgroundSettings.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmisettings/display/+10inchP/"*
		rm -f "/fs/mp/fordhmi/qml/hmisettings/display/+10inchP/BackgroundSettings.qml"
		cp "${SHORT}/backup/+10inchP/BackgroundSettings.qml"										"/fs/mp/fordhmi/qml/hmisettings/display/+10inchP/BackgroundSettings.qml"
	fi
	if [ -f "${SHORT}/backup/BackgroundSettings.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmisettings/display/"*
		rm -f "/fs/mp/fordhmi/qml/hmisettings/display/BackgroundSettings.qml"
		cp "${SHORT}/backup/BackgroundSettings.qml"													"/fs/mp/fordhmi/qml/hmisettings/display/BackgroundSettings.qml"
	fi
fi

if ! grep -q "CUSTOM_10L_BACKGROUNDS" 																"/fs/mp/etc/installed_mods.txt"; then
	# Remove custom_backgrounds_loader.sh from folder: /fs/mp/scripts/fmods/
	chmod a+x "/fs/mp/scripts/fmods/"*
	rm -f "/fs/mp/scripts/fmods/custom_backgrounds_loader.sh"
fi

# Folders:
# /fs/mp/fordhmi/customerBackgrounds
# /fs/mp/fordhmi/customerBackgrounds/day
# /fs/mp/fordhmi/customerBackgrounds/night
# are not removed yet (other mods use them too).