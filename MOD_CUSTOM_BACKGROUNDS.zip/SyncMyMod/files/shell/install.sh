#!/bin/sh
# shellcheck disable=SC2086 disable=SC3006 disable=SC3054
#########################################################################################################################################################################
#	Installation script for Custom Background Daemon					  																								#
#########################################################################################################################################################################
#																																										#
#					AAA								   TTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEE			   AAA				 MMMMMMMM				MMMMMMMM	#
#				   A:::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			  A:::A				 M:::::::M			   M:::::::M	#
#				  A:::::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			 A:::::A			 M::::::::M			  M::::::::M	#
#				 A:::::::A							   T:::::TT:::::::TT:::::TEE::::::EEEEEEEEE::::E			A:::::::A			 M:::::::::M		 M:::::::::M	#
#				A:::::::::A							   TTTTTT  T:::::T  TTTTTT  E:::::E		  EEEEEE		   A:::::::::A			 M::::::::::M		M::::::::::M	#
#			   A:::::A:::::A								   T:::::T			E:::::E			 			  A:::::A:::::A			 M:::::::::::M	   M:::::::::::M	#
#			  A:::::A A:::::A								   T:::::T			E::::::EEEEEEEEEE			 A:::::A A:::::A		 M:::::::M::::M   M::::M:::::::M	#
#			 A:::::A   A:::::A		   ---------------		   T:::::T			E:::::::::::::::E			A:::::A   A:::::A		 M::::::M M::::M M::::M M::::::M	#
#			A:::::A		A:::::A		   -:::::::::::::-		   T:::::T			E:::::::::::::::E		   A:::::A	   A:::::A		 M::::::M  M::::M::::M  M::::::M	#
#		   A:::::AAAAAAAAA:::::A	   ---------------		   T:::::T			E::::::EEEEEEEEEE		  A:::::AAAAAAAAA:::::A		 M::::::M   M:::::::M   M::::::M	#
#		  A:::::::::::::::::::::A							   T:::::T			E:::::E			 		 A:::::::::::::::::::::A	 M::::::M	 M:::::M	M::::::M	#
#		 A:::::AAAAAAAAAAAAA:::::A							   T:::::T			E:::::E		  EEEEEE	A:::::AAAAAAAAAAAAA:::::A	 M::::::M	  MMMMM		M::::::M	#
#		A:::::A				A:::::A							 TT:::::::TT	  EE::::::EEEEEEEE:::::E   A:::::A			   A:::::A   M::::::M				M::::::M	#
#	   A:::::A				 A:::::A						 T:::::::::T	  E::::::::::::::::::::E  A:::::A				A:::::A  M::::::M				M::::::M	#
#	  A:::::A				  A:::::A						 T:::::::::T	  E::::::::::::::::::::E A:::::A				 A:::::A M::::::M				M::::::M	#
#	 AAAAAAA				   AAAAAAA						 TTTTTTTTTTT	  EEEEEEEEEEEEEEEEEEEEEEAAAAAAA					 AAAAAAAMMMMMMMM				MMMMMMMM	#
#																																										#
#########################################################################################################################################################################
#																																										#
#							 ###############																															#
#							#				#																															#
#						  #					 #					M			 M						 D			 														#
#				 #########	   FFFFFFFFFFF	  #########			MM			MM						 D			 														#
#						#	   FF			   #				M M		   M M   OOOOOOOO	DDDDDDD D   SSSSSSSS		   NN		N  EEEEEEEEEE  TTTTTTTTTT			#
#			############	   FF FFFF			############	M  M	  M  M  O		 O  D		 D  S				   N NN		N  EE			   TT				#
#						#	   FF			   #				M   M	 M   M  O		 O  D		 D   SSSSSSSS		   N   NN   N  EEEEEEEEEE	   TT				#
#				 #########	   FF			  #########			M	  M M	 M  O		 O  D		 D			 S   ###   N	 NN N  EE			   TT				#
#						  #	   FF			 #					M	   M	 M   OOOOOOOO	DDDDDDDD	 SSSSSSSS	 ###   N	   NN  EEEEEEEEEE	   TT				#
#						   #				#																															#
#							################																															#
#																																										#
#########################################################################################################################################################################

# Mod Name	  : 	Custom Background Loader ( CUSTOM_BACKGROUNDS ).
# Author		: 	Au{R}oN | www.fmods.net.
# Creation date : 	2017-12-28.
# Version	   : 	3.4.
# Update date   : 	2024-06-02.
# Update notes  : 	Adjusted to support FMods Tools 2.8 and added an uninstall script.

#########################################################################################################################################################################
#	Install commands.																																					#
#########################################################################################################################################################################

MOD_NAME="CUSTOM_BACKGROUNDS"
PATH="/fs/rwdata/dev:${PATH}"
MODS_PATH="/fs/images/fmods_mods_data/"
SHORT="${MODS_PATH}/${MOD_NAME}"
PATCH_DIR="${SHORT}/patch"
PATCH=1
if [ "${PATCH;-0}" -eq 1 ]; then
	if ! patch -l --dry-run -p0 < 																"${PATCH_DIR}/master.patch" > "${SHORT}/patch.log"; then
		MANUAL=1
	else
		patch -l -b -p0 < 																		"${PATCH_DIR}/master.patch"
	fi
fi
if [ "${PATCH:-0}" -eq 0 ] || [ "${MANUAL:-0}" -eq 1 ]; then
	if [ -f "${SHORT}/new/+10inchP/BackgroundSettings.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmisettings/display/+10inchP/"*
		rm -f "/fs/mp/fordhmi/qml/hmisettings/display/+10inchP/BackgroundSettings.qml"
		cp "${SHORT}/new/+10inchP/BackgroundSettings.qml"										"/fs/mp/fordhmi/qml/hmisettings/display/+10inchP/BackgroundSettings.qml"
	fi

	if [ -f "${SHORT}/new/BackgroundSettings.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmisettings/display/"*
		rm -f "/fs/mp/fordhmi/qml/hmisettings/display/BackgroundSettings.qml"
		cp "${SHORT}/new/BackgroundSettings.qml"												"/fs/mp/fordhmi/qml/hmisettings/display/BackgroundSettings.qml"
	fi
fi

# Creating new folders
if [ ! -d "/fs/mp/fordhmi/customerBackgrounds" ]; then
	mkdir -p "/fs/mp/fordhmi/customerBackgrounds"
	if [ ! -d "/fs/mp/fordhmi/customerBackgrounds/day" ]; then
		mkdir -p "/fs/mp/fordhmi/customerBackgrounds/day"
	fi
	if [ ! -d "/fs/mp/fordhmi/customerBackgrounds/night" ]; then
		mkdir -p "/fs/mp/fordhmi/customerBackgrounds/night"
	fi
fi

# Core Files
cp "${SHORT}/new/custom_backgrounds_loader.sh" 													"/fs/mp/scripts/fmods/"
chmod a+x "/fs/mp/scripts/fmods/custom_backgrounds_loader.sh"

# Folders:
# "/fs/mp/fordhmi/customerBackgrounds"
# "/fs/mp/fordhmi/customerBackgrounds/day"
# "/fs/mp/fordhmi/customerBackgrounds/night"
# are not removed yet (other mods use them too).