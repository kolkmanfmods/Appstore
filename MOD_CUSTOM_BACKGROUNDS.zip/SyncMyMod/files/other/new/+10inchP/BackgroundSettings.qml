import QtQuick 2.0
import HmiGuiFramework.Controls 1.0
import HmiGui 1.0

import Hmi.Ford.ButtonGrids 1.0
import Hmi.Ford.Controls 1.0
import Hmi.Ford.Views 1.0
import Hmi.Ford.Popups 1.0
import PasaHmiExtension 1.0
import "../settings-utils.js" as Utils

import HmiPhone 1.0
import "../../hmiphone/phone-utils.js" as PhoneUtils
import AL2HMIBridge 1.0 as AL2HMIBridge

BackButtonTopScreenView {
    id: root
    objectName: "BackgroundSettings"

    property bool isCallActive : PhoneUtils.statusIsInPhoneCall(_hmiphoneController.phoneSource.status)

//~ TextID 38488a79-e6f6-11e7-af74-08002718b8d7
    titleText: qsTr("Background")
    alignContentToParentTop: false

    HmiImage {
        id: backgroundImage
        objectName: "BackgroundSettings_backgroundImage"
        source: UiTheme.palette.image(UiTheme.palette.viewBackground)

        // So the back button will be visible on top of the image.
        z: -1
    }

    property bool pendingAction: false
	property var action: ""
	property string selectedBackgroundPath: ""
	property bool operationComplete: false
	property bool showManagePopup: false
	
	QuestionDialogBase {
		id: actionPopup
		popupSize: HmiGui.Regular
		buttonSpacing: UiTheme.styleRoot.generalMarginBig
		visible: pendingAction
		
		questionContents: Rectangle {
			color: "transparent"
			anchors.top: parent.top
			anchors.topMargin: -100
			anchors.horizontalCenter: parent.horizontalCenter
			width: actionPopup.definedSize.width
			height: actionPopup.definedSize.height

			TextLabel {
				id: questionTextLabel
				anchors.top: parent.top
				anchors.horizontalCenter: parent.horizontalCenter
				width: parent.width
				horizontalAlignment: Text.AlignHCenter
			}

			TextPushButton {
				id: okBtn
				anchors.top: questionTextLabel.bottom
				anchors.topMargin: 80
				anchors.left: parent.left
				anchors.leftMargin: 20
				visible: !progressTimer.running && !operationComplete
				text: qsTr("Ok")
				size: HmiGui.Big
				shape: HmiGui.Flat
				onClicked: {
					progressTimer.start()
					if (action == "delete_single") {
						deleteBackground(selectedBackgroundPath)
					} else {
						manageBackgrounds(action)
					}
				}
			}

			TextPushButton {
				id: noBtn
				anchors.top: questionTextLabel.bottom
				anchors.topMargin: 80
				anchors.right: parent.right
				anchors.rightMargin: 20
				visible: !progressTimer.running && !operationComplete
				text: "No"
				size: HmiGui.Big
				shape: HmiGui.Flat
				onClicked: {
					progressTimer.stop()
					pendingAction = false
				}
			}
			
			TextPushButton {
				id: closeBtn
				anchors.top: questionTextLabel.bottom
				anchors.topMargin: 80
				anchors.horizontalCenter: questionTextLabel.horizontalCenter
				visible: progressTimer.running || operationComplete
				active: operationComplete
				text: operationComplete ? "Close" : "Please wait..."
				size: HmiGui.Big
				shape: HmiGui.Flat
				onClicked: {
					progressTimer.stop()
					pendingAction = false
					operationComplete = false
					action = ""
				}
			}
		}
	}

	QuestionDialogBase {
		id: managePopup
		popupSize: HmiGui.Regular
		buttonSpacing: UiTheme.styleRoot.generalMarginBig
		visible: showManagePopup

		questionContents: Rectangle {
			color: "transparent"
			anchors.top: parent.top
			anchors.topMargin: -100
			anchors.horizontalCenter: parent.horizontalCenter
			width: managePopup.definedSize.width
			height: managePopup.definedSize.height

			TextLabel {
				id: manageQuestionLabel
				anchors.top: parent.top
				anchors.horizontalCenter: parent.horizontalCenter
				width: parent.width
				horizontalAlignment: Text.AlignHCenter
				text: "Manage custom backgrounds"
			}

			TextPushButton {
				id: addBtn
				anchors.top: manageQuestionLabel.bottom
				anchors.topMargin: 50
				anchors.left: parent.left
				anchors.leftMargin: 50
				text: "Add"
				size: HmiGui.Big
				shape: HmiGui.Flat
				onClicked: {
					showManagePopup = false
					questionTextLabel.text = "Add new backgrounds?"
					action = "add"
					pendingAction = true
				}
			}

			TextPushButton {
				id: deleteBtn
				anchors.top: manageQuestionLabel.bottom
				anchors.topMargin: 50
				anchors.right: parent.right
				anchors.rightMargin: 50
				text: "Delete"
				size: HmiGui.Big
				shape: HmiGui.Flat
				onClicked: {
					showManagePopup = false
					questionTextLabel.text = "Delete all custom backgrounds?"
					action = "delete"
					pendingAction = true
				}
			}

			TextPushButton {
				id: cancelBtn
				anchors.top: addBtn.bottom
				anchors.topMargin: 40
				anchors.horizontalCenter: parent.horizontalCenter
				text: "Cancel"
				size: HmiGui.Big
				shape: HmiGui.Flat
				onClicked: {
					showManagePopup = false
				}
			}
		}
	}

	Timer {
		id: progressTimer
		interval: 50
		repeat: true

		onTriggered: {
			updateProgressText()

			if (checkIfOperationComplete()) {
				stop()
				questionTextLabel.text = "Operation complete!"
				operationComplete = true
				reloadBackgroundGrid()
			}
		}
    }

    onShownChanged: {
       backgroundImage.source =  UiTheme.palette.image(UiTheme.palette.viewBackground);
    }

    topAreaContent: [
        TextPushButton {
            id: manageBackgroundsButton

			anchors.right: switchTextLabel.left
            anchors.rightMargin: 50
			anchors.verticalCenter: parent.verticalCenter

			size: HmiGui.Small
			shape: HmiGui.Rectangular
			showBackground: false
            active: !pendingAction && !showManagePopup

            text: "Manage"

            onClicked: {
				showManagePopup = true
			}
        },

        OnOffSwitch {
            id: alternativePreviewSwitch
            objectName: "BackgroundSettings_alternativePreviewSwitch"

            anchors.right: parent.right
            anchors.top: parent.top
            anchors.topMargin: isCallActive ? 65 : UiTheme.styleRoot.generalMarginSmall

            anchors.rightMargin: UiTheme.styleRoot.generalMarginMedium

            property bool showingNight: checked ? AL2HMIBridge.globalSource.dayMode : !AL2HMIBridge.globalSource.dayMode
            onToggled: checked = checking
            LayoutMirroring.enabled: ViewController.rightToLeftLanguageActive
			active: !pendingAction && !showManagePopup
        },

        TextLabel {
            id: switchTextLabel
            objectName: "BackgroundSettings_switchTextLabel"

            anchors.right: alternativePreviewSwitch.left
            anchors.verticalCenter: alternativePreviewSwitch.verticalCenter
            anchors.margins: UiTheme.styleRoot.generalMarginMedium
            //~ GroupID Settings/backgroundsettings-0001
            //~ TextID 65026948-5f20-11e8-9b8a-08002718b8d7
            text: alternativePreviewSwitch.showingNight ? qsTr("Preview Day") :
                                                          //~ GroupID Settings/backgroundsettings-0001
                                                          //~ TextID 65026949-5f20-11e8-9b8a-08002718b8d7
                                                          qsTr("Preview Night")
            LayoutMirroring.enabled: ViewController.rightToLeftLanguageActive
        }
    ]

    content: HmiPagedGrid {
        id: backgroundGrid
        objectName: "BackgroundSettings_backgroundGrid"

        anchors.fill: parent
        orientation: ListView.Vertical

        grid.rows: 5
        grid.columns: 3

        grid.cellWidth: 211
        grid.cellHeight: 170

        grid.pageHeight: parent.height - pager.height

        grid.pageSpacing: -28

        delegate: ButtonBase {
            id: delegateButton
            objectName: "BackgroundSettings_delegateButton"

            HmiImage {
                id: delegateImage
                objectName: "BackgroundSettings_delegateImage"

                anchors.fill: parent
                anchors.margins: UiTheme.styleRoot.generalMarginMedium
                source: backgroundFilePath

                sourceSize: Qt.size(parent.width, parent.height)
            }

            isSelected: UiTheme.palette.fullPathFromImageUrl(UiTheme.palette.viewBackground) === backgroundFilePath

            onClicked: {
                backgroundImage.source = backgroundFilePath;

                if (alternativePreviewSwitch.showingNight) {
                    AL2HMIBridge.globalSource.nightBackground = backgroundFilePath;
                    AL2HMIBridge.globalSource.nightBackgroundTheme = UiTheme.currentThemeName
                } else {
                    AL2HMIBridge.globalSource.dayBackground = backgroundFilePath;
                    AL2HMIBridge.globalSource.dayBackgroundTheme = UiTheme.currentThemeName
                }
            }
			
			onPressAndHold: {
				popupMainText.text = "Removing Background...\nPlease wait..."
				confirmationPopup.cancelButtonText = qsTr("Please wait...");
				confirmationPopup.popupVisible = true
				progressTimer.start()
				deleteBackground(backgroundFilePath)
			}

            size: HmiGui.Bigger
            shape: HmiGui.Square
            variation: HmiGui.TileButtonVariation

        }

        model: BackgroundCollectionModel {
			id: backgroundModel
            night: alternativePreviewSwitch.showingNight
        }
    }

    function manageBackgrounds(action) {
        var xhr = new XMLHttpRequest();
		if (action == "add") {
			var loaderStatus = "/fs/mp/scripts/fmods/custom_backgrounds_loader.sh add";
		} else if (action == "delete") {
			var loaderStatus = "/fs/mp/scripts/fmods/custom_backgrounds_loader.sh delete";
		}
		xhr.open("PUT", "file:///fs/tmpfs/commands", false);
		xhr.send(loaderStatus);
	}

	function deleteBackground(filePath) {
		var xhr = new XMLHttpRequest();
		var deleteCommand = "/fs/mp/scripts/fmods/custom_backgrounds_loader.sh delete_single " + filePath;
		xhr.open("PUT", "file:///fs/tmpfs/commands", false);
		xhr.send(deleteCommand);
	}

	function updateProgressText() {
		var xhr = new XMLHttpRequest();
		xhr.open("GET", "file:///fs/tmpfs/background_operation_progress", false);
		try {
			xhr.send();
			if (xhr.status === 200 && xhr.responseText.length > 0) {
				questionTextLabel.text = xhr.responseText.trim();
			}
		} catch(e) {
		}
	}

	function checkIfOperationComplete() {
		var xhr = new XMLHttpRequest();
		xhr.open("GET", "file:///fs/tmpfs/background_operation_complete", false);
		try {
			xhr.send();

			if ((xhr.status === 200 || xhr.status === 0) && xhr.responseText.length > 0) {
				var xhrDelete = new XMLHttpRequest();
				xhrDelete.open("PUT", "file:///fs/tmpfs/commands", false);
				xhrDelete.send("rm -f /fs/tmpfs/background_operation_complete /fs/tmpfs/background_operation_progress");
				return true;
			}
		} catch(e) {

		}
		return false;
	}

	function reloadBackgroundGrid() {
		backgroundGrid.model = Qt.createQmlObject(
			'import QtQuick 2.0; import PasaHmiExtension 1.0; BackgroundCollectionModel { }',
			root,
			"backgroundModelReload"
		);

		backgroundGrid.model.night = Qt.binding(function() { return alternativePreviewSwitch.showingNight; });
    }
}
