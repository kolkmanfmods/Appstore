import QtQuick 2.0
import HmiGuiFramework.Controls 1.0
import HmiGui 1.0

import Hmi.Ford.ButtonGrids 1.0
import Hmi.Ford.Controls 1.0
import Hmi.Ford.Views 1.0

import PasaHmiExtension 1.0
import "../settings-utils.js" as Utils

import HmiPhone 1.0
import "../../hmiphone/phone-utils.js" as PhoneUtils
import AL2HMIBridge 1.0 as AL2HMIBridge

BackButtonTopScreenView {
    id: root
    objectName: "BackgroundSettings"

    property bool isCallActive : PhoneUtils.statusIsInPhoneCall(_hmiphoneController.phoneSource.status)

//~ TextID 38488a79-e6f6-11e7-af74-08002718b8d7
    titleText: qsTr("Background")
    alignContentToParentTop: false

    HmiImage {
        id: backgroundImage
        objectName: "BackgroundSettings_backgroundImage"
        source: UiTheme.palette.image(UiTheme.palette.viewBackground)

        // So the back button will be visible on top of the image.
        z: -1
    }

    onShownChanged: {
       backgroundImage.source =  UiTheme.palette.image(UiTheme.palette.viewBackground);
    }

    topAreaContent: [
        OnOffSwitch {
            id: alternativePreviewSwitch
            objectName: "BackgroundSettings_alternativePreviewSwitch"

            anchors.right: parent.right
            anchors.top: parent.top
            anchors.topMargin: isCallActive ? 65 : UiTheme.styleRoot.generalMarginSmall

            anchors.rightMargin: UiTheme.styleRoot.generalMarginMedium

            property bool showingNight: checked ? AL2HMIBridge.globalSource.dayMode : !AL2HMIBridge.globalSource.dayMode
            onToggled: checked = checking
            LayoutMirroring.enabled: ViewController.rightToLeftLanguageActive
        },

        TextLabel {
            id: switchTextLabel
            objectName: "BackgroundSettings_switchTextLabel"

            anchors.right: alternativePreviewSwitch.left
            anchors.verticalCenter: alternativePreviewSwitch.verticalCenter
            anchors.margins: UiTheme.styleRoot.generalMarginMedium
            //~ GroupID Settings/backgroundsettings-0001
            //~ TextID 65026948-5f20-11e8-9b8a-08002718b8d7
            text: alternativePreviewSwitch.showingNight ? qsTr("Preview Day") :
                                                          //~ GroupID Settings/backgroundsettings-0001
                                                          //~ TextID 65026949-5f20-11e8-9b8a-08002718b8d7
                                                          qsTr("Preview Night")
            LayoutMirroring.enabled: ViewController.rightToLeftLanguageActive
        }
    ]

    content: HmiPagedGrid {
        id: backgroundGrid
        objectName: "BackgroundSettings_backgroundGrid"

        anchors.fill: parent
        orientation: ListView.Vertical

        grid.rows: 5
        grid.columns: 3

        grid.cellWidth: 211
        grid.cellHeight: 170

        grid.pageHeight: parent.height - pager.height

        grid.pageSpacing: -28

        delegate: ButtonBase {
            id: delegateButton
            objectName: "BackgroundSettings_delegateButton"

            HmiImage {
                id: delegateImage
                objectName: "BackgroundSettings_delegateImage"

                anchors.fill: parent
                anchors.margins: UiTheme.styleRoot.generalMarginMedium
                source: backgroundFilePath

                sourceSize: Qt.size(parent.width, parent.height)
            }

            isSelected: UiTheme.palette.fullPathFromImageUrl(UiTheme.palette.viewBackground) === backgroundFilePath

            onClicked: {
                backgroundImage.source = backgroundFilePath;

                if (alternativePreviewSwitch.showingNight) {
                    AL2HMIBridge.globalSource.nightBackground = backgroundFilePath;
                    AL2HMIBridge.globalSource.nightBackgroundTheme = UiTheme.currentThemeName
                } else {
                    AL2HMIBridge.globalSource.dayBackground = backgroundFilePath;
                    AL2HMIBridge.globalSource.dayBackgroundTheme = UiTheme.currentThemeName
                }
            }

            size: HmiGui.Bigger
            shape: HmiGui.Square
            variation: HmiGui.TileButtonVariation

        }

        model: BackgroundCollectionModel {
            night: alternativePreviewSwitch.showingNight
        }
    }
}
