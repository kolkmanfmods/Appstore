import QtQuick 2.0
import HmiGuiFramework.Controls 1.0
import HmiGui 1.0

import Hmi.Ford.ButtonGrids 1.0
import Hmi.Ford.Controls 1.0
import Hmi.Ford.Views 1.0

import PasaHmiExtension 1.0
import "../settings-utils.js" as Utils
import AL2HMIBridge 1.0 as AL2HMIBridge

BackButtonTopScreenView {
    id: root
    objectName: "BackgroundSettings"

    //Use a space to hack an empty title. There is UI that is causing overlap if a title is added
//~ TextID 38488a79-e6f6-11e7-af74-08002718b8d7
    titleText: qsTr("Background")
    alignContentToParentTop: false

    HmiImage {
        id: backgroundImage
        objectName: "BackgroundSettings_backgroundImage"
        source: UiTheme.palette.image(UiTheme.palette.viewBackground)

        // So the back button will be visible on top of the image.
        z: -1
    }

    onShownChanged: {
       backgroundImage.source =  UiTheme.palette.image(UiTheme.palette.viewBackground);
    }
    customTitleComponentArea: [
        OnOffSwitch {
            id: alternativePreviewSwitch
            objectName: "BackgroundSettings_alternativePreviewSwitch"

            anchors.right: ViewController.rightToLeftLanguageActive ? switchTextLabel.left : parent.right
            anchors.top: parent.top
            anchors.topMargin: UiTheme.styleRoot.generalMarginSmall

            anchors.rightMargin: UiTheme.styleRoot.generalMarginMedium

            property bool showingNight: checked ? AL2HMIBridge.globalSource.dayMode : !AL2HMIBridge.globalSource.dayMode
            onToggled: checked = checking
        },

        TextLabel {
            id: switchTextLabel
            objectName: "BackgroundSettings_switchTextLabel"

            anchors.right: ViewController.rightToLeftLanguageActive ? parent.right : alternativePreviewSwitch.left
            anchors.verticalCenter: alternativePreviewSwitch.verticalCenter
            anchors.margins: UiTheme.styleRoot.generalMarginMedium
            //~ GroupID Settings/backgroundsettings-0001
            //~ TextID 65026948-5f20-11e8-9b8a-08002718b8d7
            text: alternativePreviewSwitch.showingNight ? qsTr("Preview Day") :
                                                          //~ GroupID Settings/backgroundsettings-0001
                                                          //~ TextID 65026949-5f20-11e8-9b8a-08002718b8d7
                                                          qsTr("Preview Night")
        }
    ]
    content: HmiPagedGrid {
        id: backgroundGrid
        objectName: "BackgroundSettings_backgroundGrid"

        anchors.fill: parent

        delegate: ButtonBase {
            id: delegateButton
            objectName: "BackgroundSettings_delegateButton"

            HmiImage {
                id: delegateImage
                objectName: "BackgroundSettings_delegateImage"

                anchors.fill: parent
                anchors.margins: UiTheme.styleRoot.generalMarginMedium
                source: backgroundFilePath
                sourceSize: Qt.size(parent.width, parent.height)
            }

            isSelected: UiTheme.palette.fullPathFromImageUrl(UiTheme.palette.viewBackground) === backgroundFilePath

            onClicked: {
                backgroundImage.source = backgroundFilePath;

                if (alternativePreviewSwitch.showingNight) {
                    AL2HMIBridge.globalSource.nightBackground = backgroundFilePath;
                    AL2HMIBridge.globalSource.nightBackgroundTheme = UiTheme.currentThemeName
                } else {
                    AL2HMIBridge.globalSource.dayBackground = backgroundFilePath;
                    AL2HMIBridge.globalSource.dayBackgroundTheme = UiTheme.currentThemeName
                }
            }
            size: HmiGui.Bigger
            shape: HmiGui.Square
        }

        model: BackgroundCollectionModel {
            night: alternativePreviewSwitch.showingNight
        }
    }
}
