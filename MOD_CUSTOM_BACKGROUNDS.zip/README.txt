//***********************************************************************************************************************************************************************//
//*                                                                                                                                                                 	*//
//*                 AAA                                TTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEE               AAA               MMMMMMMM               MMMMMMMM	*//
//*                A:::A                               T:::::::::::::::::::::TE::::::::::::::::::::E              A:::A              M:::::::M             M:::::::M	*//
//*               A:::::A                              T:::::::::::::::::::::TE::::::::::::::::::::E             A:::::A             M::::::::M           M::::::::M	*//
//*              A:::::::A                             T:::::TT:::::::TT:::::TEE::::::EEEEEEEEE::::E            A:::::::A            M:::::::::M         M:::::::::M	*//
//*             A:::::::::A                            TTTTTT  T:::::T  TTTTTT  E:::::E       EEEEEE           A:::::::::A           M::::::::::M       M::::::::::M	*//
//*            A:::::A:::::A                                   T:::::T          E:::::E                       A:::::A:::::A          M:::::::::::M     M:::::::::::M	*//
//*           A:::::A A:::::A                                  T:::::T          E::::::EEEEEEEEEE            A:::::A A:::::A         M:::::::M::::M   M::::M:::::::M	*//
//*          A:::::A   A:::::A         ---------------         T:::::T          E:::::::::::::::E           A:::::A   A:::::A        M::::::M M::::M M::::M M::::::M	*//
//*         A:::::A     A:::::A        -:::::::::::::-         T:::::T          E:::::::::::::::E          A:::::A     A:::::A       M::::::M  M::::M::::M  M::::::M	*//
//*        A:::::AAAAAAAAA:::::A       ---------------         T:::::T          E::::::EEEEEEEEEE         A:::::AAAAAAAAA:::::A      M::::::M   M:::::::M   M::::::M	*//
//*       A:::::::::::::::::::::A                              T:::::T          E:::::E                  A:::::::::::::::::::::A     M::::::M    M:::::M    M::::::M	*//
//*      A:::::AAAAAAAAAAAAA:::::A                             T:::::T          E:::::E       EEEEEE    A:::::AAAAAAAAAAAAA:::::A    M::::::M     MMMMM     M::::::M	*//
//*     A:::::A             A:::::A                          TT:::::::TT      EE::::::EEEEEEEE:::::E   A:::::A             A:::::A   M::::::M               M::::::M	*//
//*    A:::::A               A:::::A                         T:::::::::T      E::::::::::::::::::::E  A:::::A               A:::::A  M::::::M               M::::::M	*//
//*   A:::::A                 A:::::A                        T:::::::::T      E::::::::::::::::::::E A:::::A                 A:::::A M::::::M               M::::::M	*//
//*  AAAAAAA                   AAAAAAA                       TTTTTTTTTTT      EEEEEEEEEEEEEEEEEEEEEEAAAAAAA                   AAAAAAAMMMMMMMM               MMMMMMMM	*//
//*                                                                                                                                                                 	*//
//***********************************************************************************************************************************************************************//
//********************************************************** SYNC 3 CUSTOM BACKGROUNDS LOADER for SYNC 3.4 **************************************************************//
//*																											     	                                                    *//
//* Developed by Au{R}oN																							     	                                            *//
//*																											     	                                                    *//
//* www.fmods.net																									     	                                            *//
//*																											     	                                                    *//
//*************************************************************************** HOW TO USE ********************************************************************************//
//*																											     	                                                    *//
//*	This mod adds a custom backgrounds loader through a built-in Daemon that silently run on the SYNC 3.										                        *//
//*	Once installed it allows to add / delete custom backgrounds through two dedicated buttons inside the OEM Backgrounds settings page.						            *//
//* Use the "Add" button to load new backgrounds and use the "Delete" button to remove all custom backgrounds. 	   									                    *//
//*	USB Stick structure must be the following: "customerBackgrounds" folder and "day" and "night" subfolders with the all the images inside.				            *//
//*	DO NOT USE space and special characters for the images filename.											  						                                *//
//*																												                                                        *//
//*	If the USB structure is correct, the script will search for images, copy them in the system folders and automatically generate the correct json file.			    *//
//*	customerBackgrounds folder is a special folder that it's not present in an 'OEM' Sync, but the system still look for it. If it's there, the json files. 	   	    *//
//*	located in the "day" and "night" subfolder will be parsed BEFORE the theme json files and this allow to add additional backgrounds without editing any system file. *//
//*																												                                                        *//
//*	NB:																											                                                        *//
//* 1) PLEASE NOTE THAT THE MOD IS LOADED AT THE END OF THE SYNC 3 BOOT PROCEDURE, FOR THAT REASON IT MAY TAKE UP TO ONE MINUTE TO START. 	  					        *//
//* 2) AT THE MOMENT, IT LOOKS ONLY FOR THE FIRST USB DEVICE PLUGGED. IF YOU HAVE AN USB PENDRIVE ALREADY PLUGGED IN AND THEN INSERT THE SECOND USB  	   			    *//
//* PENDRIVE WITH THE IMAGES, NOTHING HAPPENS.																					                                        *//
//*																												                                                        *//
//***********************************************************************************************************************************************************************//
//*																												                                                        *//
//***************************************************************************** CHANGELOG *******************************************************************************//
//* ## v1.0 - 2017-12-28 																								                                                *//
//* - Initial Release, rely on "day" / "night" backgrounds theme folders.																                                *//
//* 																												                                                    *//
//* ## v2.0 - 2018-09-25 																								                                                *//
//* - Dropped theme's "day" / "night" folders usage.																				                                    *//
//*   This new version use the fordhmi customerBackgrounds folder, that if present, has higher priority than the one in the theme folder (theme's JSON is still parsed 	*//
//*   but AFTER).                                                                                                                                                       *//
//*   Thanks to this new version it's no longer required to edit the OEM json files. Just add a new json (one for "day" folder, and one for "night" folder)            	*//
//*   Tested only on version 3.4, i don't know if versions 3.2 and 3.3 support the customerBackgrounds folder.                                                         	*//
//*                                                                                                                                                                    	*//
//* ## v2.1 - 2020-09-14 																								                                                *//
//* -  .json file inside "day" and "night" folder is no longer required. The mod generate it on the fly everytime you add / remove new images. 					        *//
//* -  Thanks for NorMen for his bash skills.																					                                        *//
//* 																												                                                    *//
//* ## v2.2 - 2021-04-09																								                                                *//
//* - Installation script updated for new Mods Tools.										   										                                    *//
//* 																												                                                    *//
//* ## v2.3 - 2021-10-19																								                                                *//
//* - Loader script updated to use "Mods Tools" set RW / RO scripts.									   							                                    *//
//* 																												                                                    *//
//* ## v3.0 - 2021-10-26																								                                                *//
//* - Mod completely rewritten to support add / delete of new backgrounds directly from SYNC 3 UI (dropped support for SYNC 3 version 3.2 and 3.3)				        *//
//*   Lincoln Theme and 10.1" Themes are not yet supporter by this new version. Use version 2.3 if you have such themes.									            *//
//*   New Buttons are located in the Backgrounds Settings page. Use the "Add" button to load new backgrounds and use "Delete" button to remove all custom backgrounds  	*//
//* - Reboot is no longer required after a load / delete action	(EXPERIMENTAL FEATURE, TEST AND REPORT BACK!!).										                    *//
//* 																												                                                    *//
//* ## v3.1 - 2021-10-27																								                                                *//
//* - Added support for 10.1" themes.                                                                                                                                   *//
//*                                                                                                                                                                    	*//
//* ## v3.2 - 2021-11-03																								                                                *//
//* - Now when you add new backgrounds you will not lose existing ones anymore.                                                                                        	*//
//* 																												                                                    *//
//* ## v3.3 - 2021-11-15																								                                                *//
//* - Changed script's logic to allow use of the Add button when there no USB stick inserted in. This is usefull when custom themes install bg in the				    *//
//*   customerBackgrounds folder. Put your 800x480 .jpg's in the subfolders day and night (lowercase).												                    *//
//* 																												                                                    *//
//* ## v3.4 - 2024-06-02																								                                                *//
//* - Adjusted to support FMods Tools 2.9 and added an uninstall script.				                                                                                *//
//* 																												                                                    *//
//* ## v4.0 - 2025-12-07                                                                                                                                                *//
//* This version requires FMods Tools 3.0                                                                                                                               *//
//* - Removed infinite loop script.                                                                                                                                     *//
//* - Removed theme reload. Backgrounds list is now updated on the fly.                                                                                                 *//
//* - Added real-time copy progression.                                                                                                                                 *//
//* - Added single background delete (press and hold the desired background to delete it)                                                                               *//
//* - Improved QML code                                                                                                                                                 *//
//* - Improved script performance.                                                                                                                                      *//
//* - Created symlink to avoid OS partition usage.                                                                                                                      *//
//* 																												                                                    *//
//***********************************************************************************************************************************************************************//
