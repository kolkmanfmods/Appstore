//***********************************************************************************************************************************************************************//
//*																																										*//
//*					AAA								   TTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEE			   AAA				 MMMMMMMM				MMMMMMMM	*//
//*				   A:::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			  A:::A				 M:::::::M			   M:::::::M	*//
//*				  A:::::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			 A:::::A			 M::::::::M			  M::::::::M	*//
//*				 A:::::::A							   T:::::TT:::::::TT:::::TEE::::::EEEEEEEEE::::E			A:::::::A			 M:::::::::M		 M:::::::::M	*//
//*				A:::::::::A							   TTTTTT  T:::::T  TTTTTT  E:::::E		  EEEEEE		   A:::::::::A			 M::::::::::M		M::::::::::M	*//
//*			   A:::::A:::::A								   T:::::T			E:::::E			 			  A:::::A:::::A			 M:::::::::::M	   M:::::::::::M	*//
//*			  A:::::A A:::::A								   T:::::T			E::::::EEEEEEEEEE			 A:::::A A:::::A		 M:::::::M::::M   M::::M:::::::M	*//
//*			 A:::::A   A:::::A		   ---------------		   T:::::T			E:::::::::::::::E			A:::::A   A:::::A		 M::::::M M::::M M::::M M::::::M	*//
//*			A:::::A		A:::::A		   -:::::::::::::-		   T:::::T			E:::::::::::::::E		   A:::::A	   A:::::A		 M::::::M  M::::M::::M  M::::::M	*//
//*		   A:::::AAAAAAAAA:::::A	   ---------------		   T:::::T			E::::::EEEEEEEEEE		  A:::::AAAAAAAAA:::::A		 M::::::M   M:::::::M   M::::::M	*//
//*		  A:::::::::::::::::::::A							   T:::::T			E:::::E			 		 A:::::::::::::::::::::A	 M::::::M	 M:::::M	M::::::M	*//
//*		 A:::::AAAAAAAAAAAAA:::::A							   T:::::T			E:::::E		  EEEEEE	A:::::AAAAAAAAAAAAA:::::A	 M::::::M	  MMMMM		M::::::M	*//
//*		A:::::A				A:::::A							 TT:::::::TT	  EE::::::EEEEEEEE:::::E   A:::::A			   A:::::A   M::::::M				M::::::M	*//
//*	   A:::::A				 A:::::A						 T:::::::::T	  E::::::::::::::::::::E  A:::::A				A:::::A  M::::::M				M::::::M	*//
//*	  A:::::A				  A:::::A						 T:::::::::T	  E::::::::::::::::::::E A:::::A				 A:::::A M::::::M				M::::::M	*//
//*	 AAAAAAA				   AAAAAAA						 TTTTTTTTTTT	  EEEEEEEEEEEEEEEEEEEEEEAAAAAAA					 AAAAAAAMMMMMMMM				MMMMMMMM	*//
//*																																										*//
//***********************************************************************************************************************************************************************//
//*																																										*//
//*							 ###############																															*//
//*							#				#																															*//
//*						  #					 #					M			 M						 D			 														*//
//*				 #########	   FFFFFFFFFFF	  #########			MM			MM						 D			 														*//
//*						#	   FF			   #				M M		   M M   OOOOOOOO	DDDDDDD D   SSSSSSSS		   NN		N  EEEEEEEEEE  TTTTTTTTTT			*//
//*			############	   FF FFFF			############	M  M	  M  M  O		 O  D		 D  S				   N NN		N  EE			   TT				*//
//*						#	   FF			   #				M   M	 M   M  O		 O  D		 D   SSSSSSSS		   N   NN   N  EEEEEEEEEE	   TT				*//
//*				 #########	   FF			  #########			M	  M M	 M  O		 O  D		 D			 S   ###   N	 NN N  EE			   TT				*//
//*						  #	   FF			 #					M	   M	 M   OOOOOOOO	DDDDDDDD	 SSSSSSSS	 ###   N	   NN  EEEEEEEEEE	   TT				*//
//*						   #				#																															*//
//*							################																															*//
//*																																										*//
//******************************************************************************* MOD SETTINGS PAGE *********************************************************************//
//*																																										*// 
//* Developed by YuriB.																																					*//
//* This mod adds Mods Settings page to Sync Settings menu, replacing stock Automatic System Updates page (useless if your Sync is jailbroken) and serves as a 			*//
//* framework for mods that rely on custom settings.																													*//
//* 																																									*//
//* www.fmods.net																																						*//
//************************************************************************************* CHANGELOG ***********************************************************************//
//*																																										*//
//* ## v1.0 - 2022-07-23. 																																				*//
//* - Initial Release.																																					*//
//*																																										*//
//* ## v1.1 - 2026-07-12. 																																				*//
//* - Adjusted to support FMods Tools 3.3 and added (un)install.sh scripts. 																							*//
//* - The dependency check for Custom Apps Loader Mod is not needed anymore (it no longer patches Settings.qml). You can use the same master.patch file. 				*//																	*//
//*																																										*//
//***********************************************************************************************************************************************************************//