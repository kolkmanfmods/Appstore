#!/bin/sh
# shellcheck disable=SC2086 disable=SC3006 disable=SC3054
#########################################################################################################################################################################
#	Installation script for Mods Settings																																#
#########################################################################################################################################################################
#																																										#
#					AAA								   TTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEE			   AAA				 MMMMMMMM				MMMMMMMM	#
#				   A:::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			  A:::A				 M:::::::M			   M:::::::M	#
#				  A:::::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			 A:::::A			 M::::::::M			  M::::::::M	#
#				 A:::::::A							   T:::::TT:::::::TT:::::TEE::::::EEEEEEEEE::::E			A:::::::A			 M:::::::::M		 M:::::::::M	#
#				A:::::::::A							   TTTTTT  T:::::T  TTTTTT  E:::::E		  EEEEEE		   A:::::::::A			 M::::::::::M		M::::::::::M	#
#			   A:::::A:::::A								   T:::::T			E:::::E			 			  A:::::A:::::A			 M:::::::::::M	   M:::::::::::M	#
#			  A:::::A A:::::A								   T:::::T			E::::::EEEEEEEEEE			 A:::::A A:::::A		 M:::::::M::::M   M::::M:::::::M	#
#			 A:::::A   A:::::A		   ---------------		   T:::::T			E:::::::::::::::E			A:::::A   A:::::A		 M::::::M M::::M M::::M M::::::M	#
#			A:::::A		A:::::A		   -:::::::::::::-		   T:::::T			E:::::::::::::::E		   A:::::A	   A:::::A		 M::::::M  M::::M::::M  M::::::M	#
#		   A:::::AAAAAAAAA:::::A	   ---------------		   T:::::T			E::::::EEEEEEEEEE		  A:::::AAAAAAAAA:::::A		 M::::::M   M:::::::M   M::::::M	#
#		  A:::::::::::::::::::::A							   T:::::T			E:::::E			 		 A:::::::::::::::::::::A	 M::::::M	 M:::::M	M::::::M	#
#		 A:::::AAAAAAAAAAAAA:::::A							   T:::::T			E:::::E		  EEEEEE	A:::::AAAAAAAAAAAAA:::::A	 M::::::M	  MMMMM		M::::::M	#
#		A:::::A				A:::::A							 TT:::::::TT	  EE::::::EEEEEEEE:::::E   A:::::A			   A:::::A   M::::::M				M::::::M	#
#	   A:::::A				 A:::::A						 T:::::::::T	  E::::::::::::::::::::E  A:::::A				A:::::A  M::::::M				M::::::M	#
#	  A:::::A				  A:::::A						 T:::::::::T	  E::::::::::::::::::::E A:::::A				 A:::::A M::::::M				M::::::M	#
#	 AAAAAAA				   AAAAAAA						 TTTTTTTTTTT	  EEEEEEEEEEEEEEEEEEEEEEAAAAAAA					 AAAAAAAMMMMMMMM				MMMMMMMM	#
#																																										#
#########################################################################################################################################################################
#																																										#
#							 ###############																															#
#							#				#																															#
#						  #					 #					M			 M						 D			 														#
#				 #########	   FFFFFFFFFFF	  #########			MM			MM						 D			 														#
#						#	   FF			   #				M M		   M M   OOOOOOOO	DDDDDDD D   SSSSSSSS		   NN		N  EEEEEEEEEE  TTTTTTTTTT			#
#			############	   FF FFFF			############	M  M	  M  M  O		 O  D		 D  S				   N NN		N  EE			   TT				#
#						#	   FF			   #				M   M	 M   M  O		 O  D		 D   SSSSSSSS		   N   NN   N  EEEEEEEEEE	   TT				#
#				 #########	   FF			  #########			M	  M M	 M  O		 O  D		 D			 S   ###   N	 NN N  EE			   TT				#
#						  #	   FF			 #					M	   M	 M   OOOOOOOO	DDDDDDDD	 SSSSSSSS	 ###   N	   NN  EEEEEEEEEE	   TT				#
#						   #				#																															#
#							################																															#
#																																										#
#########################################################################################################################################################################

# Mod Name		: 	Mods Settings ( MODS_SETTINGS ).
# Author		: 	YuriB | www.fmods.net.
# Creation date : 	2022-07-23.
# Version		: 	1.1.
# Update date	: 	2024-06-05.
# Update notes	: 	Adjusted to support FMods Tools 2.9 and added an uninstall script.

#########################################################################################################################################################################
#	Install commands.																																					#
#########################################################################################################################################################################

MOD_NAME="MODS_SETTINGS"
PATH="/fs/rwdata/dev:${PATH}"
MODS_PATH="/fs/images/fmods_mods_data/"
SHORT="${MODS_PATH}/${MOD_NAME}"
PATCH=1
if [ "${PATCH;-0}" -eq 1 ]; then
	if ! patch -l --dry-run -p0 < 																	"${PATCH_DIR}/master.patch" > "${SHORT}/patch.log"; then
		MANUAL=1
	else
		patch -l -b -p0 < 																			"${PATCH_DIR}/master.patch"
	fi
fi
if [ "${PATCH:-0}" -eq 0 ] || [ "${MANUAL:-0}" -eq 1 ]; then
	if [ -f "${SHORT}/new/Settings.qml" ]; then
		cp "${SHORT}/new/Settings.qml"								 								"/fs/mp/fordhmi/qml/hmisettings/Settings.qml"
	fi
	if [ -f "${SHORT}/new/AutomaticSystemUpdates.qml" ]; then
		cp "${SHORT}/new/AutomaticSystemUpdates.qml"												"/fs/mp/fordhmi/qml/hmisettings/system-updates/AutomaticSystemUpdates.qml"
	fi
	if [ -f "${SHORT}/new/ModsClassicSettings.qml" ]; then
		cp "${SHORT}/new/ModsClassicSettings.qml"					 								"/fs/mp/fordhmi/qml/hmicustomapps/apps/YuriB/ModsClassicSettings/ModsClassicSettings.qml"
	fi
	if [ -f "${SHORT}/new/qmldir" ] && [ ! -f "/fs/rwdata/fmods/mods/modsSettings/qmldir" ] ; then
		mkdir -p "/fs/rwdata/fmods/mods/modsSettings"
		cp "${SHORT}/new/qmldir"																	"/fs/rwdata/fmods/mods/modsSettings/qmldir"
	fi
fi
