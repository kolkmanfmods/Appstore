#!/bin/sh
# shellcheck disable=SC2086 disable=SC3006 disable=SC3054
#########################################################################################################################################################################
#	Installation script for Mods Settings					  																											#
#########################################################################################################################################################################
#																																										#
#					AAA								   TTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEE			   AAA				 MMMMMMMM				MMMMMMMM	#
#				   A:::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			  A:::A				 M:::::::M			   M:::::::M	#
#				  A:::::A							   T:::::::::::::::::::::TE::::::::::::::::::::E			 A:::::A			 M::::::::M			  M::::::::M	#
#				 A:::::::A							   T:::::TT:::::::TT:::::TEE::::::EEEEEEEEE::::E			A:::::::A			 M:::::::::M		 M:::::::::M	#
#				A:::::::::A							   TTTTTT  T:::::T  TTTTTT  E:::::E		  EEEEEE		   A:::::::::A			 M::::::::::M		M::::::::::M	#
#			   A:::::A:::::A								   T:::::T			E:::::E			 			  A:::::A:::::A			 M:::::::::::M	   M:::::::::::M	#
#			  A:::::A A:::::A								   T:::::T			E::::::EEEEEEEEEE			 A:::::A A:::::A		 M:::::::M::::M   M::::M:::::::M	#
#			 A:::::A   A:::::A		   ---------------		   T:::::T			E:::::::::::::::E			A:::::A   A:::::A		 M::::::M M::::M M::::M M::::::M	#
#			A:::::A		A:::::A		   -:::::::::::::-		   T:::::T			E:::::::::::::::E		   A:::::A	   A:::::A		 M::::::M  M::::M::::M  M::::::M	#
#		   A:::::AAAAAAAAA:::::A	   ---------------		   T:::::T			E::::::EEEEEEEEEE		  A:::::AAAAAAAAA:::::A		 M::::::M   M:::::::M   M::::::M	#
#		  A:::::::::::::::::::::A							   T:::::T			E:::::E			 		 A:::::::::::::::::::::A	 M::::::M	 M:::::M	M::::::M	#
#		 A:::::AAAAAAAAAAAAA:::::A							   T:::::T			E:::::E		  EEEEEE	A:::::AAAAAAAAAAAAA:::::A	 M::::::M	  MMMMM		M::::::M	#
#		A:::::A				A:::::A							 TT:::::::TT	  EE::::::EEEEEEEE:::::E   A:::::A			   A:::::A   M::::::M				M::::::M	#
#	   A:::::A				 A:::::A						 T:::::::::T	  E::::::::::::::::::::E  A:::::A				A:::::A  M::::::M				M::::::M	#
#	  A:::::A				  A:::::A						 T:::::::::T	  E::::::::::::::::::::E A:::::A				 A:::::A M::::::M				M::::::M	#
#	 AAAAAAA				   AAAAAAA						 TTTTTTTTTTT	  EEEEEEEEEEEEEEEEEEEEEEAAAAAAA					 AAAAAAAMMMMMMMM				MMMMMMMM	#
#																																										#
#########################################################################################################################################################################
#																																										#
#							 ###############																															#
#							#				#																															#
#						  #					 #					M			 M						 D			 														#
#				 #########	   FFFFFFFFFFF	  #########			MM			MM						 D			 														#
#						#	   FF			   #				M M		   M M   OOOOOOOO	DDDDDDD D   SSSSSSSS		   NN		N  EEEEEEEEEE  TTTTTTTTTT			#
#			############	   FF FFFF			############	M  M	  M  M  O		 O  D		 D  S				   N NN		N  EE			   TT				#
#						#	   FF			   #				M   M	 M   M  O		 O  D		 D   SSSSSSSS		   N   NN   N  EEEEEEEEEE	   TT				#
#				 #########	   FF			  #########			M	  M M	 M  O		 O  D		 D			 S   ###   N	 NN N  EE			   TT				#
#						  #	   FF			 #					M	   M	 M   OOOOOOOO	DDDDDDDD	 SSSSSSSS	 ###   N	   NN  EEEEEEEEEE	   TT				#
#						   #				#																															#
#							################																															#
#																																										#
#########################################################################################################################################################################

# Mod Name	  : 	Mods Settings ( MODS_SETTINGS ).
# Author		: 	YuriB | www.fmods.net.
# Creation date : 	2022-07-23.
# Version	   : 	1.1.
# Update date   : 	2024-06-05.
# Update notes  : 	Adjusted to support FMods Tools 2.9 and added an uninstall script.

#########################################################################################################################################################################
#	Delete commands.																																					#
#########################################################################################################################################################################

MOD_NAME="MODS_SETTINGS"
PATH="/fs/rwdata/dev:${PATH}"
MODS_PATH="/fs/images/fmods_mods_data/"
# MODS_JSON_PATH="${MODS_PATH}/mods.json"
SHORT="${MODS_PATH}/${MOD_NAME}"
PATCH_DIR="${SHORT}/patch"
UNPATCH=1

# Remove also the dependencies from the installed_mods.txt and set the status to deleted for all Mods depending on this one to be installed first.
# DEPENDENCY1="RVC_SAFETY_REMOVER"
# DEPENDENCY1_PATH="${MODS_PATH}/${DEPENDENCY1}"
# sed -i -e "/${DEPENDENCY1}/d" 																	"/fs/mp/etc/installed_mods.txt"
# if [ -f "${DEPENDENCY1_PATH}/uninstall/uninstall.sh" ]; then
#	 chmod +x "${DEPENDENCY1_PATH}/uninstall/uninstall.sh"
#	 sh "${DEPENDENCY1_PATH}/uninstall/uninstall.sh"

#	 if grep -q "${DEPENDENCY1}" 																	"${MODS_JSON_PATH}"; then
#		 jq --arg modName "$DEPENDENCY1" '(.mods[] | select(.modName == $modName)).modUninstallFile = "deleted"' "${MODS_JSON_PATH}" > "/tmp/tmp.json"
#		 mv "/tmp/tmp.json" 																		"${MODS_JSON_PATH}"
#	 fi
# fi
if [ "${UNPATCH:-0}" -eq 1 ]; then
	if ! patch -l --dry-run -R -p0 < 																"${PATCH_DIR}/master.patch" > "${SHORT}/patch.log"; then
		MANUAL=1
	else
		patch -l -b -R -p0 < 																		"${PATCH_DIR}/master.patch"
	fi
fi
if [ "${UNPATCH:-0}" -eq 0 ] || [ "${MANUAL:-0}" -eq 1 ]; then
	if [ -f "${SHORT}/backup/Settings.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmisettings/"*
		rm -f "/fs/mp/fordhmi/qml/hmisettings/Settings.qml"
		cp "${SHORT}/backup/Settings.qml"								 							"/fs/mp/fordhmi/qml/hmisettings/Settings.qml"
	fi
	if [ -f "${SHORT}/backup/AutomaticSystemUpdates.qml" ]; then
		chmod a+x "/fs/mp/fordhmi/qml/hmisettings/system-updates/"*
		rm -f "/fs/mp/fordhmi/qml/hmisettings/system-updates/AutomaticSystemUpdates.qml"
		cp "${SHORT}/backup/AutomaticSystemUpdates.qml"				  								"/fs/mp/fordhmi/qml/hmisettings/system-updates/AutomaticSystemUpdates.qml"
	fi
fi

if ! grep -q "MODS_LINCOLN_SETTINGS" "/fs/mp/etc/installed_mods.txt" && ! grep -q "MODS_10L_SETTINGS" "/fs/mp/etc/installed_mods.txt" && ! grep -q "MODS_10P_SETTINGS" "/fs/mp/etc/installed_mods.txt"; then
	if [ -d "/fs/rwdata/fmods/mods/modsSettings" ]; then
		chmod a+x "/fs/rwdata/fmods/mods/modsSettings/"*
		rm -f "/fs/rwdata/fmods/mods/modsSettings/qmldir"
		rm -RF "/fs/rwdata/fmods/mods/modsSettings"
	fi
fi
