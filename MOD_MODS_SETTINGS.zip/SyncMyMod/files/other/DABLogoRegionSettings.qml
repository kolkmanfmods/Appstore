pragma Singleton
import QtQuick 2.0
QtObject {
    property int customDABLogoRegion:0
    property var regionDABNameArray: [

                { name: 'Region 1', folder: 'Region 1', valueId: 0},

                { name: 'Region 2', folder: 'Region 2', valueId: 1},

                { name: 'Region 3', folder: 'Region 3', valueId: 2}
            ]
}
