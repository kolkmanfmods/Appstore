import QtQuick 2.6
import HmiSettings 1.0
import HmiGuiFramework 1.0
import HmiGui 1.0
import HmiCore 1.0
import AL2HMIBridge 1.0

import Hmi.Ford 1.0
import Hmi.Ford.Views 1.0
import Hmi.Ford.ButtonGrids 1.0
import Hmi.Ford.Controls 1.0
import HmiGuiFramework.Styles 1.0
import "components"

// Ford HMI Spec H31a_View1

FordView {
    id: root
    objectName: "Settings"

    content: [
        HmiPagedGrid {
            id: gridItem_hmisettings
            objectName: "Settings_gridItem_hmisettings"

            anchors.fill: parent

            delegate: Component {
                GridDelegate {
                    id: gridDelegate_hmisettings
                    objectName: root.objectName + "_gridDelegate_" + (action ? action.icon : "NoName")

                    actionName: action ? (action.icon == "settings/icon_software_update" ? "Mods Settings" : action.name) : ""
                    iconName: action ? (action.icon == "settings/icon_software_update" ? "settings/icon_generalgear_alt" : action.icon) : ""
                    action: model ? model.action : null
                    driverRestrictedButton: action ? DrivingRestrictions.fromDriverRestrictionType(action.driverRestricted) : false
                    shown: root.shown
                    active: action ? action.enabled : false
                    alwaysAllowTouch: action ? action.allowDisabledUsage : false
                    isSelected: action ? action.selected : false
                    textElideMode: ViewController.rightToLeftLanguageActive ? Text.ElideLeft : Text.ElideRight
                    textWrapMode: Text.WrapAtWordBoundaryOrAnywhere
                    textMaximumLineCount: 2
                    iconComponent.visible: !animationLoader.active

                    Loader {
                        id: animationLoader
                        active: action ? action.animation : false
                        sourceComponent: iconAnimation
                        anchors.fill: gridDelegate_hmisettings.iconComponent
                    }
                }
            }

            model: _settingsSubmoduleHost.submoduleEntryActionModel
        }
    ]

    Component {
        id: iconAnimation
        LoadingIcon {
            anchors.fill: parent

            spinnerSize: HmiGui.SpinnerSmaller
            spinnerFrameCount: 45
            animationDuration: 3000
        }
    }
}
