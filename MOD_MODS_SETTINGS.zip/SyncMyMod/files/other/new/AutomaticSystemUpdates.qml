import QtQuick 2.6
import HmiSettings 1.0

import Hmi.Ford 1.0
import Hmi.Ford.Controls 1.0
import Hmi.Ford.Controls.Settings 1.0
import Hmi.Ford.Views 1.0
import "file:///fs/rwdata/fmods/mods/modsSettings"
import HmiGui 1.0
import HmiGuiFramework.Controls 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge

SettingsView {
    id: root
    objectName: "ModsSettings"

    viewTitle: qsTr("Mods Settings")

    function storeNewSetting(filename, propertyName, newvalue) {
        var xhr = new XMLHttpRequest();
        var text = ""
        var propertySearch = RegExp(propertyName + ".*")
        xhr.onreadystatechange = function() {
           if (xhr.readyState === 4) {
               text = xhr.responseText;
            }
        }
        xhr.open("GET", "file:///fs/rwdata/fmods/mods/modsSettings/" + filename, false);
        xhr.send();
        var xhr2 = new XMLHttpRequest();
        text = text.replace(propertySearch, propertyName+newvalue);
        xhr2.open("PUT", "file:///fs/rwdata/fmods/mods/modsSettings/" + filename, false);
        xhr2.send(text);
    }

    scrollableAreaContent: [

//ADD SETTINGS ENTRY BELOW THIS LINE








        Rectangle {
            width: 0
            height: 0
            color: "transparent"
        }
    ]
}
