import QtQuick 2.6
import QtQuick.Layouts 1.0
import QtQuick.Controls 1.2
import Hmi.Ford 1.0
import Hmi.Ford.Controls 1.0
import Hmi.Ford.Controls.Settings 1.0
import Hmi.Ford.Views 1.0
import HmiGui 1.0
import HmiGuiFramework.Controls 1.0
import HmiSettings 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge
import "file:///fs/rwdata/fmods/mods/modsSettings"

Rectangle {
    width: 800
    height: 430
    anchors.top: parent.top
    anchors.topMargin: 50
    color: "transparent"

    function storeNewSetting(filename, propertyName, newvalue) {
        var xhr = new XMLHttpRequest();
        var text = ""
        var propertySearch = RegExp(propertyName + ".*")
        xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            text = xhr.responseText;
            }
        }
        xhr.open("GET", "file:///fs/rwdata/fmods/mods/modsSettings/" + filename, false);
        xhr.send();
        var xhr2 = new XMLHttpRequest();
        text = text.replace(propertySearch, propertyName+newvalue);
        xhr2.open("PUT", "file:///fs/rwdata/fmods/mods/modsSettings/" + filename, false);
        xhr2.send(text);
    }

    // ScrollView {
    //     id: view
    //     anchors.top: parent.top
    //     anchors.bottom: parent.bottom
    //     anchors.left: parent.left
    //     anchors.right: parent.right
    //     anchors.topMargin: 10
    //     anchors.leftMargin: 10
    //     anchors.rightMargin: 10
    //     anchors.bottomMargin: 10
    //     width: 780
    //     height: 410

//ADD SETTINGS ENTRY BELOW THIS LINE
//AM LOGO REGION SETTINGS START
    LabelComboBox {
        id: customAMLogoRegionSettings
        objectName: "LogoMod_customAMLogoRegion"

        property string qmlName: "AMLogoRegionSettings.qml"
        property string propertyName: "customAMLogoRegion:"
        property var __comboBoxModel: AMLogoRegionSettings.regionAMNameArray

        label: qsTr("Custom AM logo region")
        comboBoxModel: __comboBoxModel
        comboBoxModelTextProperty: "name"
        onComboboxItemActivated: {
            AMLogoRegionSettings.customAMLogoRegion = __comboBoxModel[currentIndex].valueId
            storeNewSetting(qmlName, propertyName, __comboBoxModel[currentIndex].valueId)
        }
        modelValueProperty: "valueId"
        initialSourceValue: AMLogoRegionSettings.customAMLogoRegion

        moreInfoTitle: qsTr("Custom AM logo region","TinfoTitle")
        moreInfoText: qsTr("Allows you to choose between three sets of logos depending on the region you currently traveling in. Logos must be placed in relative folders during installation")
    }
//AM LOGO REGION SETTINGS FINISH
//DAB LOGO REGION SETTINGS START
    LabelComboBox {
        id: customDABLogoRegionSettings
        objectName: "LogoMod_customDABLogoRegion"
        anchors.top: customAMLogoRegionSettings.bottom
        anchors.topMargin: 5

        property string qmlName: "DABLogoRegionSettings.qml"
        property string propertyName: "customDABLogoRegion:"
        property var __comboBoxModel: DABLogoRegionSettings.regionDABNameArray

        label: qsTr("Custom DAB logo region")
        comboBoxModel: __comboBoxModel
        comboBoxModelTextProperty: "name"
        onComboboxItemActivated: {
            DABLogoRegionSettings.customDABLogoRegion = __comboBoxModel[currentIndex].valueId
            storeNewSetting(qmlName, propertyName, __comboBoxModel[currentIndex].valueId)
        }
        modelValueProperty: "valueId"
        initialSourceValue: DABLogoRegionSettings.customDABLogoRegion

        moreInfoTitle: qsTr("Custom DAB logo region","TinfoTitle")
        moreInfoText: qsTr("Allows you to choose between three sets of logos depending on the region you currently traveling in. Logos must be placed in relative folders during installation")
    }
//DAB LOGO REGION SETTINGS FINISH
//FM LOGO REGION SETTINGS START
    LabelComboBox {
        id: customLogoRegionSettings
        objectName: "FmLogoMod_customLogoRegion"
        anchors.top: customDABLogoRegionSettings.bottom
        anchors.topMargin: 5

        property string qmlName: "FMLogoRegionSettings.qml"
        property string propertyName: "customLogoRegion:"
        property var __comboBoxModel: FMLogoRegionSettings.regionNameArray

        label: qsTr("Custom FM logo region")
        comboBoxModel: __comboBoxModel
        comboBoxModelTextProperty: "name"
        onComboboxItemActivated: {
            FMLogoRegionSettings.customLogoRegion = __comboBoxModel[currentIndex].valueId
            storeNewSetting(qmlName, propertyName, __comboBoxModel[currentIndex].valueId)
        }
        modelValueProperty: "valueId"
        initialSourceValue: FMLogoRegionSettings.customLogoRegion

        moreInfoTitle: qsTr("Custom FM logo region","TinfoTitle")
        moreInfoText: qsTr("Allows you to choose between three sets of logos depending on the region you currently traveling in. Logos must be placed in relative folders during installation")
    }
//FM LOGO REGION SETTINGS FINISH
//PROJECTION WIDGET SETTINGS START
    LabelComboBox {
        id: projectionWidgetEnabled
        objectName: "projectionWidgetEnabled"
        anchors.top: customLogoRegionSettings.bottom
        anchors.topMargin: 5
        property string qmlName: "ProjectionWidget.qml"
        property string propertyName: "enabled:"
        property var __comboBoxModel: ProjectionWidget.enabledArray

        label: qsTr("AA/CP Widget Enabled")
        comboBoxModel: __comboBoxModel
        comboBoxModelTextProperty: "option"
        onComboboxItemActivated: {
            ProjectionWidget.enabled = __comboBoxModel[currentIndex].valueId
            storeNewSetting(qmlName, propertyName, __comboBoxModel[currentIndex].valueId)
        }
        modelValueProperty: "valueId"
        initialSourceValue: ProjectionWidget.enabled
        infoButtonVisible: false
    }

    LabelComboBox {
        id: projectionWidgetST
        objectName: "projectionWidgetST"
        anchors.top: projectionWidgetEnabled.bottom
        anchors.topMargin: 5
        property string qmlName: "ProjectionWidget.qml"
        property string propertyName: "semiTransparent:"
        property var __comboBoxModel: ProjectionWidget.semiTransparentArray

        label: qsTr("AA/CP Widget Transparency")
        comboBoxModel: __comboBoxModel
        comboBoxModelTextProperty: "option"
        onComboboxItemActivated: {
            ProjectionWidget.semiTransparent = __comboBoxModel[currentIndex].valueId
            storeNewSetting(qmlName, propertyName, __comboBoxModel[currentIndex].valueId)
        }
        modelValueProperty: "valueId"
        initialSourceValue: ProjectionWidget.semiTransparent
        infoButtonVisible: false
    }
//PROJECTION WIDGET SETTINGS FINISH


    Rectangle {
        width: 0
        height: 0
        color: "transparent"
    }
//    }
}