//AM LOGO REGION SETTINGS START
        LabelComboBox {
            id: customAMLogoRegionSettings
            objectName: "LogoMod_customAMLogoRegion"

            property string qmlName: "AMLogoRegionSettings.qml"
            property string propertyName: "customAMLogoRegion:"
            property var __comboBoxModel: AMLogoRegionSettings.regionAMNameArray

            label: qsTr("Custom AM logo region")
            comboBoxModel: __comboBoxModel
            comboBoxModelTextProperty: "name"
            onComboboxItemActivated: {
                AMLogoRegionSettings.customAMLogoRegion = __comboBoxModel[currentIndex].valueId
                storeNewSetting(qmlName, propertyName, __comboBoxModel[currentIndex].valueId)
            }
            modelValueProperty: "valueId"
            initialSourceValue: AMLogoRegionSettings.customAMLogoRegion
            moreInfoTitle: qsTr("Custom AM logo region","TinfoTitle")
            moreInfoText: qsTr("Allows you to choose between three sets of logos depending on the region you currently traveling in. Logos must be placed in relative folders during installation")
        }
//AM LOGO REGION SETTINGS FINISH
