import QtQuick 2.6
import HmiSettings 1.0

import Hmi.Ford 1.0
import Hmi.Ford.Controls 1.0
import Hmi.Ford.Controls.Settings 1.0
import Hmi.Ford.Views 1.0

import HmiGui 1.0
import HmiGuiFramework.Controls 1.0
import AL2HMIBridge 1.0 as AL2HMIBridge

// Ford HMI Spec H33_View 19/33/34

SettingsView {
    id: root
    objectName: "AutomaticSystemUpdates"
    //~ TextID 5cc44d0e-d16d-11e3-9a96-8c705affb218
    viewTitle: qsTr("Automatic System Updates")

    property string timeStamp : FormattingUtils.formatDateTime(AL2HMIBridge.globalSource.lastUpdateCheckYear,
                                                               AL2HMIBridge.globalSource.lastUpdateCheckMonth,
                                                               AL2HMIBridge.globalSource.lastUpdateCheckDay,
                                                               AL2HMIBridge.globalSource.lastUpdateCheckHour,
                                                               AL2HMIBridge.globalSource.lastUpdateCheckMinute,
                                                               AL2HMIBridge.globalSource.lastUpdateCheckSecond )

    function getSystemUpdateProcess() {
        var systemUpdateProcess = "";
        if (AL2HMIBridge.globalSource.systemUpdateProcess === AL2HMIBridge.GlobalSource.SystemUpdate_Downloading)
            //~ GroupID Settings/automaticsystemupdates-0001
            //~ OldTextID 5cc625de-d16d-11e3-9a96-8c705affb218
            //~ TextID 3dc764b0-d173-11e5-8e77-c4346b7ac93f
            systemUpdateProcess = qsTr("Downloading %1").arg(AL2HMIBridge.globalSource.downloadingFileName)
        else if (AL2HMIBridge.globalSource.systemUpdateProcess === AL2HMIBridge.GlobalSource.SystemUpdate_Installation)
            //~ GroupID Settings/automaticsystemupdates-0001
            //~ TextID 69186d30-661e-11e7-adf9-c4346b6ba0ce
            systemUpdateProcess = qsTr("Installing %1").arg(AL2HMIBridge.globalSource.downloadingFileName)
        else
            systemUpdateProcess = ""

        return systemUpdateProcess
    }

    scrollableAreaContent: [
        SettingsSwitch {
            id: autoSysUpdates
            objectName: "AutomaticSystemUpdates_autoSysUpdates"

            //~ TextID 5cc4b17c-d16d-11e3-9a96-8c705affb218
            text: qsTr("Automatic System Updates", "switchContext")
            toggled: AL2HMIBridge.globalSource.systemAutoUpdateOn && enabled
            onToggleButtonClicked: {
                _hmiSettings.controller.sendAutoSysUpdatesEnabled(!toggled)
            }
            infoButtonVisible: true
            //~ GroupID Dynamic/dynamiccloseabletext-huge-0002
            //~ OldTextID e7d85b50-50e8-11e5-90d2-8c705affb218
            //~ TextID f5184062-ec68-11e6-b5c1-f44d3010a58e
            moreInfoText:qsTr("Enables the vehicle to download the latest available system software features, enhancements, and security updates when connected to a Wi-Fi network. Vehicle information needed to perform the update will be sent to Ford U.S. Data charges may apply. Certain updates may be possible through the %1 app. See your Owners Manual for more details.").arg(CellPhonePassport.getMobileName())
            //~ GroupID Dynamic/dynamiccloseabletext-huge-0001
            //~ OldTextID e473e39c-137d-11e5-9eca-8c705affb218
            //~ TextID f51a3c30-ec68-11e6-a7ae-f44d3010a58e
            moreInfoTitle: qsTr("Automatic System Updates", "moreInfoTitleContext")
            moreInfoPopupSize: HmiGui.Huge
            enabled: !AL2HMIBridge.appLinkSource.installationIsRunning
        },

        ArrowButton {
            id: wifiConnection
            objectName: "AutomaticSystemUpdates_wifiConnection"

            //~ OldTextID ef985401-8bc3-11e6-9085-c4346b6b4525
            //~ TextID 76827f40-ec63-11e6-b476-f44d3010a58e
            text: qsTr("System Wi-Fi")
            visible: autoSysUpdates.toggled
            onClicked: {
                _hmiSettings.controller.setWifiSettingsBackButtonDestination(HmiSettingsController.GoToAutomaticUpdatesState)
                _hmiSettings.controller.requestTransition(HmiSettingsController.ToWifiPage);
            }
            infoButtonVisible: true
            //~ GroupID Dynamic/dynamiccloseabletext-0002
            //~ OldTextID ef985402-8bc3-11e6-b868-c4346b6b4525
            //~ TextID 08155062-ec67-11e6-95ac-f44d3010a58e
            moreInfoText: qsTr("System Wi-Fi allows SYNC to connect to available Wi-Fi networks for Automatic System Updates. System Wi-Fi must be on for Automatic System Updates to take place.")
            //~ GroupID Dynamic/dynamiccloseabletext-0001
            //~ TextID ef985403-8bc3-11e6-9092-c4346b6b4525
            moreInfoTitle: qsTr("System Wi-Fi", "moreInfoTitleContext")
            moreInfoPopupSize: HmiGui.Big
        },

        ArrowButton {
            id: currentVersion
            objectName: "AutomaticSystemUpdates_currentVersion"

            //~ OldTextID 5cc52972-d16d-11e3-9a96-8c705affb218
            //~ TextID 913bec80-ec6e-11e6-92e2-f44d3010a58e
            text: qsTr("View Current Software Versions")
            onClicked: _hmiSettings.controller.requestTransition(HmiSettingsController.ToGeneralAboutPage);
            infoButtonVisible: true
            //~ GroupID Dynamic/dynamiccloseabletext-0002
            //~ TextID d038e690-ec69-11e6-ace1-f44d3010a58e
            moreInfoText: qsTr("Provides information about SYNC, including the software version, and any specific serial numbers or identification numbers that may be specific to your vehicle's system.")
            //~ GroupID Dynamic/dynamiccloseabletext-0001
            //~ TextID d03abb52-ec69-11e6-b43f-f44d3010a58e
            moreInfoTitle: qsTr("About SYNC")
            moreInfoPopupSize: HmiGui.Big
        },

        ArrowButton {
            id: checkForUpdates
            objectName: "AutomaticSystemUpdates_checkForUpdates"

            //~ TextID faf685ce-f5bf-11e4-a08b-2089842afb51
            text: qsTr("Scan for Updates Now")
            visible: autoSysUpdates.toggled
                     && !AL2HMIBridge.globalSource.systemUpdateDownloadInProgress
                     && AL2HMIBridge.globalSource.systemUpdateScanStatus !== AL2HMIBridge.GlobalSource.SystemUpdateScanActive
                     && AL2HMIBridge.globalSource.systemUpdateScanStatus !== AL2HMIBridge.GlobalSource.SystemUpdateScanAck

            onClicked: _hmiSettings.controller.checkForSystemUpdates();
            infoButtonVisible: true
            //~ GroupID Dynamic/dynamiccloseabletext-0001
            //~ TextID 70adadd2-ecf2-11e6-be49-a0481c9f9aee
            moreInfoTitle: qsTr("Scan for Updates Now", "moreInfoTitleContext")
            //~ GroupID Dynamic/dynamiccloseabletext-0002
            //~ TextID 70adadd3-ecf2-11e6-b860-a0481c9f9aee
            moreInfoText: qsTr("Scan for available vehicle updates.")
            moreInfoPopupSize: HmiGui.Big
        },

        SettingsDelegate {
            id: scanningForUpdates
            objectName: "AutomaticSystemUpdates_scanningForUpdates"

            text:!AL2HMIBridge.globalSource.systemUpdateDownloadInProgress ?
                     //~ GroupID Settings/automaticsystemupdates-0002
                     //~ TextID 9cba1b70-ec75-11e6-bfef-f44d3010a58e
                     qsTr("Scanning for Updates...") :
                     //~ GroupID Settings/automaticsystemupdates-0002
                     //~ TextID 9caf3c70-eeda-11e6-ba0d-c4346b7ac93f
                     qsTr("Downloading Update...")
            infoButtonVisible: false
            keepMoreInfoGap: false
            visible: autoSysUpdates.toggled
                     && (AL2HMIBridge.globalSource.systemUpdateDownloadInProgress
                         ||AL2HMIBridge.globalSource.systemUpdateScanStatus === AL2HMIBridge.GlobalSource.SystemUpdateScanActive
                         || AL2HMIBridge.globalSource.systemUpdateScanStatus === AL2HMIBridge.GlobalSource.SystemUpdateScanAck)
            active: !AL2HMIBridge.globalSource.systemUpdateDownloadInProgress
                    && AL2HMIBridge.globalSource.systemUpdateScanStatus !== AL2HMIBridge.GlobalSource.SystemUpdateScanActive
                    && AL2HMIBridge.globalSource.systemUpdateScanStatus !== AL2HMIBridge.GlobalSource.SystemUpdateScanAck
        },

        Column {
            objectName: "AutomaticSystemUpdates_column1"
            anchors {
                left: parent.left
                right: parent.right
                leftMargin: UiTheme.styleRoot.globalMarginWide
            }
            spacing: UiTheme.styleRoot.generalMarginSmall

            visible: autoSysUpdates.toggled && timeStamp !== "" && !(AL2HMIBridge.globalSource.systemUpdateDownloadInProgress
                                                           || AL2HMIBridge.globalSource.systemUpdateScanStatus === AL2HMIBridge.GlobalSource.SystemUpdateScanActive
                                                           || AL2HMIBridge.globalSource.systemUpdateScanStatus === AL2HMIBridge.GlobalSource.SystemUpdateScanAck)

            Item {
                id: lastUpdatedTopSpacer
                objectName: "AutomaticSystemUpdates_lastUpdatedTopSpacer"
                height: UiTheme.styleRoot.generalMarginSmaller
                width: parent.width
            }

            TextLabel {
                objectName: "AutomaticSystemUpdates_textLabel1"
                anchors.left: parent.left
                anchors.right: parent.right
                wrapMode: Text.WordWrap
                horizontalAlignment: ViewController.rightToLeftLanguageActive ? Text.AlignRight : Text.AlignLeft
                //~ OldTextID 5cc5965a-d16d-11e3-9a96-8c705affb218
                //~ TextID 3af3e07c-8026-11e8-b96a-08002718b8d7
                text: qsTr("The software is up to date.")
            }

            TextLabel {
                objectName: "AutomaticSystemUpdates_textLabel2"
                anchors.left: parent.left
                anchors.right: parent.right
                wrapMode: Text.WordWrap
                horizontalAlignment: ViewController.rightToLeftLanguageActive ? Text.AlignRight : Text.AlignLeft

                text: timeStamp
            }
        },

        Column {
            objectName: "AutomaticSystemUpdates_column2"
            anchors {
                left: parent.left
                right: parent.right
                leftMargin: UiTheme.styleRoot.globalMarginMedium
            }
            spacing: UiTheme.styleRoot.generalMarginSmall

            visible: autoSysUpdates.toggled && AL2HMIBridge.globalSource.systemUpdateDownloadInProgress

            Item {
                id: downloadingUpdatesTopSpacer
                objectName: "AutomaticSystemUpdates_downloadingUpdatesTopSpacer"
                height: UiTheme.styleRoot.generalMarginSmaller
                width: parent.width
            }

            TextLabel {
                objectName: "AutomaticSystemUpdates_textLabel3"
                anchors.left: parent.left
                anchors.right: parent.right
                wrapMode: Text.WordWrap
                horizontalAlignment: Text.AlignHCenter

                text: root.getSystemUpdateProcess()
                variation: HmiGui.BigLabelVariationMedium
            }

            ProgressBar {
                objectName: "AutomaticSystemUpdates_progressBar1"
                anchors {
                    left: parent.left
                    right: parent.right
                }
                LayoutMirroring.enabled: ViewController.rightToLeftLanguageActive
                LayoutMirroring.childrenInherit: true

                minimumValue: 0
                maximumValue: 100
                value: AL2HMIBridge.globalSource.updateDownloadProgress
            }
        },

        Column {
            objectName: "AutomaticSystemUpdates_column3"
            anchors {
                left: parent.left
                right: parent.right
                leftMargin: UiTheme.styleRoot.globalMarginWide
            }

            visible: autoSysUpdates.toggled
                     && (AL2HMIBridge.globalSource.systemUpdateScanStatus === AL2HMIBridge.GlobalSource.SystemUpdateScanActive
                         || AL2HMIBridge.globalSource.systemUpdateScanStatus === AL2HMIBridge.GlobalSource.SystemUpdateScanAck)

            Item {
                id: scaningTopSpacer
                objectName: "AutomaticSystemUpdates_scaningTopSpacer"
                height: UiTheme.styleRoot.generalMarginSmaller
                width: parent.width
            }

                LoadingIcon {
                    id: spinner
                    objectName: "AutomaticSystemUpdates_spinner"
                    anchors.horizontalCenter: parent.horizontalCenter

                    spinnerSize: HmiGui.SpinnerMedium
                }
        }
    ]
}
