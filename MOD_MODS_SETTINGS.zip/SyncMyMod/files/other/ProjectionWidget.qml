pragma Singleton
import QtQuick 2.0
QtObject {
    property var positionAA:[200,200]
    property var positionCP:[200,200]
    property int enabled:0
    property var enabledArray: [

        { option: 'Enabled', valueId: 0},

        { option: 'AndroidAuto Only', valueId: 1},

        { option: 'CarPlay Only', valueId: 2},

        { option: 'Disabled', valueId: 3}
    ]
    property int semiTransparent:3
    property var semiTransparentArray: [

        { option: 'Enabled', valueId: 0},

        { option: 'AndroidAuto Only', valueId: 1},

        { option: 'CarPlay Only', valueId: 2},

        { option: 'Disabled', valueId: 3}
    ]
}