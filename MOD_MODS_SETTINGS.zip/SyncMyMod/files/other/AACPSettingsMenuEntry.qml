//PROJECTION WIDGET SETTINGS START
        LabelComboBox {
            id: projectionWidgetEnabled
            objectName: "projectionWidgetEnabled"
            property string qmlName: "ProjectionWidget.qml"
            property string propertyName: "enabled:"
            property var __comboBoxModel: ProjectionWidget.enabledArray

            label: qsTr("AA/CP Widget Enabled")
            comboBoxModel: __comboBoxModel
            comboBoxModelTextProperty: "option"
            onComboboxItemActivated: {
                ProjectionWidget.enabled = __comboBoxModel[currentIndex].valueId
                storeNewSetting(qmlName, propertyName, __comboBoxModel[currentIndex].valueId)
            }
            modelValueProperty: "valueId"
            initialSourceValue: ProjectionWidget.enabled
            infoButtonVisible: false

        },
        LabelComboBox {
            id: projectionWidgetST
            objectName: "projectionWidgetST"
            property string qmlName: "ProjectionWidget.qml"
            property string propertyName: "semiTransparent:"
            property var __comboBoxModel: ProjectionWidget.semiTransparentArray

            label: qsTr("AA/CP Widget Transparency")
            comboBoxModel: __comboBoxModel
            comboBoxModelTextProperty: "option"
            onComboboxItemActivated: {
                ProjectionWidget.semiTransparent = __comboBoxModel[currentIndex].valueId
                storeNewSetting(qmlName, propertyName, __comboBoxModel[currentIndex].valueId)
            }
            modelValueProperty: "valueId"
            initialSourceValue: ProjectionWidget.semiTransparent
            infoButtonVisible: false

        },
//PROJECTION WIDGET SETTINGS FINISH
