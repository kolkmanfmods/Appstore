//FM LOGO REGION SETTINGS START
        LabelComboBox {
            id: customLogoRegionSettings
            objectName: "FMLogoMod_customLogoRegion"

            property string qmlName: "FMLogoRegionSettings.qml"
            property string propertyName: "customLogoRegion:"
            property var __comboBoxModel: FMLogoRegionSettings.regionNameArray

            label: qsTr("Custom FM logo region")
            comboBoxModel: __comboBoxModel
            comboBoxModelTextProperty: "name"
            onComboboxItemActivated: {
                FMLogoRegionSettings.customLogoRegion = __comboBoxModel[currentIndex].valueId
                storeNewSetting(qmlName, propertyName, __comboBoxModel[currentIndex].valueId)
            }
            modelValueProperty: "valueId"
            initialSourceValue: FMLogoRegionSettings.customLogoRegion
            moreInfoTitle: qsTr("Custom FM logo region","TinfoTitle")
            moreInfoText: qsTr("Allows you to choose between three sets of logos depending on the region you currently traveling in. Logos must be placed in relative folders during installation")
        }
//FM LOGO REGION SETTINGS FINISH
