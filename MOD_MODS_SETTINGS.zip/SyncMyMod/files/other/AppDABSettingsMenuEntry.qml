//DAB LOGO REGION SETTINGS START
        LabelComboBox {
            id: customDABLogoRegionSettings
            objectName: "LogoMod_customDABLogoRegion"

            property string qmlName: "DABLogoRegionSettings.qml"
            property string propertyName: "customDABLogoRegion:"
            property var __comboBoxModel: DABLogoRegionSettings.regionDABNameArray

            label: qsTr("Custom DAB logo region")
            comboBoxModel: __comboBoxModel
            comboBoxModelTextProperty: "name"
            onComboboxItemActivated: {
                DABLogoRegionSettings.customDABLogoRegion = __comboBoxModel[currentIndex].valueId
                storeNewSetting(qmlName, propertyName, __comboBoxModel[currentIndex].valueId)
            }
            modelValueProperty: "valueId"
            initialSourceValue: DABLogoRegionSettings.customDABLogoRegion
            moreInfoTitle: qsTr("Custom DAB logo region","TinfoTitle")
            moreInfoText: qsTr("Allows you to choose between three sets of logos depending on the region you currently traveling in. Logos must be placed in relative folders during installation")
        }
//DAB LOGO REGION SETTINGS FINISH
